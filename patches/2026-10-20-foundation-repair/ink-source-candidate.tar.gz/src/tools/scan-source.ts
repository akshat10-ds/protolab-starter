import { z } from 'zod';
import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import type { Registry } from '../data/registry';
import type { Tracker } from '../analytics/tracker';
import { withTracking } from '../analytics/wrapper';
import mappingData from '@/data/dsui-mapping.json';

/* ═══════════════════════════════════════
   URL Validation (SSRF protection)
   ═══════════════════════════════════════ */

/** Private/internal IP ranges that must never be fetched */
const PRIVATE_IP_PATTERNS = [
  /^127\./, /^10\./, /^172\.(1[6-9]|2\d|3[01])\./, /^192\.168\./,
  /^169\.254\./, /^0\.0\.0\.0$/, /^\[::1\]$/, /^localhost$/i,
];

/**
 * Validate a URL before fetching. Returns an error string if invalid, null if OK.
 * Blocks private IPs, internal metadata endpoints, and non-http(s) schemes.
 * Allows http://localhost in dev for local prototype scanning.
 */
export function validateScanUrl(rawUrl: string): string | null {
  let parsed: URL;
  try {
    parsed = new URL(rawUrl);
  } catch {
    return `Invalid URL: "${rawUrl}"`;
  }

  // Block dangerous schemes
  if (!['http:', 'https:'].includes(parsed.protocol)) {
    return `Blocked scheme "${parsed.protocol}" — only http/https allowed`;
  }

  const hostname = parsed.hostname;

  // Allow localhost for local dev
  if (hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '[::1]') {
    return null;
  }

  // Block private/internal IPs
  for (const pattern of PRIVATE_IP_PATTERNS) {
    if (pattern.test(hostname)) {
      return `Blocked private/internal address: ${hostname}`;
    }
  }

  // Enforce https for non-localhost
  if (parsed.protocol !== 'https:') {
    return `Non-localhost URLs must use https (got ${parsed.protocol})`;
  }

  return null;
}

/* ═══════════════════════════════════════
   Types
   ═══════════════════════════════════════ */

interface ComponentMapping {
  dsuiName: string;
  propMap: Record<string, string>;
  textProp?: string;
  subcomponents?: string[];
  notes?: string;
}

interface ProtoLabOnlyEntry {
  dsuiHint: string;
}

interface MappingConfig {
  version: string;
  components: Record<string, ComponentMapping>;
  protoLabOnly: Record<string, ProtoLabOnlyEntry>;
  iconMap: Record<string, string>;
}

interface ScannedComponent {
  component: string;
  dsuiName: string;
  props: Record<string, string>;
  dsuiProps: Record<string, string>;
  text?: string;
  icon?: { protoLabName: string; dsuiName: string; position?: string };
  isProtoLabOnly: boolean;
  dsuiHint?: string;
  notes?: string;
}

interface ScanOutput {
  metadata: {
    source: string;
    scannedAt: string;
    mappingVersion: string;
  };
  imports: {
    dsui: string;
    icons: string;
  };
  components: ScannedComponent[];
  summary: {
    total: number;
    unique: string[];
    directMatch: number;
    renamed: number;
    protoLabOnly: number;
    byComponent: Record<string, number>;
  };
  todos: string[];
}

/* ═══════════════════════════════════════
   Load Mapping
   ═══════════════════════════════════════ */

const mapping = mappingData as MappingConfig;

/* ═══════════════════════════════════════
   HTML Scanner
   ═══════════════════════════════════════ */

function scanHtml(html: string, source: string): ScanOutput {
  const scanned: ScannedComponent[] = [];

  // Find all elements with data-ink-component
  const elementRe = /<[a-zA-Z][^>]*data-ink-component="([^"]+)"[^>]*>/gi;
  const propRe = /data-ink-prop-([a-z]+)="([^"]*)"/g;
  let match;

  while ((match = elementRe.exec(html)) !== null) {
    const fullTag = match[0];
    const protoLabName = match[1];

    // Extract variant props
    const props: Record<string, string> = {};
    let propMatch;
    propRe.lastIndex = 0;
    while ((propMatch = propRe.exec(fullTag)) !== null) {
      props[propMatch[1]] = propMatch[2];
    }

    // Extract text content (first text after the opening tag, before next tag)
    const afterTag = html.substring(match.index + fullTag.length);
    const textMatch = afterTag.match(/^\s*([^<]+)/);
    const text = textMatch ? textMatch[1].trim() : undefined;

    // Look up mapping
    const componentMap = mapping.components[protoLabName];
    const isProtoLabOnly = protoLabName in mapping.protoLabOnly;

    // Map props to ds-ui prop names
    const dsuiProps: Record<string, string> = {};
    if (componentMap) {
      for (const [plProp, value] of Object.entries(props)) {
        const dsuiPropName = componentMap.propMap[plProp] || plProp;
        dsuiProps[dsuiPropName] = value;
      }
    }

    // Check for icon
    let icon: ScannedComponent['icon'] | undefined;
    if (protoLabName === 'Icon' && props.name) {
      const dsuiIconName = mapping.iconMap[props.name] || props.name;
      icon = { protoLabName: props.name, dsuiName: dsuiIconName };
    }

    scanned.push({
      component: protoLabName,
      dsuiName: componentMap?.dsuiName || protoLabName,
      props,
      dsuiProps: Object.keys(dsuiProps).length > 0 ? dsuiProps : {},
      ...(text && text.length > 0 && text.length < 100 ? { text } : {}),
      ...(icon ? { icon } : {}),
      isProtoLabOnly,
      ...(isProtoLabOnly ? { dsuiHint: mapping.protoLabOnly[protoLabName]?.dsuiHint } : {}),
      ...(componentMap?.notes ? { notes: componentMap.notes } : {}),
    });
  }

  return buildOutput(scanned, source);
}

/* ═══════════════════════════════════════
   Output Builder
   ═══════════════════════════════════════ */

function buildOutput(scanned: ScannedComponent[], source: string): ScanOutput {
  // Collect unique ds-ui component names for imports
  const dsuiImports = new Set<string>();
  const iconImports = new Set<string>();

  for (const c of scanned) {
    if (!c.isProtoLabOnly) {
      dsuiImports.add(c.dsuiName);
    }
    if (c.icon) {
      iconImports.add(c.icon.dsuiName);
    }
  }

  // Also scan for icons used as startElement/endElement in other components
  for (const c of scanned) {
    if (c.component === 'Icon' && c.icon) {
      iconImports.add(c.icon.dsuiName);
    }
  }

  // Count categories
  const byComponent: Record<string, number> = {};
  let directMatch = 0;
  let renamed = 0;
  let protoLabOnly = 0;

  for (const c of scanned) {
    byComponent[c.component] = (byComponent[c.component] || 0) + 1;
    if (c.isProtoLabOnly) {
      protoLabOnly++;
    } else if (c.component === c.dsuiName) {
      directMatch++;
    } else {
      renamed++;
    }
  }

  // Generate TODOs
  const todos: string[] = [];
  const textsFound = scanned.filter(c => c.text);
  if (textsFound.length > 0) {
    todos.push(`${textsFound.length} text strings need localization via useTranslate()`);
  }
  todos.push('Add data-qa attributes to interactive elements');
  todos.push('Add accessibilityText to IconButton components');
  todos.push('Wire event handlers (onClick, onChange, etc.)');
  todos.push('Add state management for controlled components');
  if (protoLabOnly > 0) {
    todos.push(`${protoLabOnly} ProtoLab-only components need manual ds-ui composition (see dsuiHint)`);
  }

  const sortedDsui = Array.from(dsuiImports).sort();
  const sortedIcons = Array.from(iconImports).sort();

  return {
    metadata: {
      source,
      scannedAt: new Date().toISOString(),
      mappingVersion: mapping.version,
    },
    imports: {
      dsui: sortedDsui.length > 0
        ? `import { ${sortedDsui.join(', ')} } from '@ds/ui'`
        : '',
      icons: sortedIcons.length > 0
        ? `import { ${sortedIcons.join(', ')} } from '@ds/icons'`
        : '',
    },
    components: scanned,
    summary: {
      total: scanned.length,
      unique: Array.from(new Set(scanned.map(c => c.component))),
      directMatch,
      renamed,
      protoLabOnly,
      byComponent,
    },
    todos,
  };
}

/* ═══════════════════════════════════════
   MCP Tool Registration
   ═══════════════════════════════════════ */

export function registerScanSource(
  server: McpServer,
  registry: Registry,
  tracker: Tracker,
) {
  server.tool(
    'scan_prototype',
    `Scan a ProtoLab prototype for ProtoLab components and produce a structured ds-ui component spec.

Accepts a URL (fetches rendered page) or raw HTML. Returns a deterministic JSON spec with:
- @ds/ui and @ds/icons import statements (copy-paste ready)
- Every component found with its ds-ui equivalent name and mapped props
- ProtoLab-only components flagged with migration hints
- TODO checklist for production readiness (localization, a11y, handlers)

Use this to:
- Convert a ProtoLab prototype to a production @ds/ui component spec
- Audit component usage across a prototype
- Feed the spec into Figma plugins, v0, or code generators
- Share with FES as a machine-readable design handoff`,
    {
      url: z.string().optional().describe('URL of a deployed ProtoLab prototype'),
      html: z.string().optional().describe('Raw rendered HTML to scan (alternative to URL)'),
    },
    withTracking(tracker, 'scan_prototype', server, async ({ url, html }) => {
      if (!url && !html) {
        return {
          content: [{
            type: 'text' as const,
            text: JSON.stringify({ error: 'Provide either a url or html parameter' }, null, 2),
          }],
        };
      }

      const source = url || 'html-input';
      let htmlContent: string;

      if (url) {
        // SSRF protection: validate URL before fetching
        const urlError = validateScanUrl(url);
        if (urlError) {
          return {
            content: [{
              type: 'text' as const,
              text: JSON.stringify({ error: urlError }, null, 2),
            }],
          };
        }

        try {
          const controller = new AbortController();
          const timeout = setTimeout(() => controller.abort(), 10_000);
          const response = await fetch(url, {
            headers: { 'User-Agent': 'ProtoLab-Scanner/1.0' },
            signal: controller.signal,
          });
          clearTimeout(timeout);
          if (!response.ok) {
            return {
              content: [{
                type: 'text' as const,
                text: JSON.stringify({
                  error: `Failed to fetch ${url}: ${response.status} ${response.statusText}`,
                }, null, 2),
              }],
            };
          }
          htmlContent = await response.text();
        } catch (err) {
          const message = err instanceof Error ? err.message : String(err);
          return {
            content: [{
              type: 'text' as const,
              text: JSON.stringify({
                error: `Network error fetching ${url}: ${message}`,
              }, null, 2),
            }],
          };
        }
      } else {
        htmlContent = html ?? '';
      }

      const result = scanHtml(htmlContent, source);

      return {
        content: [{
          type: 'text' as const,
          text: JSON.stringify(result, null, 2),
        }],
      };
    }),
  );
}
