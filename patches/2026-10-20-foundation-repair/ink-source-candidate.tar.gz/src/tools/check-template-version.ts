import { z } from 'zod';
import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import type { Tracker } from '../analytics/tracker';
import { withTracking } from '../analytics/wrapper';
import { getSiteBaseUrl } from '../data/base-url';

export function registerCheckTemplateVersion(
  server: McpServer,
  tracker: Tracker,
  /** Pre-computed SHA-256 prefix of data/bundle.json (from module init in route.ts) */
  bundleHash: string,
  componentCount: number,
) {
  server.tool(
    'check_template_version',
    'Check if a local Ink template project is up to date with the server. Pass the bundleHash from your local version.json to compare.',
    {
      localBundleHash: z
        .string()
        .optional()
        .describe('The bundleHash from your local version.json file'),
    },
    withTracking(tracker, 'check_template_version', server, async ({ localBundleHash }) => {
      const siteUrl = getSiteBaseUrl();

      const upToDate = localBundleHash
        ? localBundleHash === bundleHash
        : false;

      const result = {
        upToDate,
        serverBundleHash: bundleHash,
        serverComponentCount: componentCount,
        ...(localBundleHash && { localBundleHash }),
        ...(upToDate
          ? { message: 'Your template is up to date.' }
          : {
              message: 'Your template is outdated. Update from GitHub or download the latest version.',
              downloadUrl: `${siteUrl}/downloads/ink-starter-kit.zip`,
              githubRepoUrl: 'https://github.com/akshat10-ds/protolab-starter',
              updateInstructions: 'Pull latest from https://github.com/akshat10-ds/protolab-starter, or download the zip and replace your src/design-system/ directory.',
            }),
      };

      return {
        content: [{ type: 'text' as const, text: JSON.stringify(result) }],
      };
    })
  );
}
