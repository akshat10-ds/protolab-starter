import { z } from 'zod';
import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { STOP_WORDS, type Registry } from '../data/registry';
import type { Tracker } from '../analytics/tracker';
import { withTracking } from '../analytics/wrapper';

// ─── JSX Source Mode Types ───────────────────────────────────────────

interface ComponentTreeNode {
  /** Ink component name (PascalCase, found in registry) */
  component?: string;
  /** Props extracted from JSX attributes */
  props?: Record<string, string>;
  /** Raw HTML element tag (lowercase) */
  element?: string;
  /** Text content */
  text?: string;
  /** Child nodes */
  children?: ComponentTreeNode[];
  /** Whether this node is a known Ink component */
  isInk?: boolean;
}

// ─── JSX Parser ──────────────────────────────────────────────────────

function parseJSXToTree(code: string, registry: Registry): ComponentTreeNode {
  const allNames = registry.getAllNamesSet();
  const root: ComponentTreeNode = { element: 'root', children: [] };
  const stack: ComponentTreeNode[] = [root];

  // Match JSX tags: opening, closing, self-closing
  const tagRegex = /<\/?([A-Za-z][A-Za-z0-9.]*)((?:\s+[a-zA-Z][-a-zA-Z0-9]*(?:\s*=\s*(?:"[^"]*"|'[^']*'|\{[^}]*\}))?)*)\s*(\/?)>/g;

  let match;
  let lastIndex = 0;

  while ((match = tagRegex.exec(code)) !== null) {
    const [fullMatch, tagName, attrsStr, selfClosing] = match;
    const isClosing = fullMatch.startsWith('</');

    if (isClosing) {
      if (stack.length > 1) {
        stack.pop();
      }
      continue;
    }

    // Extract text content between tags
    const textBetween = code.slice(lastIndex, match.index).trim();
    if (textBetween && !textBetween.startsWith('<') && !textBetween.includes('{') && stack.length > 0) {
      const cleanText = textBetween.replace(/[{}]/g, '').trim();
      if (cleanText && cleanText.length < 200) {
        const parent = stack[stack.length - 1];
        if (!parent.children) parent.children = [];
        parent.children.push({ text: cleanText });
      }
    }
    lastIndex = match.index + fullMatch.length;

    // Build node
    const isPascalCase = /^[A-Z]/.test(tagName);
    const isInkComponent = isPascalCase && (allNames.has(tagName) || allNames.has(tagName.split('.')[0]));

    const node: ComponentTreeNode = {};

    if (isInkComponent) {
      node.component = tagName;
      node.isInk = true;

      // Extract props
      const props: Record<string, string> = {};
      const propRegex = /([a-zA-Z][-a-zA-Z0-9]*)\s*=\s*(?:"([^"]*)"|'([^']*)'|\{([^}]*)\})/g;
      let propMatch;
      while ((propMatch = propRegex.exec(attrsStr || '')) !== null) {
        const [, propName, dblQuote, sglQuote, expr] = propMatch;
        if (propName !== 'className' && propName !== 'style' && propName !== 'key') {
          props[propName] = dblQuote ?? sglQuote ?? expr ?? 'true';
        }
      }
      // Boolean props (no value)
      const boolPropRegex = /\s([a-zA-Z][-a-zA-Z0-9]*)(?=\s|\/?>|$)/g;
      let boolMatch;
      while ((boolMatch = boolPropRegex.exec(attrsStr || '')) !== null) {
        const propName = boolMatch[1];
        if (!props[propName] && propName !== 'className' && propName !== 'style') {
          props[propName] = 'true';
        }
      }

      if (Object.keys(props).length > 0) {
        node.props = props;
      }
    } else if (isPascalCase) {
      // PascalCase but not in registry — custom/local component
      node.component = tagName;
      node.isInk = false;
    } else {
      // HTML element
      node.element = tagName;
      node.isInk = false;
    }

    // Add to parent
    const parent = stack[stack.length - 1];
    if (!parent.children) parent.children = [];
    parent.children.push(node);

    // Push to stack if not self-closing
    if (!selfClosing) {
      stack.push(node);
    }
  }

  // Return the root's children (or root itself)
  if (root.children && root.children.length === 1) {
    return root.children[0];
  }
  return root;
}

// ─── Tree Analysis Helpers ───────────────────────────────────────────

function collectTreeStats(node: ComponentTreeNode) {
  let totalNodes = 0;
  let inkComponents = 0;
  let rawHtmlElements = 0;
  const uniqueInk = new Set<string>();
  const rawHtmlGaps: Array<{ element: string; suggestion: string | null; context: string }> = [];

  function walk(n: ComponentTreeNode, parentName: string) {
    totalNodes++;

    if (n.component && n.isInk) {
      inkComponents++;
      uniqueInk.add(n.component);
    } else if (n.element && n.element !== 'root') {
      rawHtmlElements++;
    } else if (n.text) {
      // text nodes count toward total but nothing else
    }

    if (n.element && n.element !== 'root' && !n.isInk) {
      rawHtmlGaps.push({
        element: n.element,
        suggestion: null, // filled in by caller with registry search
        context: parentName,
      });
    }

    if (n.children) {
      const name = n.component ?? n.element ?? parentName;
      for (const child of n.children) {
        walk(child, name);
      }
    }
  }

  walk(node, 'root');
  return { totalNodes, inkComponents, rawHtmlElements, uniqueInkComponents: Array.from(uniqueInk), rawHtmlGaps };
}

// Module-level constants (avoids recreation per request)
const TOKEN_SUGGESTIONS: Record<string, string[]> = {
  layout: ['spacing', 'color'],
  navigation: ['color', 'spacing'],
  form: ['spacing', 'color', 'typography'],
  input: ['spacing', 'color', 'border-radius'],
  button: ['color', 'spacing', 'typography'],
  table: ['spacing', 'color', 'border'],
  card: ['spacing', 'color', 'border-radius', 'shadow'],
  modal: ['spacing', 'color', 'shadow', 'border-radius'],
  text: ['typography', 'color'],
  icon: ['color'],
};

function getTokenSuggestions(element: string): string[] {
  const lower = element.toLowerCase();
  const suggestions = new Set<string>();
  for (const [keyword, tokens] of Object.entries(TOKEN_SUGGESTIONS)) {
    if (lower.includes(keyword)) {
      for (const t of tokens) suggestions.add(t);
    }
  }
  // Default if nothing matched
  if (suggestions.size === 0) {
    suggestions.add('spacing');
    suggestions.add('color');
  }
  return Array.from(suggestions);
}

export function registerMapElements(server: McpServer, registry: Registry, tracker: Tracker) {
  server.tool(
    'map_ui_elements',
    'Map UI elements to ProtoLab components. Two modes: (1) Pass JSX/TSX code to get a hierarchical component tree showing ProtoLab components and raw HTML gaps. (2) Pass element descriptions for flat component matching.',
    {
      elements: z
        .array(z.string())
        .optional()
        .describe(
          'List of UI element descriptions for flat mapping mode, e.g. ["sidebar navigation", "search input", "data table", "submit button"]'
        ),
      code: z
        .string()
        .optional()
        .describe(
          'JSX/TSX source code to parse into a hierarchical ProtoLab component tree. Returns a tree showing ProtoLab components (with props), raw HTML elements, and text content.'
        ),
      includeTokenSuggestions: z
        .boolean()
        .optional()
        .default(false)
        .describe('Include relevant design token suggestions for each element'),
    },
    withTracking(tracker, 'map_ui_elements', server, async ({ elements, code, includeTokenSuggestions }) => {
      // Validate: at least one of elements or code must be provided
      if (!code && (!elements || elements.length === 0)) {
        return {
          content: [{ type: 'text' as const, text: JSON.stringify({ error: 'At least one of "elements" or "code" must be provided.' }) }],
        };
      }

      // ─── Source Mode: JSX/TSX code → component tree ───
      if (code) {
        const tree = parseJSXToTree(code, registry);
        const stats = collectTreeStats(tree);

        // Fill in suggestions for raw HTML gaps using registry search
        for (const gap of stats.rawHtmlGaps) {
          const results = registry.searchComponents(gap.element);
          if (results.length > 0) {
            gap.suggestion = results[0].name;
          }
        }

        // Build suggested import statement
        const importNames = stats.uniqueInkComponents.sort();
        const suggestedImports = importNames.length > 0
          ? `import { ${importNames.join(', ')} } from '@/design-system';`
          : '';

        // Analytics
        tracker.emit({
          event: 'search_query',
          ts: new Date().toISOString(),
          query: `map_elements_source: ${stats.uniqueInkComponents.join(', ')}`,
          resultCount: stats.inkComponents,
          topMatches: stats.uniqueInkComponents,
        });

        const result = {
          tree,
          summary: {
            totalNodes: stats.totalNodes,
            inkComponents: stats.inkComponents,
            rawHtmlElements: stats.rawHtmlElements,
            uniqueInkComponents: stats.uniqueInkComponents,
            rawHtmlGaps: stats.rawHtmlGaps,
          },
          suggestedImports,
        };

        return {
          content: [{ type: 'text' as const, text: JSON.stringify(result) }],
        };
      }

      // ─── Flat Mapping Mode: element descriptions → component matches ───
      interface Mapping {
        element: string;
        match: {
          name: string;
          layer: number;
          type: string;
          description: string;
          import: string;
        } | null;
        alternatives: Array<{ name: string; layer: number; type: string }>;
        confidence: 'high' | 'medium' | 'low' | 'none';
        tokenSuggestions?: string[];
      }

      const mappings: Mapping[] = [];
      const unmapped: string[] = [];

      for (const element of elements!) {
        const results = registry.searchComponentsWithScores(element);

        if (results.length === 0) {
          unmapped.push(element);
          mappings.push({
            element,
            match: null,
            alternatives: [],
            confidence: 'none',
            ...(includeTokenSuggestions && { tokenSuggestions: getTokenSuggestions(element) }),
          });
          continue;
        }

        const { meta: top, score: topScore } = results[0];
        const alternatives = results.slice(1, 4).map(r => ({
          name: r.meta.name,
          layer: r.meta.layer,
          type: r.meta.type,
        }));

        // Scale confidence thresholds by query complexity
        const termCount = element.split(/\s+/).filter((t: string) => !STOP_WORDS.has(t)).length || 1;
        const highThreshold = 10 + (termCount * 5);   // 1 term: 15, 2 terms: 20, 3 terms: 25
        const medThreshold = 5 + (termCount * 3);     // 1 term: 8, 2 terms: 11, 3 terms: 14

        let confidence: 'high' | 'medium' | 'low';
        if (topScore >= highThreshold) confidence = 'high';
        else if (topScore >= medThreshold) confidence = 'medium';
        else confidence = 'low';

        mappings.push({
          element,
          match: {
            name: top.name,
            layer: top.layer,
            type: top.type,
            description: top.description,
            import: `import { ${top.name} } from '${top.imports}';`,
          },
          alternatives,
          confidence,
          ...(includeTokenSuggestions && { tokenSuggestions: getTokenSuggestions(element) }),
        });
      }

      // Build a suggested hierarchy from matched components
      const matched = mappings
        .filter(m => m.match)
        .sort((a, b) => (b.match!.layer - a.match!.layer));

      let suggestedHierarchy = '';
      if (matched.length > 0) {
        const parts = matched.map(m => `${m.match!.name} (L${m.match!.layer})`);
        suggestedHierarchy = parts.join(' > ');
      }

      // Semantic event
      tracker.emit({
        event: 'search_query',
        ts: new Date().toISOString(),
        query: `map_elements: ${elements!.join(', ')}`,
        resultCount: mappings.filter(m => m.match).length,
        topMatches: mappings.filter(m => m.match).map(m => m.match!.name),
      });

      const result = {
        mappings,
        unmapped,
        suggestedHierarchy,
      };

      return {
        content: [{ type: 'text' as const, text: JSON.stringify(result) }],
      };
    })
  );
}
