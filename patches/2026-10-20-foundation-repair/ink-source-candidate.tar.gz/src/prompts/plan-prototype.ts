import { z } from 'zod';
import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import type { Registry } from '../data/registry';
import { componentIndex, tokenQuickRef, spacingCheatSheet, navigationDefaults } from './format';

export function registerPlanPrototypePrompt(server: McpServer, registry: Registry) {
  server.prompt(
    'plan_prototype',
    'End-to-end workflow for planning and building a prototype. Accepts a Figma URL, screenshot description, or text description. Generates an ASCII layout plan for user approval, then scaffolds a complete runnable project.',
    {
      description: z
        .string()
        .describe(
          "What to build — a Figma URL (figma.com/design/...), a description of a screenshot you're looking at, or a text description like 'agreements table page with filters'"
        ),
    },
    ({ description }) => {
      const workflow = `You are helping the user plan and build a prototype with ProtoLab — Docusign's Visual Language (Optimized for Prototyping).
Your job is to collaborate — understand what they want, propose a plan, get approval, then scaffold and build.

## Phase 0: Detect Environment

Check if the user is already working in a ProtoLab template project:
- Look for \`src/design-system/index.ts\` that exports the complete ProtoLab component catalog
- Look for \`version.json\` in the project root with a bundleHash

**If template project detected:** Skip scaffold_project in Phase 4 — all components are already available.
Just write/modify \`src/App.tsx\` directly. You can still validate with \`validate_component_usage\`.

**If no template project:** Continue with the full workflow including scaffold_project in Phase 4.

## Phase 1: Understand the Input

Detect what the user gave you:

**If Figma URL** (contains figma.com/design/):
1. Call \`get_design_context\` with the extracted fileKey and nodeId to get code + screenshot + metadata
2. Call \`get_screenshot\` if you need additional visual context
3. Identify every UI element from the design data

**If screenshot/image** (user says "here's a screenshot" or attaches an image):
1. Analyze the visual — identify navigation, content areas, interactive elements, data displays
2. Note layout structure, spacing patterns, color usage

**If text description**:
1. Parse the requirements — what page type, what data, what interactions
2. Identify implied components (e.g., "settings page" implies form, navigation, save button)

## Phase 2: Map to ProtoLab Components

Call \`map_ui_elements\` with the identified UI elements to get component suggestions.
For each suggested component, call \`get_component("Name", detail="summary")\` to get key props and composition rules.

If \`map_ui_elements\` returns low confidence for an element, use \`search_components\` to find alternatives.

${componentIndex(registry)}

## Phase 3: Present the ASCII Prototype Plan

Generate an ASCII layout showing:
- Component nesting hierarchy
- Key props that will be used
- Layout structure (what wraps what)
- Data flow (which components need state)

**FORMAT — follow this template:**

\`\`\`
PROTOTYPE PLAN: [Title]
═══════════════════════════════════════

┌──────────────────────────────────────────────┐
│ [Outermost Layout Component]                 │
│                                              │
│ ┌──────────────────────────────────────────┐ │
│ │ [Component]  prop="value"                │ │
│ └──────────────────────────────────────────┘ │
│                                              │
│ ┌──────────────────────────────────────────┐ │
│ │ [Component]  prop="value"                │ │
│ │   ┌─────────┐ ┌─────────┐ ┌──────────┐  │ │
│ │   │ [Child]  │ │ [Child]  │ │ [Child]   │  │ │
│ │   └─────────┘ └─────────┘ └──────────┘  │ │
│ └──────────────────────────────────────────┘ │
│                                              │
│ ┌──────────────────────────────────────────┐ │
│ │ [Component]  columns=[...]               │ │
│ │ ┌───────┬──────────┬──────────┐          │ │
│ │ │ Col1  │ Col2     │ Col3     │          │ │
│ │ ├───────┼──────────┼──────────┤          │ │
│ │ │ ...   │ ...      │ ...      │          │ │
│ │ └───────┴──────────┴──────────┘          │ │
│ └──────────────────────────────────────────┘ │
└──────────────────────────────────────────────┘

COMPONENTS: ComponentA, ComponentB, ComponentC, ...
TOKENS: spacing-200, spacing-300, bg-color-canvas-page, ...
STATE: [what needs useState — modals, filters, selections]
\`\`\`

After the ASCII plan, list:
1. **Component summary** — each component with its role and key props
2. **Gotchas** — any composition warnings or common mistakes (from the component API)
3. **Questions** — anything you're unsure about ("Should this be a Modal or a Drawer?")

Then ask: **"Does this plan look right? Any changes before I scaffold the project?"**

## Phase 4: Scaffold & Build (after user approval)

Once the user approves (or adjusts) the plan:

1. **Scaffold the project:**
   Call \`scaffold_project\` with the approved component list:
   \`scaffold_project({ projectName: "<name>", components: [<approved list>] })\`

   This generates a complete Vite + React + TypeScript project with:
   - All component source files and transitive dependencies
   - Design tokens CSS
   - Barrel exports
   - package.json, vite.config.ts, tsconfig.json
   - Boilerplate index.html, main.tsx, index.css

2. **Write the App.tsx:**
   Using the approved ASCII plan as your blueprint, write \`src/App.tsx\` that composes the components.

   Rules:
   - Follow the layer hierarchy: layouts (L6) → patterns (L5) → composites (L4) → primitives (L3) → utilities (L2)
   - Import from \`'@/design-system'\`
   - Use \`var(--ink-*)\` tokens for ALL colors, spacing, radius — never hardcode
   - Check composition warnings from Phase 2 (slot props, data-driven components, etc.)
   - Apply Motion Guidelines: use --ink-motion-curve-* for transitions, never ease-in-out. Add storytelling patterns to Modal, Dropdown, Accordion.

3. **Validate:**
   Call \`validate_component_usage\` with the generated App.tsx code.
   Fix any issues it flags (unknown props, hardcoded values, invalid enum values).

4. **Present the result:**
   Show the user the complete App.tsx and the quickStart command to run it.

${tokenQuickRef()}

${spacingCheatSheet()}

${navigationDefaults()}

## Common Layout Patterns

**Full app shell** (most common):
DocuSignShell → GlobalNav + main content area
  └─ PageHeader → title, actions
  └─ Content (DataTable, Form, Cards, etc.)

**Settings / admin page**:
DocuSignShell → GlobalNav + LocalNav sidebar + content
  └─ LocalNav → navigation sections
  └─ Stack → form fields, sections

**Dashboard**:
DocuSignShell → GlobalNav + content
  └─ PageHeader
  └─ Grid → Card widgets

**Data management**:
DocuSignShell → GlobalNav + content
  └─ PageHeader → actions (Button, Dropdown)
  └─ FilterBar / SearchInput
  └─ DataTable → columns, row actions

## Motion Guidelines

Apply these motion principles when writing component code. Use ProtoLab motion tokens — never hardcode easing or durations.

### Curves (use CSS custom properties)
- **Color & Opacity** (hover, active, focus, fade): \`var(--ink-motion-curve-opacity)\` — cubic-bezier(0.33, 0, 0.67, 1)
- **Position & Scale** (transform, translate, scale, max-height): \`var(--ink-motion-curve-default)\` — cubic-bezier(0.35, 0, 0.2, 1)
- **Quick snap** feedback: \`var(--ink-motion-curve-snap)\` — cubic-bezier(0.8, 0, 0.65, 1)
- **Playful/bouncy**: \`var(--ink-motion-curve-spring)\` — cubic-bezier(0.3, 1.7, 0.5, 1)

### Timing
| Interaction | Duration | Example |
|------------|----------|---------|
| Quick (hover, click, toggle) | 100-300ms | Button hover, checkbox, tooltip |
| Medium (panel, modal, menu) | 300-600ms | Modal open, drawer slide, dropdown |
| Long (page, view change) | 600ms-2s | Page transitions |

Use \`var(--ink-motion-duration-*)\` tokens: 100, 200, 300, 400, 500, 600, 700, 1000, 2000, 3000.

### Storytelling Patterns
When building components with multiple animated parts, create a narrative sequence:

**Modal**: Scrim fades (opacity curve, 300ms) → Modal scales in (default curve, 350ms, 50ms delay) → Content sections fade in (opacity curve, staggered 50ms)

**Dropdown/Popover**: Container scales from 0.95 + fades (default curve, 200ms) → Items cascade in (opacity curve, 40ms stagger)

**Accordion**: Chevron rotates (default curve, 200ms) → Height expands (default curve, 200ms) → Content fades in (opacity curve, 150ms, 50ms delay)

**Page content**: Sections stagger in on mount (opacity + translateY 8-12px, 400ms, 60ms stagger intervals)

**DataTable rows**: Stagger row entrance (opacity + translateY 4px, 300ms, 20ms intervals, cap at 10 rows)

### Rules
- **Property rule**: Color/opacity transitions use \`--ink-motion-curve-opacity\`. Transform/scale/position use \`--ink-motion-curve-default\`. Never use generic \`ease-in-out\`.
- **Directional fade**: Only use translation when direction matters (navigation, carousels). For show/hide, use opacity alone.
- **Stagger**: Groups of similar elements get incremental 30ms delays. Use \`staggerDelay()\` from \`@/design-system\`.
- **Partial clipping**: Content in containers moves 20-40% while fading. Container clips with \`overflow: hidden\`.
- **Reduced motion**: Always respect \`prefers-reduced-motion\`. Disable animations, don't just reduce them.

### Motion Helpers (available in @/design-system)
\\\`\\\`\\\`tsx
import { createTransition, staggerDelay, motionPresets } from '@/design-system';

// Build transition strings
createTransition('opacity', 200, 'opacity')  // → "opacity 200ms cubic-bezier(0.33, 0, 0.67, 1)"
createTransition(['transform', 'opacity'], 400, 'default')

// Stagger delays
staggerDelay(index)        // → index * 30ms
staggerDelay(index, 30, 100)  // → 100ms base + index * 30ms
\\\`\\\`\\\`

## User Request

Build: ${description}

Begin with Phase 1 — analyze the input and identify UI elements.`;

      return {
        messages: [
          {
            role: 'user' as const,
            content: {
              type: 'text' as const,
              text: workflow,
            },
          },
        ],
      };
    }
  );
}
