/** Vite authoring environment used by source/test components (including import.meta.glob). */
/// <reference types="vite/client" />
