import { defineConfig } from 'vitest/config';
import path from 'node:path';

export default defineConfig({
  resolve: {
    alias: {
      '@/design-system': path.resolve(__dirname, 'protolab-source/src/design-system'),
      '@/lib/utils': path.resolve(__dirname, 'protolab-source/src/lib/utils.ts'),
      '@': path.resolve(__dirname, '.'),
    },
  },
  test: {
    include: ['tests/**/*.test.ts'],
    benchmark: {
      include: ['tests/**/*.bench.ts'],
    },
    testTimeout: 30_000,
  },
});
