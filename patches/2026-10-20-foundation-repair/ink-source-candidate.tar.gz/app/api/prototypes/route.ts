import { NextResponse } from 'next/server';

interface PrototypeBranch {
  name: string;        // full branch name: "prototype/jilly-participant-portal"
  displayName: string; // parsed: "Participant Portal"
  author: string;      // parsed from branch name: "jilly"
  date: string;        // commit date ISO string
  message: string;     // commit message
  previewUrl: string;  // constructed Vercel preview URL
}

export async function GET() {
  try {
    const headers: Record<string, string> = {
      'Accept': 'application/vnd.github+json',
    };
    if (process.env.GITHUB_TOKEN) {
      headers['Authorization'] = `Bearer ${process.env.GITHUB_TOKEN}`;
    }

    // Fetch all branches
    const res = await fetch(
      'https://api.github.com/repos/akshat10-ds/protolab-starter/branches?per_page=100',
      { headers, next: { revalidate: 60 } }
    );
    if (!res.ok) {
      return NextResponse.json({ prototypes: [], error: 'Failed to fetch branches' }, { status: 500 });
    }

    const branches = await res.json();

    // Filter to prototype/* branches
    const protoBranches = branches.filter(
      (branch: { name: string }) => branch.name.startsWith('prototype/')
    );

    // Fetch commit details in parallel (not sequentially)
    const commitResults = await Promise.all(
      protoBranches.map(async (branch: { name: string }) => {
        try {
          const commitRes = await fetch(
            `https://api.github.com/repos/akshat10-ds/protolab-starter/commits/${branch.name}`,
            { headers, next: { revalidate: 60 } }
          );
          if (!commitRes.ok) return { date: '', message: '' };
          const commit = await commitRes.json();
          return {
            date: commit.commit?.committer?.date || '',
            message: commit.commit?.message || '',
          };
        } catch {
          return { date: '', message: '' };
        }
      })
    );

    // Build prototype list from branches + commit data
    const prototypes: PrototypeBranch[] = protoBranches.map(
      (branch: { name: string }, i: number) => {
        const slug = branch.name.replace('prototype/', '');
        const parts = slug.split('-');
        const author = parts[0] || 'unknown';
        const displayName = parts.slice(1).join(' ').replace(/^\w/, (c: string) => c.toUpperCase()) || slug;

        const sanitizedBranch = branch.name.replace(/\//g, '-');
        const previewUrl = `https://protolab-starter-git-${sanitizedBranch}.vercel.app`;

        return {
          name: branch.name,
          displayName,
          author,
          date: commitResults[i].date,
          message: commitResults[i].message,
          previewUrl,
        };
      }
    );

    // Sort by date, newest first
    prototypes.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    return NextResponse.json({ prototypes }, {
      headers: { 'Cache-Control': 'public, s-maxage=60, stale-while-revalidate=120' },
    });
  } catch (error) {
    return NextResponse.json({ prototypes: [], error: 'Internal error' }, { status: 500 });
  }
}
