'use client';

import { useState, useCallback, useEffect, useRef } from 'react';
import GuideView from './guide-view';

/* ═══════════════════════════════════════
   Constants
   ═══════════════════════════════════════ */

const ENDPOINT = process.env.NEXT_PUBLIC_PROTOLAB_ENDPOINT || 'https://protolab-mcp.vercel.app/api/mcp';

const ASCII_ART = [
  '  ██████╗ ██████╗  ██████╗ ████████╗ ██████╗ ██╗      █████╗ ██████╗ ',
  '  ██╔══██╗██╔══██╗██╔═══██╗╚══██╔══╝██╔═══██╗██║     ██╔══██╗██╔══██╗',
  '  ██████╔╝██████╔╝██║   ██║   ██║   ██║   ██║██║     ███████║██████╔╝',
  '  ██╔═══╝ ██╔══██╗██║   ██║   ██║   ██║   ██║██║     ██╔══██║██╔══██╗',
  '  ██║     ██║  ██║╚██████╔╝   ██║   ╚██████╔╝███████╗██║  ██║██████╔╝',
  '  ╚═╝     ╚═╝  ╚═╝ ╚═════╝    ╚═╝    ╚═════╝ ╚══════╝╚═╝  ╚═╝╚═════╝ ',
];

const TERMINAL_LINES = [
  '$ protolab',
  '',
  ...ASCII_ART,
  '',
  '  Build Docusign prototypes for vision and ideation with AI.',
  '  63 ProtoLab Components. Your code editor does the rest.',
  '',
  '$ protolab status',
  '  ✓ MCP server   online (Claude Code, GitHub Copilot)',
  '  ✓ starter kit  63 ProtoLab Components, ready to download',
  '  ✓ prompts      plan, build, find, figma-to-code',
  '',
];

const NAV_COMMANDS = [
  { label: 'about', target: 'how-it-works' },
  { label: 'get started', target: 'prerequisites' },
  { label: 'kit', target: 'starter-kit' },
  { label: 'examples', target: 'examples' },
  { label: 'share', target: 'share' },
  { label: 'prototypes', target: '_link', href: '/prototypes' },
];

const CLIENTS = [
  {
    id: 'claude-code',
    label: 'claude code',
    file: '.mcp.json',
    config: JSON.stringify(
      { mcpServers: { 'ink-design-system': { url: ENDPOINT } } },
      null,
      2,
    ),
  },
  {
    id: 'github-copilot',
    label: 'github copilot',
    file: '.vscode/mcp.json',
    config: JSON.stringify(
      { servers: { 'ink-design-system': { type: 'http', url: ENDPOINT } } },
      null,
      2,
    ),
  },
];

const EXAMPLES = [
  { name: 'agreements-list', prompt: 'Build me an agreements list page with search, filters, and a data table' },
  { name: 'settings-page', prompt: 'I need a settings page with sidebar navigation and form sections for profile, notifications, and security' },
  { name: 'dashboard', prompt: 'Create a dashboard with 4 KPI stat cards and a recent activity table' },
  { name: 'detail-view', prompt: 'Build an agreement detail page with a status badge, document info, and action buttons' },
  { name: 'error-page', prompt: 'Design a 404 error page with a message and a button to go back home' },
  { name: 'template-gallery', prompt: 'Build a template gallery page with cards showing template previews and a search bar' },
];

/* ═══════════════════════════════════════
   Terminal Themes
   ═══════════════════════════════════════ */

interface TermTheme {
  label: string;
  bg: string; surface: string; chrome: string;
  border: string; borderSubtle: string;
  text: string; textBright: string; textDim: string; textMuted: string;
  green: string; logo: string; hover?: string; yellow?: string;
  shadow: string; logoFilter: string;
}

const THEMES: Record<string, TermTheme> = {
  dark: {
    label: 'Dark',
    bg: '#0D0D0D', surface: '#141414', chrome: '#1A1A1A',
    border: '#2A2A2A', borderSubtle: '#1F1F1F',
    text: '#B0B0B0', textBright: '#FFFFFF', textDim: '#666666', textMuted: '#4A4A4A',
    green: '#00FF85', logo: '#00FF85', hover: '#00FF85', yellow: '#FF0099',
    shadow: '0 25px 60px -12px rgba(0,0,0,0.9), 0 0 0 1px rgba(0,255,133,0.06) inset',
    logoFilter: 'brightness(0) invert(1)',
  },
  light: {
    label: 'Light',
    bg: '#F4F4F4', surface: '#FFFFFF', chrome: '#EAEAEA',
    border: '#D0D0D0', borderSubtle: '#E0E0E0',
    text: '#3B3B3B', textBright: '#0D0D0D', textDim: '#777777', textMuted: '#999999',
    green: '#00994D', logo: '#00994D', hover: '#00994D', yellow: '#CC0066',
    shadow: '0 25px 60px -12px rgba(0,0,0,0.1), 0 0 0 1px rgba(0,0,0,0.06)',
    logoFilter: 'none',
  },
};

/* ═══════════════════════════════════════
   Helpers
   ═══════════════════════════════════════ */

const isCmd = (l: string) => l.startsWith('$ ');
const isAscii = (l: string) => /[█╗╔╝╚═║]/.test(l);

/* ═══════════════════════════════════════
   Command Processor
   ═══════════════════════════════════════ */

type CmdResult = { lines: string[]; scrollTo?: string; clear?: boolean };

function processCommand(raw: string): CmdResult {
  const cmd = raw.trim().toLowerCase();

  if (!cmd) return { lines: [] };

  if (cmd === 'help') {
    return {
      lines: [
        '',
        '  Available commands:',
        '',
        '    help           show this message',
        '    how-it-works   what ProtoLab does',
        '    setup          connect your AI editor',
        '    starter-kit    download the starter project',
        '    examples       browse example prompts',
        '    clear          clear terminal',
        '',
      ],
    };
  }
  if (cmd === 'how-it-works' || cmd === 'how') {
    return { lines: ['  → scrolling to how-it-works...', ''], scrollTo: 'how-it-works' };
  }
  if (cmd === 'setup' || cmd.startsWith('setup ')) {
    return { lines: ['  → scrolling to setup...', ''], scrollTo: 'setup' };
  }
  if (cmd === 'starter-kit' || cmd === 'download' || cmd === 'starter') {
    return { lines: ['  → scrolling to starter-kit...', ''], scrollTo: 'starter-kit' };
  }
  if (cmd === 'examples') {
    return { lines: ['  → scrolling to examples...', ''], scrollTo: 'examples' };
  }
  if (cmd === 'clear') {
    return { lines: [], clear: true };
  }
  if (cmd === 'whoami') {
    return {
      lines: [
        '  Built by Akshat Mishra',
        '  Design Systems × Developer Tools',
        '',
      ],
    };
  }
  if (cmd.startsWith('sudo')) {
    return { lines: ['  Permission denied. This is a read-only terminal.', ''] };
  }
  if (cmd === 'status') {
    return {
      lines: [
        '  ✓ server      online at protolab-mcp.vercel.app/api/mcp',
        '  ✓ components  63 loaded (tokens → layouts)',
        '  ✓ transport   Streamable HTTP',
        '',
      ],
    };
  }

  return {
    lines: [
      `  command not found: ${cmd}`,
      '  Type "help" for available commands.',
      '',
    ],
  };
}

/* ═══════════════════════════════════════
   Theme Hook
   ═══════════════════════════════════════ */

function applyTheme(id: string) {
  const t = THEMES[id];
  if (!t) return;
  const root = document.documentElement;
  root.style.setProperty('--t-bg', t.bg);
  root.style.setProperty('--t-surface', t.surface);
  root.style.setProperty('--t-chrome', t.chrome);
  root.style.setProperty('--t-border', t.border);
  root.style.setProperty('--t-border-subtle', t.borderSubtle);
  root.style.setProperty('--t-text', t.text);
  root.style.setProperty('--t-text-bright', t.textBright);
  root.style.setProperty('--t-text-dim', t.textDim);
  root.style.setProperty('--t-text-muted', t.textMuted);
  root.style.setProperty('--t-green', t.green);
  root.style.setProperty('--t-amber', t.green);
  root.style.setProperty('--t-blue', t.green);
  root.style.setProperty('--t-cyan', t.green);
  root.style.setProperty('--t-pink', t.green);
  root.style.setProperty('--t-orange', t.green);
  root.style.setProperty('--t-purple', t.green);
  root.style.setProperty('--t-logo', t.logo);
  root.style.setProperty('--t-hover', t.hover ?? t.green);
  root.style.setProperty('--t-yellow', t.yellow ?? t.logo);
  root.style.setProperty('--t-shadow-terminal', t.shadow);
  root.style.setProperty('--t-logo-filter', t.logoFilter);
  // For selection color and light-mode overrides
  root.setAttribute('data-theme', id === 'light' ? 'light' : 'dark');
}

function useTheme() {
  const [themeId, setThemeId] = useState('dark');

  useEffect(() => {
    const saved = localStorage.getItem('protolab-theme-id');
    if (saved && THEMES[saved]) {
      setThemeId(saved);
      applyTheme(saved);
    }
  }, []);

  const setTheme = useCallback((id: string) => {
    setThemeId(id);
    applyTheme(id);
    localStorage.setItem('protolab-theme-id', id);
  }, []);

  return { themeId, setTheme };
}

/* ═══════════════════════════════════════
   Typewriter Hook
   ═══════════════════════════════════════ */

function useTypewriter(sequence: string[]) {
  const [lines, setLines] = useState<string[]>([]);
  const [typing, setTyping] = useState('');
  const [done, setDone] = useState(false);
  const skipRef = useRef(false);

  const skip = useCallback(() => {
    skipRef.current = true;
    setLines([...sequence]);
    setTyping('');
    setDone(true);
  }, [sequence]);

  useEffect(() => {
    skipRef.current = false;
    let cancelled = false;
    let tid: ReturnType<typeof setTimeout>;

    const wait = (ms: number) =>
      new Promise<void>((r) => {
        tid = setTimeout(r, ms);
      });

    async function run() {
      await wait(400);

      for (let i = 0; i < sequence.length; i++) {
        if (cancelled || skipRef.current) return;
        const line = sequence[i];

        if (isCmd(line)) {
          for (let j = 1; j <= line.length; j++) {
            if (cancelled || skipRef.current) return;
            setTyping(line.slice(0, j));
            await wait(30 + Math.random() * 25);
          }
          setTyping('');
          setLines((p) => [...p, line]);
          await wait(300);
        } else if (isAscii(line)) {
          setLines((p) => [...p, line]);
          await wait(18);
        } else if (line === '') {
          setLines((p) => [...p, line]);
          await wait(10);
        } else if (line.includes('✓')) {
          setLines((p) => [...p, line]);
          await wait(120);
        } else {
          setLines((p) => [...p, line]);
          await wait(60);
        }
      }

      if (!cancelled && !skipRef.current) setDone(true);
    }

    run();
    return () => {
      cancelled = true;
      clearTimeout(tid);
    };
  }, [sequence]);

  return { lines, typing, done, skip };
}

/* ═══════════════════════════════════════
   Line Renderer
   ═══════════════════════════════════════ */

function TermLine({ text }: { text: string }) {
  if (text === '') return <br />;

  if (isCmd(text)) {
    return (
      <div style={st.line}>
        <span style={{ color: 'var(--t-green)' }}>$ </span>
        <span style={{ color: 'var(--t-text-bright)' }}>{text.slice(2)}</span>
      </div>
    );
  }

  if (isAscii(text)) {
    return (
      <div
        className="ascii-art"
        style={{ ...st.line, color: 'var(--t-logo)', lineHeight: '1.15', opacity: 0.8 }}
      >
        {text}
      </div>
    );
  }

  if (text.includes('✓')) {
    const m = text.match(/^(\s*)(✓)(\s+\S+)(\s+)(.*)/);
    if (m) {
      return (
        <div style={st.line}>
          {m[1]}
          <span style={{ color: 'var(--t-green)' }}>{m[2]}</span>
          <span style={{ color: 'var(--t-text-dim)' }}>{m[3]}</span>
          {m[4]}
          <span>{m[5]}</span>
        </div>
      );
    }
  }

  if (text.includes('→') || text.includes('·')) {
    return (
      <div style={{ ...st.line, color: 'var(--t-amber)' }}>{text}</div>
    );
  }

  return <div style={st.line}>{text}</div>;
}

/* ═══════════════════════════════════════
   JSON Syntax Highlighter
   ═══════════════════════════════════════ */

function HighlightedJSON({ code }: { code: string }) {
  return (
    <>
      {code.split('\n').map((line, i) => (
        <div key={i} style={{ minHeight: '1.4em' }}>
          <JSONLine text={line} />
        </div>
      ))}
    </>
  );
}

function JSONLine({ text }: { text: string }) {
  // key: "value"
  const kv = text.match(/^(\s*)"([^"]+)"(\s*:\s*)"([^"]*)"(.*)/);
  if (kv) {
    return (
      <>
        {kv[1]}
        <span style={{ color: 'var(--t-blue)' }}>&quot;{kv[2]}&quot;</span>
        <span style={{ color: 'var(--t-text-dim)' }}>{kv[3]}</span>
        <span style={{ color: 'var(--t-green)' }}>&quot;{kv[4]}&quot;</span>
        <span style={{ color: 'var(--t-text-dim)' }}>{kv[5]}</span>
      </>
    );
  }

  // key: { or key: [
  const ko = text.match(/^(\s*)"([^"]+)"(\s*:\s*)(.*)/);
  if (ko) {
    return (
      <>
        {ko[1]}
        <span style={{ color: 'var(--t-blue)' }}>&quot;{ko[2]}&quot;</span>
        <span style={{ color: 'var(--t-text-dim)' }}>{ko[3]}{ko[4]}</span>
      </>
    );
  }

  // braces / brackets
  if (/^\s*[{}[\],]/.test(text)) {
    return <span style={{ color: 'var(--t-text-dim)' }}>{text}</span>;
  }

  return <>{text}</>;
}

/* ═══════════════════════════════════════
   Components
   ═══════════════════════════════════════ */

function CopyButton({ text, label = 'copy' }: { text: string; label?: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = useCallback(() => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }, [text]);

  return (
    <button onClick={handleCopy} className="copy-btn" style={st.copyBtn}>
      {copied ? (
        <span style={{ color: 'var(--t-green)' }}>copied ✓</span>
      ) : (
        <span>{label}</span>
      )}
    </button>
  );
}

/* ─── Terminal Hero ─── */

function TerminalHero({ themeId, onSetTheme }: { themeId: string; onSetTheme: (id: string) => void }) {
  const toggleTheme = () => onSetTheme(themeId === 'dark' ? 'light' : 'dark');
  const { lines: introLines, typing, done, skip } = useTypewriter(TERMINAL_LINES);
  const [extraLines, setExtraLines] = useState<string[]>([]);
  const [input, setInput] = useState('');
  const [showIntro, setShowIntro] = useState(true);
  const bodyRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const visibleLines = [...(showIntro ? introLines : []), ...extraLines];

  // Auto-scroll terminal
  useEffect(() => {
    if (bodyRef.current) {
      bodyRef.current.scrollTop = bodyRef.current.scrollHeight;
    }
  }, [visibleLines, typing, extraLines]);

  // Auto-focus input when animation completes
  useEffect(() => {
    if (done) inputRef.current?.focus();
  }, [done]);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cmd = input;
    setInput('');
    const result = processCommand(cmd);

    if (result.clear) {
      setShowIntro(false);
      setExtraLines([]);
      return;
    }

    setExtraLines((prev) => [...prev, `$ ${cmd}`, ...result.lines]);

    if (result.scrollTo) {
      setTimeout(() => scrollTo(result.scrollTo!), 300);
    }
  };

  const focusInput = () => {
    if (done) inputRef.current?.focus();
  };

  return (
    <section style={st.heroSection}>
      <div style={st.terminal} onClick={!done ? skip : focusInput}>
        {/* Title bar */}
        <div style={st.titleBar}>
          <div style={st.dots}>
            <span style={{ ...st.dot, background: '#FF5F57' }} />
            <span style={{ ...st.dot, background: '#FFBD2E' }} />
            <span style={{ ...st.dot, background: '#28CA41' }} />
          </div>
          <div style={st.titleCenter}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/docusign-logo.svg" alt="Docusign" style={st.titleLogo} />
            <span style={st.titleText}>protolab — zsh — 80×24</span>
          </div>
          <button
            className="theme-toggle"
            onClick={(e) => { e.stopPropagation(); toggleTheme(); }}
            style={st.themeToggle}
            aria-label="Toggle theme"
          >
            {themeId === 'dark' ? (
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
            ) : (
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
            )}
          </button>
        </div>

        {/* Body */}
        <div ref={bodyRef} className="term-body" style={st.termBody}>
          {visibleLines.map((line, i) => (
            <TermLine key={i} text={line} />
          ))}

          {/* Currently typing (during animation) */}
          {typing && (
            <div style={st.line}>
              <span style={{ color: 'var(--t-green)' }}>$ </span>
              <span style={{ color: 'var(--t-text-bright)' }}>{typing.slice(2)}</span>
              <span style={st.cursor}>▋</span>
            </div>
          )}

          {/* Interactive input (after animation) */}
          {done && !typing && (
            <form onSubmit={handleSubmit} style={st.inputLine}>
              <span style={{ color: 'var(--t-green)' }}>$ </span>
              <input
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                style={st.termInput}
                spellCheck={false}
                autoComplete="off"
                autoCapitalize="off"
                aria-label="Terminal input"
              />
            </form>
          )}
        </div>

        {/* Nav commands */}
        {done && (
          <div style={st.commandBar}>
            {NAV_COMMANDS.map((c) =>
              'href' in c && c.href ? (
                <a
                  key={c.label}
                  href={c.href}
                  className="term-cmd"
                  style={{ ...st.cmdBtn, textDecoration: 'none' }}
                >
                  <span style={{ color: 'var(--t-text-dim)' }}>[</span>
                  {c.label}
                  <span style={{ color: 'var(--t-text-dim)' }}>]</span>
                </a>
              ) : (
                <button
                  key={c.label}
                  className="term-cmd"
                  onClick={(e) => {
                    e.stopPropagation();
                    scrollTo(c.target);
                  }}
                  style={st.cmdBtn}
                >
                  <span style={{ color: 'var(--t-text-dim)' }}>[</span>
                  {c.label}
                  <span style={{ color: 'var(--t-text-dim)' }}>]</span>
                </button>
              )
            )}
            <span style={st.cmdHint}>or type a command</span>
          </div>
        )}
      </div>

      {/* Skip hint / scroll indicator */}
      {!done && <div style={st.skipHint}>click to skip</div>}
      {done && (
        <button
          className="scroll-more"
          onClick={() => scrollTo('how-it-works')}
          style={st.scrollMore}
        >
          ↓ scroll for more
        </button>
      )}
    </section>
  );
}

/* ─── Section Heading ─── */

function SectionHeading({ step, title, subtitle }: { step: string; title: string; subtitle: string }) {
  return (
    <div style={{ marginBottom: 32 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 10 }}>
        <span style={st.stepBadge}>{step}</span>
        <h2 style={st.h2}>{title}</h2>
      </div>
      <p style={st.subtitle}>{subtitle}</p>
    </div>
  );
}

/* ─── How It Works ─── */

function HowItWorksSection() {
  return (
    <section id="how-it-works" style={st.section}>
      <h2 style={{ ...st.h2, fontSize: 26, marginBottom: 14 }}>What is ProtoLab?</h2>
      <p style={st.subtitle}>
        ProtoLab gives AI code editors like Claude Code and GitHub Copilot
        knowledge of Docusign&apos;s Visual Language (Optimized for Prototyping) — 63 ProtoLab Components, from buttons to
        full page layouts. Describe what you want, and it builds it with the right
        components, tokens, and composition patterns.
      </p>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 0, marginTop: 32 }}>
        {[
          {
            num: '01',
            title: 'You describe what you need',
            body: '"Build me an agreements list page with search, filters, and a data table."',
            color: 'var(--t-green)',
          },
          {
            num: '02',
            title: 'Your code editor knows the system',
            body: 'It picks the right components, sets the correct props, applies design tokens, and follows Docusign layout patterns.',
            color: 'var(--t-green)',
          },
          {
            num: '03',
            title: 'You get working code',
            body: 'High-fidelity scaffolding for rapid prototyping — not a mockup, not a wireframe. Components optimized for prototyping (not for production use).',
            color: 'var(--t-green)',
          },
        ].map((step) => (
          <div key={step.num} style={st.stepRow}>
            <span style={{ ...st.stepNum, color: step.color }}>{step.num}</span>
            <div>
              <div style={st.stepTitle}>{step.title}</div>
              <div style={st.stepBody}>{step.body}</div>
            </div>
          </div>
        ))}
      </div>

      <div style={{ marginTop: 56, marginBottom: 8 }}>
        <h2 style={{ ...st.h2, fontSize: 28 }}>Get started</h2>
      </div>
      <p style={{ ...st.subtitle, marginBottom: 0 }}>
        Check the prerequisites, download the starter kit, and start prompting.
      </p>
    </section>
  );
}

/* ─── Prerequisites ─── */

function PrerequisitesSection() {
  const checks = [
    {
      name: 'VS Code',
      desc: 'Free code editor — you won\'t write code, but the AI runs inside it.',
      link: 'https://code.visualstudio.com',
      linkText: 'Download VS Code',
    },
    {
      name: 'Claude Code extension',
      desc: 'The AI that builds your prototypes. Install it from the VS Code marketplace.',
      link: 'https://marketplace.visualstudio.com/items?itemName=anthropic.claude-code',
      linkText: 'Install Claude Code',
    },
    {
      name: 'Node.js',
      desc: 'Runs the prototype locally on your computer. Grab the LTS version.',
      link: 'https://nodejs.org',
      linkText: 'Download Node.js',
    },
  ];

  return (
    <section id="prerequisites" style={st.section}>
      <SectionHeading
        step="0"
        title="Before you start"
        subtitle="You need these three things installed. If you already have them, skip to the next step."
      />
      <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
        {checks.map((check) => (
          <div key={check.name} style={st.miniStep}>
            <span style={{
              width: 28, height: 28, display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 14, color: 'var(--t-green)', flexShrink: 0,
            }}>
              ✓
            </span>
            <div>
              <div style={st.miniStepTitle}>{check.name}</div>
              <div style={{ fontSize: 14, color: 'var(--t-text)', lineHeight: 1.6, marginBottom: 6 }}>
                {check.desc}
              </div>
              <a
                href={check.link}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  fontSize: 13, color: 'var(--t-green)', textDecoration: 'none',
                  fontFamily: 'var(--t-font)', transition: 'opacity 0.15s',
                }}
              >
                {check.linkText} &rarr;
              </a>
            </div>
          </div>
        ))}
      </div>
      <div style={{
        marginTop: 24, padding: '14px 18px',
        background: 'var(--t-surface)', border: '1px solid var(--t-border)',
        borderRadius: 'var(--t-radius-sm)', fontSize: 13, color: 'var(--t-text)', lineHeight: 1.7,
      }}>
        <span style={{ color: 'var(--t-green)', marginRight: 8 }}>tip</span>
        Don&apos;t worry about Git or GitHub yet — you only need those when you want to
        share your prototype with the team. We&apos;ll cover that later.
      </div>
    </section>
  );
}

/* ─── Share & Collaborate ─── */

function ShareSection() {
  return (
    <section id="share" style={st.section}>
      <h2 style={{ ...st.h2, fontSize: 26, marginBottom: 14 }}>Share with your team</h2>
      <p style={st.subtitle}>
        Once you&apos;ve built something, share it with a live preview URL.
        Your team can browse, fork, and build on each other&apos;s prototypes.
      </p>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 0, marginTop: 32 }}>
        {[
          {
            num: '01',
            title: 'Deploy your prototype',
            body: 'Type /deploy in Claude Code. It pushes your work to a live Vercel URL you can share with anyone.',
          },
          {
            num: '02',
            title: 'Browse the gallery',
            body: 'Every deployed prototype appears in the gallery at /prototypes. See what others have built, filter by author or page type.',
          },
          {
            num: '03',
            title: 'Fork and iterate',
            body: 'See a prototype you like? Type /fork to create your own copy and start building on it. No starting from scratch.',
          },
        ].map((step) => (
          <div key={step.num} style={st.stepRow}>
            <span style={{ ...st.stepNum, color: 'var(--t-green)' }}>{step.num}</span>
            <div>
              <div style={st.stepTitle}>{step.title}</div>
              <div style={st.stepBody}>{step.body}</div>
            </div>
          </div>
        ))}
      </div>

      <div style={{
        marginTop: 32, padding: '14px 18px',
        background: 'var(--t-surface)', border: '1px solid var(--t-border)',
        borderRadius: 'var(--t-radius-sm)', fontSize: 13, color: 'var(--t-text)', lineHeight: 1.7,
      }}>
        <span style={{ color: 'var(--t-green)', marginRight: 8 }}>note</span>
        Deploying requires Git and a GitHub account. If you haven&apos;t set that up,
        Claude Code will walk you through it when you type <code style={st.inlineCode}>/deploy</code>.
      </div>
    </section>
  );
}

/* ─── Available Commands ─── */

function CommandsSection() {
  const commands = [
    { cmd: '/deploy', desc: 'Push your prototype to a shareable Vercel preview URL.' },
    { cmd: '/fork', desc: 'Copy someone else\'s prototype and build on top of it.' },
    { cmd: '/handoff', desc: 'Generate a HANDOFF.md for engineers with component inventory and migration guide.' },
    { cmd: '/update', desc: 'Check if your design system components are up to date and refresh them.' },
    { cmd: '/onboard', desc: 'Verify your setup is correct — checks dependencies, MCP connection, and dev server.' },
  ];

  return (
    <section id="commands" style={st.section}>
      <h2 style={{ ...st.h2, fontSize: 26, marginBottom: 14 }}>Commands you can use</h2>
      <p style={st.subtitle}>
        Type these in Claude Code to trigger workflows. They&apos;re built-in skills
        that handle the hard parts for you.
      </p>

      <div style={{ marginTop: 24, display: 'flex', flexDirection: 'column', gap: 0 }}>
        {commands.map((c) => (
          <div key={c.cmd} style={{
            display: 'flex', gap: 16, padding: '12px 0',
            borderBottom: '1px solid var(--t-border-subtle)',
          }}>
            <code style={{
              ...st.inlineCode, flexShrink: 0, minWidth: 100,
              textAlign: 'center',
            }}>
              {c.cmd}
            </code>
            <span style={{ fontSize: 14, color: 'var(--t-text)', lineHeight: 1.6, paddingTop: 4 }}>
              {c.desc}
            </span>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ─── Setup (Path A) ─── */

function SetupSection() {
  const [active, setActive] = useState('claude-code');
  const client = CLIENTS.find((c) => c.id === active)!;

  return (
    <section id="setup" style={st.section}>
      <div style={{ marginBottom: 32 }}>
        <h2 style={st.h2}>Add to an existing project</h2>
        <p style={st.subtitle}>
          Already have a project? Add this config file to connect your editor to ProtoLab&apos;s
          component intelligence — search, validation, and scaffolding.
          <span style={{ display: 'block', marginTop: 8, fontSize: 13, color: 'var(--t-text-muted)' }}>
            Skip this if you downloaded the starter kit — it&apos;s already configured.
          </span>
        </p>
      </div>

      <div style={st.tabs}>
        {CLIENTS.map((c) => (
          <button
            key={c.id}
            className="tab-btn"
            onClick={() => setActive(c.id)}
            style={{
              ...st.tab,
              ...(active === c.id ? st.tabActive : {}),
            }}
          >
            {c.label}
          </button>
        ))}
      </div>

      <div style={st.codeBlock}>
        <div style={st.codeHeader}>
          <span style={st.codeComment}># {client.file}</span>
          <CopyButton text={client.config} />
        </div>
        <pre style={st.pre}>
          <HighlightedJSON code={client.config} />
        </pre>
      </div>

      <p style={st.hint}>Paste this into the config file, restart your editor, and you&apos;re connected.</p>
    </section>
  );
}

/* ─── Starter Kit (Path B) ─── */

function StarterKitSection() {
  return (
    <section id="starter-kit" style={st.section}>
      <SectionHeading
        step="1"
        title="Download the Starter Kit"
        subtitle="A complete project with all 63 ProtoLab components pre-installed. The AI connection is already configured — just open it and start prompting."
      />

      <div style={st.stepsGrid}>
        <div style={st.miniStep}>
          <span style={st.miniStepNum}>a</span>
          <div>
            <div style={st.miniStepTitle}>Download &amp; unzip</div>
            <a
              href="vscode://vscode.git/clone?url=https://github.com/akshat10-ds/protolab-starter.git"
              className="download-btn"
              style={{
                ...st.downloadBtn,
                marginTop: 8,
                background: 'var(--t-green)',
                color: '#1E1D1C',
                fontWeight: 600,
              }}
            >
              Open in VS Code
            </a>
            <a
              href="/downloads/ink-starter-kit.zip"
              download
              className="download-btn"
              style={{ ...st.downloadBtn, marginTop: 6, background: 'var(--t-surface)', color: 'var(--t-text)', border: '1px solid var(--t-border)' }}
            >
              ↓ starter-kit.zip
            </a>
            <div style={{ ...st.hint, marginTop: 6 }}>~0.7 MB</div>
            <a
              href="/prototypes"
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: 4,
                marginTop: 8,
                fontSize: 12,
                color: 'var(--t-text-dim)',
                textDecoration: 'none',
                fontFamily: 'var(--t-font)',
                transition: 'color 0.15s',
              }}
            >
              Browse prototypes &rarr;
            </a>
          </div>
        </div>
        <div style={st.miniStep}>
          <span style={st.miniStepNum}>b</span>
          <div>
            <div style={st.miniStepTitle}>Install &amp; run</div>
            <code style={st.inlineCode}>npm install &amp;&amp; npm run dev</code>
          </div>
        </div>
        <div style={st.miniStep}>
          <span style={st.miniStepNum}>c</span>
          <div>
            <div style={st.miniStepTitle}>Prompt your editor</div>
            <div style={{ ...st.hint, marginTop: 4 }}>Open the project in your AI code editor and try:</div>
          </div>
        </div>
      </div>

      <div style={{ marginTop: 16 }}>
        <div style={{ ...st.codeBlock, borderTop: '1px solid var(--t-border)', borderRadius: 'var(--t-radius-sm)' }}>
          <div style={st.codeHeader}>
            <span style={{ ...st.codeComment, color: 'var(--t-text-dim)' }}>Try this prompt in your AI code editor</span>
            <CopyButton text="Build me an agreements list page with a data table, search bar, filters, and status badges. Use DocuSignShell with GlobalNav and LocalNav." />
          </div>
          <pre style={{ ...st.pre, padding: '14px 20px', fontSize: 14 }}>
            <span style={{ color: 'var(--t-text-dim)' }}>&quot;</span>
            <span style={{ color: 'var(--t-text-bright)' }}>Build me an agreements list page with a data table, search bar,{'\n'}filters, and status badges. Use DocuSignShell with GlobalNav{'\n'}and LocalNav.</span>
            <span style={{ color: 'var(--t-text-dim)' }}>&quot;</span>
          </pre>
        </div>
      </div>
    </section>
  );
}

/* ─── Examples ─── */

function ExamplesSection() {
  const [copiedName, setCopiedName] = useState<string | null>(null);

  const copy = (name: string, prompt: string) => {
    navigator.clipboard.writeText(prompt);
    setCopiedName(name);
    setTimeout(() => setCopiedName(null), 2000);
  };

  return (
    <section id="examples" style={st.section}>
      <h2 style={{ ...st.h2, marginBottom: 8 }}>Example Prompts</h2>
      <p style={{ ...st.subtitle, marginBottom: 24 }}>Try these after downloading or connecting. Click to copy.</p>

      <div style={st.exList}>
        {EXAMPLES.map((ex) => (
          <button
            key={ex.name}
            className="example-row"
            onClick={() => copy(ex.name, ex.prompt)}
            style={st.exRow}
          >
            <span style={st.exName}>{ex.name}</span>
            <span style={st.exPrompt}>&ldquo;{ex.prompt}&rdquo;</span>
            {copiedName === ex.name && (
              <span style={st.exCopied}>copied</span>
            )}
          </button>
        ))}
      </div>
    </section>
  );
}

/* ═══════════════════════════════════════
   Page
   ═══════════════════════════════════════ */

function TerminalView({ onSwitchMode }: { onSwitchMode: () => void }) {
  const { themeId, setTheme } = useTheme();

  return (
    <div>
      <TerminalHero themeId={themeId} onSetTheme={setTheme} />

      <div style={st.content}>
        <HowItWorksSection />
        <PrerequisitesSection />
        <StarterKitSection />
        <ExamplesSection />
        <ShareSection />
        <CommandsSection />
        <SetupSection />

        <footer style={st.footer}>
          <span style={{ color: 'var(--t-text-dim)' }}>protolab v1.0.0</span>
          <span style={{ color: 'var(--t-text-muted)' }}>·</span>
          <span style={{ color: 'var(--t-text-dim)' }}>built by <span style={{ color: 'var(--t-green)' }}>Akshat Mishra</span></span>
          <span style={{ color: 'var(--t-text-muted)' }}>·</span>
          <button onClick={onSwitchMode} style={{ ...st.footerLink, marginLeft: 8 }}>
            guide mode
          </button>
          <span style={{ color: 'var(--t-text-muted)' }}>·</span>
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            style={st.footerLink}
          >
            ↑ top
          </button>
        </footer>
      </div>
    </div>
  );
}

export default function Home() {
  const [mode, setMode] = useState<'guide' | 'terminal'>('terminal');

  const switchMode = useCallback((newMode: 'guide' | 'terminal') => {
    setMode(newMode);
    try { localStorage.setItem('protolab-view-mode', newMode); } catch { /* ignore */ }
    window.scrollTo({ top: 0 });
  }, []);

  if (mode === 'terminal') {
    return <TerminalView onSwitchMode={() => switchMode('guide')} />;
  }

  return <GuideView onSwitchMode={() => switchMode('terminal')} />;
}

/* ═══════════════════════════════════════
   Styles
   ═══════════════════════════════════════ */

const st: Record<string, React.CSSProperties> = {
  /* Hero */
  heroSection: {
    minHeight: '100vh',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '40px 24px',
  },

  /* Terminal window */
  terminal: {
    width: '100%',
    maxWidth: 780,
    borderRadius: 'var(--t-radius)',
    overflow: 'hidden',
    border: '1px solid var(--t-border)',
    boxShadow: 'var(--t-shadow-terminal)',
  },
  titleBar: {
    display: 'flex',
    alignItems: 'center',
    padding: '12px 16px',
    background: 'var(--t-chrome)',
    borderBottom: '1px solid var(--t-border-subtle)',
  },
  dots: { display: 'flex', gap: 8, marginRight: 16 },
  dot: { width: 12, height: 12, borderRadius: '50%' },
  titleCenter: {
    flex: 1,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  titleLogo: {
    height: 14,
    opacity: 0.6,
    filter: 'var(--t-logo-filter, none)',
  },
  titleText: {
    textAlign: 'center' as const,
    fontSize: 12,
    color: 'var(--t-text-dim)',
    letterSpacing: '0.02em',
  },
  themeToggle: {
    width: 32,
    height: 24,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    background: 'transparent',
    border: '1px solid var(--t-border)',
    borderRadius: 'var(--t-radius-sm)',
    color: 'var(--t-text-dim)',
    fontSize: 14,
    cursor: 'pointer',
    fontFamily: 'var(--t-font)',
    transition: 'border-color 0.15s, color 0.15s',
    lineHeight: 1,
  },
  termBody: {
    padding: '20px 24px',
    background: 'var(--t-surface)',
    fontSize: 14,
    lineHeight: 1.5,
    fontFamily: 'var(--t-font)',
    minHeight: 400,
    overflowY: 'auto' as const,
  },
  line: { whiteSpace: 'pre' as const, minHeight: '1.5em' },
  cursor: {
    animation: 'blink 1s step-end infinite',
    color: 'var(--t-green)',
  },

  /* Command bar */
  commandBar: {
    display: 'flex',
    gap: 4,
    padding: '12px 24px',
    background: 'var(--t-chrome)',
    borderTop: '1px solid var(--t-border-subtle)',
    animation: 'fadeInUp 0.4s ease',
  },
  cmdBtn: {
    padding: '6px 14px',
    background: 'transparent',
    border: 'none',
    color: 'var(--t-blue)',
    fontSize: 13,
    fontFamily: 'var(--t-font)',
    cursor: 'pointer',
    borderRadius: 'var(--t-radius-sm)',
    whiteSpace: 'nowrap' as const,
    transition: 'background 0.15s',
  },
  skipHint: {
    marginTop: 16,
    fontSize: 12,
    color: 'var(--t-text-muted)',
    opacity: 0,
    animationName: 'fadeInUp',
    animationDuration: '0.3s',
    animationTimingFunction: 'ease',
    animationDelay: '2s',
    animationFillMode: 'forwards' as const,
  },

  /* Interactive input */
  inputLine: {
    display: 'flex',
    alignItems: 'center',
    whiteSpace: 'pre' as const,
    minHeight: '1.5em',
  },
  termInput: {
    background: 'transparent',
    border: 'none',
    outline: 'none',
    color: 'var(--t-text-bright)',
    fontSize: 14,
    fontFamily: 'var(--t-font)',
    flex: 1,
    caretColor: 'var(--t-green)',
    lineHeight: 1.5,
    padding: 0,
  },
  cmdHint: {
    marginLeft: 'auto',
    fontSize: 12,
    color: 'var(--t-text-muted)',
    fontStyle: 'italic' as const,
  },

  /* Scroll indicator */
  scrollMore: {
    marginTop: 24,
    padding: '8px 16px',
    background: 'none',
    border: 'none',
    color: 'var(--t-yellow)',
    fontSize: 13,
    fontFamily: 'var(--t-font)',
    cursor: 'pointer',
    animation: 'pulse 2.5s ease-in-out infinite, gentleBounce 2.5s ease-in-out infinite',
    transition: 'color 0.15s',
    letterSpacing: '0.05em',
  },

  /* Content */
  content: {
    maxWidth: 720,
    margin: '0 auto',
    padding: '0 24px',
  },

  /* Sections */
  section: {
    paddingTop: 72,
    paddingBottom: 72,
  },
  h2: {
    fontSize: 22,
    fontWeight: 700,
    color: 'var(--t-yellow, var(--t-text-bright))',
    letterSpacing: '-0.02em',
  },
  subtitle: {
    fontSize: 16,
    color: 'var(--t-text-bright)',
    opacity: 0.65,
    lineHeight: 1.75,
    maxWidth: 620,
  },
  stepBadge: {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    width: 28,
    height: 28,
    borderRadius: 'var(--t-radius-sm)',
    background: 'var(--t-chrome)',
    border: '1px solid var(--t-border)',
    fontSize: 13,
    fontWeight: 700,
    color: 'var(--t-yellow, var(--t-green))',
    flexShrink: 0,
  },
  sectionRule: {
    height: 1,
    background: 'var(--t-border)',
    marginTop: 12,
  },

  /* How it works — numbered steps */
  stepRow: {
    display: 'flex',
    gap: 16,
    padding: '16px 0',
  },
  stepNum: {
    fontSize: 20,
    fontWeight: 700,
    lineHeight: 1,
    paddingTop: 2,
    flexShrink: 0,
    width: 28,
    textAlign: 'right' as const,
  },
  stepTitle: {
    fontSize: 16,
    fontWeight: 700,
    color: 'var(--t-text-bright)',
    marginBottom: 6,
  },
  stepBody: {
    fontSize: 15,
    color: 'var(--t-text-bright)',
    lineHeight: 1.7,
    opacity: 0.7,
  },

  /* Path cards */
  pathDivider: {
    display: 'flex',
    alignItems: 'center',
    gap: 16,
    marginTop: 48,
    marginBottom: 24,
  },
  pathCard: {
    flex: 1,
    padding: '20px',
    background: 'var(--t-surface)',
    border: '1px solid var(--t-border)',
    borderRadius: 'var(--t-radius)',
    cursor: 'pointer',
    textAlign: 'left' as const,
    fontFamily: 'var(--t-font)',
    transition: 'border-color 0.2s, background 0.2s',
  },
  pathIcon: {
    fontSize: 16,
    fontWeight: 700,
    display: 'block',
    marginBottom: 10,
  },
  pathTitle: {
    fontSize: 14,
    fontWeight: 600,
    color: 'var(--t-text-bright)',
    marginBottom: 6,
  },
  pathBody: {
    fontSize: 14,
    color: 'var(--t-text)',
    lineHeight: 1.7,
    marginBottom: 12,
  },
  pathBest: {
    fontSize: 11,
    color: 'var(--t-text-muted)',
    textTransform: 'uppercase' as const,
    letterSpacing: '0.08em',
  },

  /* Mini-steps (starter kit) */
  stepsGrid: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: 0,
  },
  miniStep: {
    display: 'flex',
    gap: 16,
    padding: '16px 0',
  },
  miniStepNum: {
    width: 28,
    height: 28,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: '50%',
    background: 'var(--t-chrome)',
    border: '1px solid var(--t-border)',
    fontSize: 13,
    fontWeight: 600,
    color: 'var(--t-yellow, var(--t-green))',
    flexShrink: 0,
  },
  miniStepTitle: {
    fontSize: 15,
    fontWeight: 700,
    color: 'var(--t-text-bright)',
    marginBottom: 6,
  },
  inlineCode: {
    display: 'inline-block',
    padding: '6px 12px',
    background: 'var(--t-surface)',
    border: '1px solid var(--t-border)',
    borderRadius: 'var(--t-radius-sm)',
    fontSize: 13,
    fontFamily: 'var(--t-font)',
    color: 'var(--t-cyan)',
  },

  /* Tabs */
  tabs: {
    display: 'flex',
    gap: 2,
    borderBottom: '1px solid var(--t-border)',
    marginBottom: 0,
  },
  tab: {
    padding: '10px 18px',
    fontSize: 13,
    fontWeight: 500,
    color: 'var(--t-text-dim)',
    background: 'transparent',
    border: 'none',
    borderBottomWidth: 2,
    borderBottomStyle: 'solid' as const,
    borderBottomColor: 'transparent',
    cursor: 'pointer',
    fontFamily: 'var(--t-font)',
    transition: 'color 0.15s, border-color 0.15s',
  },
  tabActive: {
    color: 'var(--t-text-bright)',
    borderBottomColor: 'var(--t-green)',
  },

  /* Code */
  codeBlock: {
    border: '1px solid var(--t-border)',
    borderTop: 'none',
    borderRadius: '0 0 var(--t-radius-sm) var(--t-radius-sm)',
    overflow: 'hidden',
    marginBottom: 16,
  },
  codeHeader: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '10px 16px',
    background: 'var(--t-chrome)',
    borderBottom: '1px solid var(--t-border-subtle)',
  },
  codeComment: {
    fontSize: 12,
    color: 'var(--t-text-dim)',
  },
  pre: {
    background: 'var(--t-surface)',
    padding: '16px 20px',
    fontSize: 13,
    fontFamily: 'var(--t-font)',
    overflowX: 'auto' as const,
    color: 'var(--t-text)',
    lineHeight: 1.6,
    margin: 0,
  },
  hint: {
    fontSize: 13,
    color: 'var(--t-text)',
  },

  /* Copy */
  copyBtn: {
    padding: '4px 10px',
    fontSize: 12,
    color: 'var(--t-text-dim)',
    background: 'transparent',
    border: '1px solid var(--t-border)',
    borderRadius: 'var(--t-radius-sm)',
    cursor: 'pointer',
    fontFamily: 'var(--t-font)',
    transition: 'border-color 0.15s, color 0.15s',
  },

  /* Examples */
  exList: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: 2,
    marginBottom: 16,
  },
  exRow: {
    display: 'flex',
    alignItems: 'baseline',
    gap: 16,
    padding: '10px 8px 10px 20px',
    background: 'transparent',
    border: 'none',
    borderRadius: 'var(--t-radius-sm)',
    cursor: 'pointer',
    fontFamily: 'var(--t-font)',
    fontSize: 13,
    textAlign: 'left' as const,
    color: 'var(--t-text)',
    transition: 'background 0.15s',
    width: '100%',
  },
  exName: {
    color: 'var(--t-orange)',
    minWidth: 160,
    fontWeight: 500,
    flexShrink: 0,
  },
  exPrompt: {
    color: 'var(--t-text-dim)',
    flex: 1,
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap' as const,
  },
  exCopied: {
    color: 'var(--t-green)',
    fontSize: 12,
    flexShrink: 0,
  },


  /* Download */
  downloadBtn: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: 8,
    padding: '10px 20px',
    fontSize: 14,
    fontWeight: 500,
    fontFamily: 'var(--t-font)',
    color: '#1E1D1C',
    background: 'var(--t-green)',
    border: 'none',
    borderRadius: 'var(--t-radius-sm)',
    cursor: 'pointer',
    textDecoration: 'none',
    transition: 'opacity 0.15s',
  },

  /* Footer */
  footer: {
    display: 'flex',
    alignItems: 'center',
    gap: 10,
    paddingTop: 32,
    paddingBottom: 48,
    fontSize: 13,
  },
  footerLink: {
    background: 'none',
    border: 'none',
    color: 'var(--t-blue)',
    cursor: 'pointer',
    fontFamily: 'var(--t-font)',
    fontSize: 13,
  },
};
