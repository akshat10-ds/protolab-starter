'use client';

import { useState, useEffect, useCallback } from 'react';

/* ═══════════════════════════════════════
   Types
   ═══════════════════════════════════════ */

interface PrototypeBranch {
  name: string;
  displayName: string;
  author: string;
  date: string;
  message: string;
  previewUrl: string;
}

/* ═══════════════════════════════════════
   Helpers
   ═══════════════════════════════════════ */

function timeAgo(dateStr: string): string {
  if (!dateStr) return '';
  const now = Date.now();
  const then = new Date(dateStr).getTime();
  const seconds = Math.floor((now - then) / 1000);
  if (seconds < 60) return 'just now';
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days}d ago`;
  const months = Math.floor(days / 30);
  return `${months}mo ago`;
}

function truncate(str: string, max: number): string {
  if (!str) return '';
  // Take first line only
  const firstLine = str.split('\n')[0];
  if (firstLine.length <= max) return firstLine;
  return firstLine.slice(0, max) + '...';
}

/* ═══════════════════════════════════════
   Page
   ═══════════════════════════════════════ */

export default function PrototypesPage() {
  const [prototypes, setPrototypes] = useState<PrototypeBranch[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState('');
  const [copiedBranch, setCopiedBranch] = useState<string | null>(null);

  const fetchPrototypes = useCallback(async () => {
    try {
      const res = await fetch('/api/prototypes');
      if (!res.ok) throw new Error('Failed to fetch');
      const data = await res.json();
      setPrototypes(data.prototypes || []);
      setError(null);
    } catch {
      setError('Failed to load prototypes');
    } finally {
      setLoading(false);
    }
  }, []);

  // Initial fetch
  useEffect(() => {
    fetchPrototypes();
  }, [fetchPrototypes]);

  // Auto-refresh on window focus
  useEffect(() => {
    const handleVisibility = () => {
      if (document.visibilityState === 'visible') {
        fetchPrototypes();
      }
    };
    document.addEventListener('visibilitychange', handleVisibility);
    return () => document.removeEventListener('visibilitychange', handleVisibility);
  }, [fetchPrototypes]);

  const filtered = prototypes.filter(
    (p) =>
      !filter ||
      p.displayName.toLowerCase().includes(filter.toLowerCase()) ||
      p.author.toLowerCase().includes(filter.toLowerCase()) ||
      p.message.toLowerCase().includes(filter.toLowerCase())
  );

  const copyForkCommand = (branch: PrototypeBranch) => {
    const cmd = `git fetch origin && git checkout -b prototype/${branch.author}-fork origin/${branch.name}`;
    navigator.clipboard.writeText(cmd);
    setCopiedBranch(branch.name);
    setTimeout(() => setCopiedBranch(null), 2000);
  };

  return (
    <div style={st.page}>
      {/* Header */}
      <header style={st.header}>
        <a href="/" style={st.backLink}>
          <span style={{ color: 'var(--t-text-dim)' }}>&larr;</span> protolab
        </a>
        <div style={st.headerContent}>
          <div>
            <h1 style={st.title}>
              <span style={{ color: 'var(--t-green)' }}>$</span> Prototype Gallery
            </h1>
            <p style={st.subtitle}>
              Browse and fork prototypes built by the team
            </p>
          </div>
          <a
            href="vscode://vscode.git/clone?url=https://github.com/akshat10-ds/protolab-starter.git"
            style={st.newBtn}
            className="download-btn"
          >
            + Create Prototype
          </a>
        </div>
      </header>

      {/* Search */}
      <div style={st.searchBar}>
        <span style={{ color: 'var(--t-green)' }}>$</span>
        <input
          type="text"
          placeholder="filter by name, author, or message..."
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          style={st.searchInput}
          spellCheck={false}
        />
      </div>

      {/* Loading state */}
      {loading && (
        <div style={st.grid}>
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} style={st.skeletonCard} className="skeleton-pulse">
              <div style={{ ...st.skeletonLine, width: '60%' }} />
              <div style={{ ...st.skeletonLine, width: '90%', marginTop: 10 }} />
              <div style={{ ...st.skeletonLine, width: '40%', marginTop: 10 }} />
            </div>
          ))}
        </div>
      )}

      {/* Error state */}
      {error && !loading && (
        <p style={{ color: 'var(--t-text-dim)', textAlign: 'center', padding: '40px 0' }}>
          {error}
        </p>
      )}

      {/* Grid */}
      {!loading && !error && (
        <div style={st.grid}>
          {filtered.map((proto) => (
            <div key={proto.name} style={st.card} className="path-card">
              <div style={st.cardTop}>
                <span style={st.cardTitle}>{proto.displayName}</span>
                <span style={st.cardDate}>{timeAgo(proto.date)}</span>
              </div>
              <p style={st.cardDesc}>{truncate(proto.message, 80)}</p>
              <div style={st.cardMeta}>
                <span style={st.cardAuthor}>{proto.author}</span>
              </div>
              <div style={st.cardActions}>
                <a
                  href={proto.previewUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  style={st.openBtn}
                  className="download-btn"
                >
                  Open
                </a>
                <button
                  onClick={() => copyForkCommand(proto)}
                  style={st.forkBtn}
                  className="download-btn"
                >
                  {copiedBranch === proto.name ? 'Copied!' : 'Fork'}
                </button>
              </div>
            </div>
          ))}

          {/* New prototype card */}
          <a
            href="vscode://vscode.git/clone?url=https://github.com/akshat10-ds/protolab-starter.git"
            style={st.newCard}
            className="path-card"
          >
            <div style={st.plusIcon}>+</div>
            <span style={{ color: 'var(--t-text-dim)', fontSize: 13 }}>new prototype</span>
          </a>
        </div>
      )}

      {/* Empty state */}
      {!loading && !error && prototypes.length === 0 && (
        <p style={{ color: 'var(--t-text-dim)', textAlign: 'center', padding: '40px 0', lineHeight: 1.7 }}>
          No prototypes yet. Deploy your first one with <code style={st.inlineCode}>/deploy</code> in Claude Code.
        </p>
      )}

      {/* Filtered empty */}
      {!loading && !error && prototypes.length > 0 && filtered.length === 0 && filter && (
        <p style={{ color: 'var(--t-text-dim)', textAlign: 'center', padding: '40px 0' }}>
          No prototypes match &quot;{filter}&quot;
        </p>
      )}

      {/* Toast */}
      {copiedBranch && (
        <div style={st.toast}>
          Copied fork command to clipboard
        </div>
      )}

      <style>{`
        .skeleton-pulse {
          animation: pulse 1.5s ease-in-out infinite;
        }
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.4; }
        }
      `}</style>
    </div>
  );
}

/* ═══════════════════════════════════════
   Styles (inline, matching terminal theme)
   ═══════════════════════════════════════ */

const st: Record<string, React.CSSProperties> = {
  page: {
    maxWidth: 960,
    margin: '0 auto',
    padding: '24px 20px 80px',
    fontFamily: 'var(--t-font)',
  },
  header: {
    marginBottom: 32,
  },
  backLink: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: 6,
    color: 'var(--t-text-dim)',
    textDecoration: 'none',
    fontSize: 13,
    marginBottom: 20,
    transition: 'color 0.15s',
  },
  headerContent: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    gap: 20,
    flexWrap: 'wrap' as const,
  },
  title: {
    fontSize: 20,
    fontWeight: 600,
    color: 'var(--t-text-bright)',
    margin: 0,
  },
  subtitle: {
    fontSize: 13,
    color: 'var(--t-text-dim)',
    marginTop: 6,
  },
  newBtn: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: 6,
    padding: '8px 16px',
    background: 'var(--t-green)',
    color: '#000',
    borderRadius: 'var(--t-radius-sm)',
    textDecoration: 'none',
    fontSize: 13,
    fontWeight: 600,
    fontFamily: 'var(--t-font)',
    whiteSpace: 'nowrap' as const,
    transition: 'opacity 0.15s',
  },
  searchBar: {
    display: 'flex',
    alignItems: 'center',
    gap: 10,
    padding: '10px 14px',
    background: 'var(--t-surface)',
    border: '1px solid var(--t-border)',
    borderRadius: 'var(--t-radius-sm)',
    marginBottom: 24,
  },
  searchInput: {
    flex: 1,
    background: 'none',
    border: 'none',
    outline: 'none',
    color: 'var(--t-text)',
    fontFamily: 'var(--t-font)',
    fontSize: 13,
  },
  grid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
    gap: 12,
  },
  card: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: 10,
    padding: 16,
    background: 'var(--t-surface)',
    border: '1px solid var(--t-border)',
    borderRadius: 'var(--t-radius-sm)',
    transition: 'border-color 0.15s, background 0.15s',
  },
  cardTop: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'baseline',
    gap: 8,
  },
  cardTitle: {
    fontSize: 14,
    fontWeight: 600,
    color: 'var(--t-text-bright)',
  },
  cardDate: {
    fontSize: 11,
    color: 'var(--t-text-muted)',
    whiteSpace: 'nowrap' as const,
  },
  cardDesc: {
    fontSize: 12,
    color: 'var(--t-text-dim)',
    lineHeight: 1.5,
    margin: 0,
  },
  cardMeta: {
    display: 'flex',
    alignItems: 'center',
    gap: 8,
  },
  cardAuthor: {
    fontSize: 11,
    color: 'var(--t-text-muted)',
  },
  cardActions: {
    display: 'flex',
    gap: 8,
    marginTop: 'auto',
    paddingTop: 10,
    borderTop: '1px solid var(--t-border-subtle)',
  },
  openBtn: {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
    padding: '6px 12px',
    fontSize: 12,
    fontWeight: 600,
    fontFamily: 'var(--t-font)',
    color: '#000',
    background: 'var(--t-green)',
    border: 'none',
    borderRadius: 'var(--t-radius-sm)',
    textDecoration: 'none',
    cursor: 'pointer',
    transition: 'opacity 0.15s',
  },
  forkBtn: {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
    padding: '6px 12px',
    fontSize: 12,
    fontWeight: 600,
    fontFamily: 'var(--t-font)',
    color: 'var(--t-text)',
    background: 'transparent',
    border: '1px solid var(--t-border)',
    borderRadius: 'var(--t-radius-sm)',
    cursor: 'pointer',
    transition: 'border-color 0.15s, background 0.15s',
  },
  newCard: {
    display: 'flex',
    flexDirection: 'column' as const,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    padding: 16,
    minHeight: 140,
    background: 'transparent',
    border: '1px dashed var(--t-border)',
    borderRadius: 'var(--t-radius-sm)',
    textDecoration: 'none',
    color: 'inherit',
    transition: 'border-color 0.15s, background 0.15s',
    cursor: 'pointer',
  },
  plusIcon: {
    width: 36,
    height: 36,
    borderRadius: '50%',
    border: '1px solid var(--t-border)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: 18,
    color: 'var(--t-text-dim)',
  },
  inlineCode: {
    padding: '2px 6px',
    background: 'var(--t-surface)',
    border: '1px solid var(--t-border)',
    borderRadius: 4,
    fontFamily: 'var(--t-font)',
    fontSize: 12,
  },
  skeletonCard: {
    padding: 16,
    background: 'var(--t-surface)',
    border: '1px solid var(--t-border)',
    borderRadius: 'var(--t-radius-sm)',
    minHeight: 140,
  },
  skeletonLine: {
    height: 12,
    borderRadius: 4,
    background: 'var(--t-border)',
  },
  toast: {
    position: 'fixed' as const,
    bottom: 24,
    left: '50%',
    transform: 'translateX(-50%)',
    padding: '10px 20px',
    background: 'var(--t-surface)',
    border: '1px solid var(--t-green)',
    borderRadius: 'var(--t-radius-sm)',
    color: 'var(--t-green)',
    fontSize: 13,
    fontFamily: 'var(--t-font)',
    zIndex: 1000,
    boxShadow: '0 4px 20px rgba(0,0,0,0.4)',
  },
};
