'use client';

import { useState, useEffect, useCallback, useRef } from 'react';

/* ═══════════════════════════════════════
   Constants
   ═══════════════════════════════════════ */

const ENDPOINT = process.env.NEXT_PUBLIC_PROTOLAB_ENDPOINT || 'https://protolab-mcp.vercel.app/api/mcp';
const INSTALL_CMD = 'curl -fsSL https://protolab-mcp.vercel.app/install.sh | bash';

const EXAMPLES = [
  { name: 'Agreements list', prompt: 'Build me an agreements list page with search, filters, and a data table', color: '#10B981' },
  { name: 'Settings page', prompt: 'I need a settings page with sidebar navigation and form sections', color: '#6366F1' },
  { name: 'Dashboard', prompt: 'Create a dashboard with 4 KPI stat cards and a recent activity table', color: '#F59E0B' },
  { name: 'Detail view', prompt: 'Build an agreement detail page with status badge, document info, and action buttons', color: '#EC4899' },
  { name: 'Template gallery', prompt: 'Build a template gallery page with cards and a search bar', color: '#8B5CF6' },
  { name: 'Error page', prompt: 'Design a 404 error page with a message and a button to go home', color: '#EF4444' },
];

const COMMANDS = [
  { cmd: '/deploy', desc: 'Push your prototype to a shareable live URL.', accent: '#10B981' },
  { cmd: '/fork', desc: 'Copy someone else\'s prototype and build on it.', accent: '#6366F1' },
  { cmd: '/handoff', desc: 'Generate an engineer handoff with component inventory.', accent: '#F59E0B' },
  { cmd: '/update', desc: 'Check for and apply ProtoLab Component updates.', accent: '#EC4899' },
  { cmd: '/onboard', desc: 'Verify your setup is correct.', accent: '#8B5CF6' },
];

const EDITORS = [
  { id: 'claude', label: 'Claude Code', file: '.mcp.json', config: JSON.stringify({ mcpServers: { 'ink-design-system': { url: ENDPOINT } } }, null, 2) },
  { id: 'cursor', label: 'Cursor', file: '.cursor/mcp.json', config: JSON.stringify({ mcpServers: { 'ink-design-system': { url: ENDPOINT } } }, null, 2) },
  { id: 'copilot', label: 'GitHub Copilot', file: '.vscode/mcp.json', config: JSON.stringify({ servers: { 'ink-design-system': { type: 'http', url: ENDPOINT } } }, null, 2) },
];

/* ═══════════════════════════════════════
   Hooks
   ═══════════════════════════════════════ */

function useReveal() {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setVisible(true); obs.disconnect(); } }, { threshold: 0.12 });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return { ref, visible };
}

function Reveal({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) {
  const { ref, visible } = useReveal();
  return (
    <div ref={ref} style={{ opacity: visible ? 1 : 0, transform: visible ? 'translateY(0)' : 'translateY(20px)', transition: `opacity 0.5s ease ${delay}ms, transform 0.5s ease ${delay}ms` }}>
      {children}
    </div>
  );
}

/* ═══════════════════════════════════════
   Hero
   ═══════════════════════════════════════ */

function Hero() {
  const [copied, setCopied] = useState(false);
  const copy = () => { navigator.clipboard.writeText(INSTALL_CMD); setCopied(true); setTimeout(() => setCopied(false), 3000); };

  return (
    <section style={{ position: 'relative', paddingTop: 90, paddingBottom: 72, textAlign: 'center' as const, overflow: 'hidden' }}>
      {/* Ambient glow */}
      <div style={{ position: 'absolute', top: -160, left: '50%', transform: 'translateX(-50%)', width: 900, height: 900, borderRadius: '50%', background: 'radial-gradient(circle, rgba(16,185,129,0.07) 0%, rgba(16,185,129,0.02) 35%, transparent 65%)', pointerEvents: 'none' }} />
      {/* Dot grid */}
      <div style={{ position: 'absolute', inset: 0, opacity: 0.35, pointerEvents: 'none', backgroundImage: 'radial-gradient(circle, #CBD5E1 1px, transparent 1px)', backgroundSize: '28px 28px', maskImage: 'radial-gradient(ellipse 50% 50% at 50% 35%, black, transparent)', WebkitMaskImage: 'radial-gradient(ellipse 50% 50% at 50% 35%, black, transparent)' }} />

      <div style={{ position: 'relative', maxWidth: 620, margin: '0 auto', padding: '0 24px' }}>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '6px 16px 6px 10px', background: '#fff', border: '1px solid #E2E8F0', borderRadius: 24, fontSize: 13, fontWeight: 600, fontFamily: F, color: '#475569', marginBottom: 28, boxShadow: '0 1px 4px rgba(0,0,0,0.04)' }}>
          <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#10B981', boxShadow: '0 0 8px rgba(16,185,129,0.5)' }} />
          63 ProtoLab components ready
        </div>

        <h1 style={{ fontSize: 50, fontWeight: 800, lineHeight: 1.1, letterSpacing: '-0.04em', color: '#0F172A', fontFamily: F, marginBottom: 18 }}>
          Build DocuSign<br />prototypes{' '}
          <span style={{ background: 'linear-gradient(135deg, #10B981, #059669)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>with AI</span>
        </h1>

        <p style={{ fontSize: 17, lineHeight: 1.7, color: '#64748B', fontFamily: F, maxWidth: 460, margin: '0 auto 40px' }}>
          Describe what you want. Your editor knows the entire design system and builds working prototypes.
        </p>

        {/* ── The one command ── */}
        <div style={{ maxWidth: 520, margin: '0 auto' }}>
          <div style={{ background: '#0F172A', borderRadius: 14, overflow: 'hidden', boxShadow: '0 8px 32px rgba(15,23,42,0.18), 0 0 0 1px rgba(255,255,255,0.04) inset', textAlign: 'left' as const }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 16px', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
              <div style={{ display: 'flex', gap: 6 }}>
                <span style={{ width: 10, height: 10, borderRadius: '50%', background: '#EF4444', opacity: 0.8 }} />
                <span style={{ width: 10, height: 10, borderRadius: '50%', background: '#F59E0B', opacity: 0.8 }} />
                <span style={{ width: 10, height: 10, borderRadius: '50%', background: '#10B981', opacity: 0.8 }} />
              </div>
              <span style={{ fontSize: 11, fontFamily: M, color: '#475569' }}>Terminal</span>
              <div style={{ width: 44 }} />
            </div>
            <div style={{ padding: '16px 20px', display: 'flex', alignItems: 'center', gap: 10 }}>
              <code style={{ flex: 1, fontSize: 13, fontFamily: M, color: '#E2E8F0', wordBreak: 'break-all' as const, lineHeight: 1.5 }}>
                <span style={{ color: '#34D399' }}>$</span> {INSTALL_CMD}
              </code>
              <button onClick={copy} className="g-copy" style={{ padding: '6px 14px', background: copied ? '#10B981' : 'rgba(255,255,255,0.08)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, fontSize: 12, fontWeight: 700, fontFamily: M, color: copied ? '#fff' : '#94A3B8', cursor: 'pointer', transition: 'all 0.2s', whiteSpace: 'nowrap' as const }}>
                {copied ? '✓ copied' : 'copy'}
              </button>
            </div>
          </div>

          <p style={{ marginTop: 14, fontSize: 13, color: '#94A3B8', fontFamily: F, lineHeight: 1.6 }}>
            This installs VS Code, Node.js, and the starter kit in one go.{' '}
            <button onClick={() => document.getElementById('terminal-help')?.scrollIntoView({ behavior: 'smooth' })} style={{ background: 'none', border: 'none', color: '#10B981', cursor: 'pointer', fontFamily: F, fontSize: 13, fontWeight: 600, textDecoration: 'underline', textDecorationColor: 'rgba(16,185,129,0.3)', textUnderlineOffset: '3px' }}>
              What&apos;s a terminal?
            </button>
          </p>

          {/* Fallback options */}
          <div style={{ display: 'flex', gap: 10, justifyContent: 'center', marginTop: 20, flexWrap: 'wrap' as const }}>
            <a href="vscode://vscode.git/clone?url=https://github.com/akshat10-ds/protolab-starter.git" className="g-pill" style={{ padding: '9px 18px', background: '#fff', border: '1.5px solid #E2E8F0', borderRadius: 10, fontSize: 13, fontWeight: 600, color: '#374151', textDecoration: 'none', fontFamily: F, transition: 'all 0.2s' }}>
              Open in VS Code
            </a>
            <a href="/downloads/ink-starter-kit.zip" download className="g-pill" style={{ padding: '9px 18px', background: '#fff', border: '1.5px solid #E2E8F0', borderRadius: 10, fontSize: 13, fontWeight: 600, color: '#374151', textDecoration: 'none', fontFamily: F, transition: 'all 0.2s' }}>
              ↓ Download .zip
            </a>
            <a href="/prototypes" className="g-pill" style={{ padding: '9px 18px', background: '#fff', border: '1.5px solid #E2E8F0', borderRadius: 10, fontSize: 13, fontWeight: 600, color: '#374151', textDecoration: 'none', fontFamily: F, transition: 'all 0.2s' }}>
              Gallery →
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ═══════════════════════════════════════
   Terminal Help (collapsible)
   ═══════════════════════════════════════ */

function TerminalHelp() {
  const [open, setOpen] = useState(false);

  return (
    <section id="terminal-help" style={{ padding: '0 0 48px' }}>
      <Reveal>
        <button onClick={() => setOpen(!open)} className="g-collapse" style={{
          display: 'flex', alignItems: 'center', gap: 10, width: '100%',
          padding: '16px 20px', background: '#fff', border: '1.5px solid #E2E8F0',
          borderRadius: 14, cursor: 'pointer', fontFamily: F, fontSize: 15,
          color: '#374151', textAlign: 'left' as const, transition: 'all 0.2s',
        }}>
          <span style={{ transform: open ? 'rotate(90deg)' : 'none', transition: 'transform 0.2s', display: 'inline-block', fontSize: 11, color: '#94A3B8' }}>▶</span>
          <span style={{ fontWeight: 700 }}>What&apos;s a terminal?</span>
          <span style={{ color: '#94A3B8', fontSize: 13 }}>— quick guide for first-timers</span>
        </button>

        {open && (
          <div style={{ marginTop: 12, padding: '24px', background: '#fff', border: '1.5px solid #E2E8F0', borderRadius: 14 }}>
            <p style={{ fontSize: 15, lineHeight: 1.7, color: '#475569', fontFamily: F, marginBottom: 16 }}>
              A terminal is a text window where you type commands. It comes built into your computer — you don&apos;t need to install anything.
            </p>
            <div style={{ display: 'flex', flexDirection: 'column' as const, gap: 12 }}>
              {[
                { os: 'Mac', steps: 'Press Cmd + Space, type "Terminal", hit Enter' },
                { os: 'Windows', steps: 'Press Win key, type "PowerShell", hit Enter' },
              ].map(item => (
                <div key={item.os} style={{ padding: '12px 16px', background: '#F8FAFC', borderRadius: 10, border: '1px solid #F1F5F9' }}>
                  <span style={{ fontSize: 13, fontWeight: 700, color: '#0F172A', fontFamily: F }}>{item.os}: </span>
                  <span style={{ fontSize: 13, color: '#64748B', fontFamily: F }}>{item.steps}</span>
                </div>
              ))}
            </div>
            <p style={{ fontSize: 14, lineHeight: 1.7, color: '#64748B', fontFamily: F, marginTop: 16, marginBottom: 0 }}>
              Once it&apos;s open, paste the install command and press Enter. The script handles the rest.
            </p>
          </div>
        )}
      </Reveal>
    </section>
  );
}

/* ═══════════════════════════════════════
   Examples
   ═══════════════════════════════════════ */

function ExamplesSection() {
  const [copied, setCopied] = useState<string | null>(null);
  const copy = (name: string, prompt: string) => { navigator.clipboard.writeText(prompt); setCopied(name); setTimeout(() => setCopied(null), 2000); };

  return (
    <section style={{ padding: '48px 0 64px' }}>
      <Reveal>
        <h2 style={{ fontSize: 30, fontWeight: 800, letterSpacing: '-0.03em', color: '#0F172A', fontFamily: F, marginBottom: 6 }}>
          What you can build
        </h2>
        <p style={{ fontSize: 15, color: '#64748B', fontFamily: F, marginBottom: 28, lineHeight: 1.6 }}>
          Paste any prompt into your AI editor. Click to copy.
        </p>
      </Reveal>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(215px, 1fr))', gap: 12 }}>
        {EXAMPLES.map((ex, i) => (
          <Reveal key={ex.name} delay={i * 50}>
            <button onClick={() => copy(ex.name, ex.prompt)} className="g-card" style={{
              display: 'flex', flexDirection: 'column' as const, alignItems: 'flex-start', width: '100%',
              gap: 8, padding: '18px', background: '#fff', border: '1.5px solid #E2E8F0',
              borderRadius: 14, cursor: 'pointer', textAlign: 'left' as const, fontFamily: F,
              position: 'relative' as const, overflow: 'hidden', transition: 'all 0.25s',
            }}>
              <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 3, background: ex.color }} />
              <span style={{ fontSize: 15, fontWeight: 700, color: '#0F172A' }}>{ex.name}</span>
              <span style={{ fontSize: 13, lineHeight: 1.55, color: '#64748B' }}>{ex.prompt}</span>
              {copied === ex.name && <span style={{ position: 'absolute', top: 12, right: 14, fontSize: 11, fontWeight: 700, color: '#10B981', fontFamily: M }}>✓ COPIED</span>}
            </button>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

/* ═══════════════════════════════════════
   Share
   ═══════════════════════════════════════ */

function ShareSection() {
  const items = [
    { num: '01', title: 'Deploy', body: 'Type /deploy in your editor. Get a live URL to share with anyone.', icon: '🚀' },
    { num: '02', title: 'Gallery', body: 'Deployed prototypes show up at /prototypes. Browse and filter.', icon: '🖼️' },
    { num: '03', title: 'Fork', body: 'Type /fork to copy someone else\'s prototype and iterate.', icon: '🔀' },
  ];

  return (
    <section style={{ padding: '64px 0' }}>
      <Reveal>
        <h2 style={{ fontSize: 30, fontWeight: 800, letterSpacing: '-0.03em', color: '#0F172A', fontFamily: F, marginBottom: 6 }}>Share with your team</h2>
        <p style={{ fontSize: 15, color: '#64748B', fontFamily: F, marginBottom: 28, lineHeight: 1.6 }}>Built something? Get it in front of people in seconds.</p>
      </Reveal>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
        {items.map((s, i) => (
          <Reveal key={s.num} delay={i * 80}>
            <div className="g-card" style={{ padding: '24px', background: '#fff', border: '1.5px solid #E2E8F0', borderRadius: 14, transition: 'all 0.25s', height: '100%' }}>
              <div style={{ fontSize: 28, marginBottom: 12 }}>{s.icon}</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
                <span style={{ fontSize: 11, fontWeight: 800, fontFamily: M, color: '#94A3B8', letterSpacing: '0.08em' }}>{s.num}</span>
                <h3 style={{ fontSize: 17, fontWeight: 800, color: '#0F172A', fontFamily: F, margin: 0 }}>{s.title}</h3>
              </div>
              <p style={{ fontSize: 14, lineHeight: 1.65, color: '#64748B', fontFamily: F, margin: 0 }}>{s.body}</p>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

/* ═══════════════════════════════════════
   Commands
   ═══════════════════════════════════════ */

function CommandsSection() {
  return (
    <section style={{ padding: '48px 0 64px' }}>
      <Reveal>
        <h2 style={{ fontSize: 30, fontWeight: 800, letterSpacing: '-0.03em', color: '#0F172A', fontFamily: F, marginBottom: 6 }}>Editor commands</h2>
        <p style={{ fontSize: 15, color: '#64748B', fontFamily: F, marginBottom: 28, lineHeight: 1.6 }}>Type these in your AI editor to trigger workflows.</p>
      </Reveal>
      <Reveal delay={60}>
        <div style={{ background: '#fff', border: '1.5px solid #E2E8F0', borderRadius: 14, overflow: 'hidden' }}>
          {COMMANDS.map((c, i) => (
            <div key={c.cmd} style={{ display: 'flex', alignItems: 'center', gap: 18, padding: '15px 22px', borderBottom: i < COMMANDS.length - 1 ? '1px solid #F1F5F9' : 'none' }}>
              <code style={{ display: 'inline-block', minWidth: 96, padding: '5px 12px', background: `${c.accent}10`, borderRadius: 8, fontSize: 14, fontWeight: 700, fontFamily: M, color: c.accent, textAlign: 'center' as const, borderLeft: `3px solid ${c.accent}` }}>
                {c.cmd}
              </code>
              <span style={{ fontSize: 14, color: '#475569', fontFamily: F, lineHeight: 1.5 }}>{c.desc}</span>
            </div>
          ))}
        </div>
      </Reveal>
    </section>
  );
}

/* ═══════════════════════════════════════
   Advanced Setup (collapsible)
   ═══════════════════════════════════════ */

function AdvancedSetup() {
  const [open, setOpen] = useState(false);
  const [editor, setEditor] = useState('claude');
  const cfg = EDITORS.find(e => e.id === editor)!;
  const [copied, setCopied] = useState(false);

  return (
    <section style={{ padding: '0 0 24px' }}>
      <Reveal>
        <button onClick={() => setOpen(!open)} className="g-collapse" style={{
          display: 'flex', alignItems: 'center', gap: 10, width: '100%', padding: '16px 20px',
          background: '#fff', border: '1.5px solid #E2E8F0', borderRadius: 14, cursor: 'pointer',
          fontFamily: F, fontSize: 15, color: '#374151', textAlign: 'left' as const, transition: 'all 0.2s',
        }}>
          <span style={{ transform: open ? 'rotate(90deg)' : 'none', transition: 'transform 0.2s', display: 'inline-block', fontSize: 11, color: '#94A3B8' }}>▶</span>
          <span style={{ fontWeight: 700 }}>Add to an existing project</span>
          <span style={{ color: '#94A3B8', fontSize: 13 }}>— manual MCP config</span>
        </button>

        {open && (
          <div style={{ marginTop: 12, padding: '24px', background: '#fff', border: '1.5px solid #E2E8F0', borderRadius: 14 }}>
            <div style={{ display: 'flex', gap: 6, marginBottom: 16 }}>
              {EDITORS.map(e => (
                <button key={e.id} onClick={() => setEditor(e.id)} style={{
                  padding: '7px 16px', borderRadius: 8, fontSize: 13, fontWeight: 600, fontFamily: F, cursor: 'pointer', transition: 'all 0.2s',
                  ...(editor === e.id ? { background: '#0F172A', color: '#fff', border: '1px solid #0F172A' } : { background: '#F8FAFC', color: '#64748B', border: '1px solid #E2E8F0' }),
                }}>{e.label}</button>
              ))}
            </div>
            <div style={{ background: '#0F172A', borderRadius: 12, overflow: 'hidden' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 16px', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
                <span style={{ fontSize: 13, fontFamily: M, color: '#64748B' }}>{cfg.file}</span>
                <button onClick={() => { navigator.clipboard.writeText(cfg.config); setCopied(true); setTimeout(() => setCopied(false), 2000); }} style={{ padding: '4px 12px', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 6, fontSize: 12, fontWeight: 600, fontFamily: M, color: copied ? '#34D399' : '#64748B', cursor: 'pointer' }}>
                  {copied ? '✓ copied' : 'copy'}
                </button>
              </div>
              <pre style={{ padding: '16px', margin: 0, fontSize: 14, fontFamily: M, color: '#E2E8F0', lineHeight: 1.65, overflow: 'auto' }}>{cfg.config}</pre>
            </div>
          </div>
        )}
      </Reveal>
    </section>
  );
}

/* ═══════════════════════════════════════
   Main Export
   ═══════════════════════════════════════ */

export default function GuideView({ onSwitchMode }: { onSwitchMode: () => void }) {
  return (
    <div style={{ background: '#FAFBFC', color: '#1A1A1A', fontFamily: F, minHeight: '100vh' }}>
      <header style={{
        position: 'sticky', top: 0, zIndex: 100, display: 'flex', alignItems: 'center',
        justifyContent: 'space-between', padding: '10px 24px',
        background: 'rgba(250,251,252,0.8)', backdropFilter: 'blur(16px)',
        WebkitBackdropFilter: 'blur(16px)', borderBottom: '1px solid #E2E8F0',
      }}>
        <span style={{ fontSize: 16, fontWeight: 800, fontFamily: F, letterSpacing: '-0.03em', color: '#0F172A' }}>
          <span style={{ color: '#10B981' }}>●</span> ProtoLab
        </span>
        <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
          <a href="/prototypes" style={{ fontSize: 14, color: '#64748B', textDecoration: 'none', fontFamily: F, fontWeight: 500 }}>Gallery</a>
          <button onClick={onSwitchMode} title="Terminal mode" className="g-toggle" style={{
            width: 38, height: 32, display: 'flex', alignItems: 'center', justifyContent: 'center',
            background: '#F1F5F9', border: '1px solid #E2E8F0', borderRadius: 8,
            cursor: 'pointer', color: '#64748B', transition: 'all 0.2s', fontSize: 13, fontFamily: M,
          }}>&gt;_</button>
        </div>
      </header>

      <main style={{ maxWidth: 760, margin: '0 auto', padding: '0 24px' }}>
        <Hero />
        <TerminalHelp />
        <ExamplesSection />
        <ShareSection />
        <CommandsSection />
        <AdvancedSetup />

        <footer style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, padding: '40px 0 60px', fontSize: 13, color: '#94A3B8', fontFamily: F }}>
          <span>ProtoLab v1.0.0</span><span>·</span>
          <span>Built by <span style={{ color: '#10B981', fontWeight: 600 }}>Akshat Mishra</span></span>
        </footer>
      </main>

      <style>{`
        .g-copy:hover { background: rgba(255,255,255,0.15) !important; }
        .g-pill:hover { border-color: #CBD5E1 !important; background: #F1F5F9 !important; transform: translateY(-1px); }
        .g-card:hover { border-color: #CBD5E1 !important; box-shadow: 0 6px 20px rgba(0,0,0,0.05); transform: translateY(-2px); }
        .g-collapse:hover { border-color: #CBD5E1 !important; background: #F8FAFC !important; }
        .g-toggle:hover { background: #E2E8F0 !important; color: #0F172A !important; }
        @media (max-width: 640px) {
          section [style*="grid-template-columns: repeat(3"] { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </div>
  );
}

/* ── Fonts ── */
const F = "'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif";
const M = "'JetBrains Mono', 'SF Mono', monospace";
