'use client';

import { useState } from 'react';

/* ═══════════════════════════════════════
   Data
   ═══════════════════════════════════════ */

type Status = 'match' | 'renamed' | 'protolab-only' | 'missing';

interface ComponentEntry {
  name: string;
  status: Status;
  dsui?: string;        // ds-ui equivalent name (if renamed)
  note?: string;
  layer: string;
  props?: string[];     // key props for annotation
}

const COMPONENTS: ComponentEntry[] = [
  // Direct matches (31)
  { name: 'Accordion', status: 'match', layer: 'composite', props: ['defaultOpen'] },
  { name: 'AlertBadge', status: 'match', layer: 'primitive', props: ['count', 'kind'] },
  { name: 'Avatar', status: 'match', layer: 'primitive', props: ['name', 'size', 'src'] },
  { name: 'Banner', status: 'match', layer: 'composite', props: ['kind', 'dismissible'] },
  { name: 'Breadcrumb', status: 'match', layer: 'composite', props: [] },
  { name: 'Button', status: 'match', layer: 'primitive', props: ['kind', 'size', 'disabled', 'fullWidth', 'pill'] },
  { name: 'Callout', status: 'match', layer: 'composite', props: ['kind'] },
  { name: 'Checkbox', status: 'match', layer: 'primitive', props: ['checked', 'disabled'] },
  { name: 'Chip', status: 'match', layer: 'composite', props: ['kind', 'removable'] },
  { name: 'ComboBox', status: 'match', layer: 'composite', props: ['placeholder', 'disabled'] },
  { name: 'ComboButton', status: 'match', layer: 'composite', props: ['kind', 'size'] },
  { name: 'FileInput', status: 'match', layer: 'composite', props: ['accept', 'multiple'] },
  { name: 'FilterTag', status: 'match', layer: 'composite', props: ['active'] },
  { name: 'Icon', status: 'match', layer: 'primitive', props: ['name', 'size'] },
  { name: 'IconButton', status: 'match', layer: 'primitive', props: ['icon', 'size', 'kind'] },
  { name: 'Link', status: 'match', layer: 'primitive', props: ['href', 'kind'] },
  { name: 'List', status: 'match', layer: 'composite', props: ['kind'] },
  { name: 'Modal', status: 'match', layer: 'composite', props: ['size', 'open'] },
  { name: 'Pagination', status: 'match', layer: 'composite', props: ['totalPages', 'currentPage'] },
  { name: 'Popover', status: 'match', layer: 'composite', props: ['placement'] },
  { name: 'ProgressBar', status: 'match', layer: 'primitive', props: ['value', 'max'] },
  { name: 'Select', status: 'match', layer: 'primitive', props: ['placeholder', 'disabled'] },
  { name: 'Skeleton', status: 'match', layer: 'primitive', props: ['width', 'height'] },
  { name: 'Slider', status: 'match', layer: 'primitive', props: ['min', 'max', 'value'] },
  { name: 'StatusLight', status: 'match', layer: 'primitive', props: ['kind'] },
  { name: 'Switch', status: 'match', layer: 'primitive', props: ['checked', 'disabled'] },
  { name: 'Table', status: 'match', layer: 'composite', props: ['selectable'] },
  { name: 'Tabs', status: 'match', layer: 'composite', props: ['defaultTab'] },
  { name: 'TaskCard', status: 'match', layer: 'composite', props: ['status'] },
  { name: 'TextArea', status: 'match', layer: 'primitive', props: ['placeholder', 'disabled'] },
  { name: 'Tooltip', status: 'match', layer: 'primitive', props: ['content', 'placement'] },

  // Renamed (ProtoLab name → ds-ui name)
  { name: 'Input', status: 'renamed', dsui: 'TextBox', layer: 'primitive', props: ['placeholder', 'disabled', 'type'] },
  { name: 'Radio', status: 'renamed', dsui: 'RadioButton', layer: 'primitive', props: ['checked', 'disabled'] },
  { name: 'Typography', status: 'renamed', dsui: 'Heading / TextEllipsis', layer: 'primitive', props: ['level', 'size'] },
  { name: 'Dropdown', status: 'renamed', dsui: 'Menu', layer: 'composite', props: ['items'] },
  { name: 'SearchInput', status: 'renamed', dsui: 'TextBox (search)', layer: 'composite', props: ['placeholder'] },
  { name: 'Stepper', status: 'renamed', dsui: 'ProgressStepper', layer: 'composite', props: ['steps', 'currentStep'] },
  { name: 'Alert', status: 'renamed', dsui: 'InlineMessage', layer: 'composite', props: ['kind'] },
  { name: 'GlobalNav', status: 'renamed', dsui: 'Header', layer: 'pattern', props: ['navItems'] },
  { name: 'LocalNav', status: 'renamed', dsui: 'SideNav', layer: 'pattern', props: ['sections'] },
  { name: 'Drawer', status: 'renamed', dsui: 'Panel', layer: 'composite', props: ['open', 'position'] },
  { name: 'Grid', status: 'renamed', dsui: 'FlexLayout', layer: 'utility', props: ['columns', 'gap'] },
  { name: 'Stack', status: 'renamed', dsui: 'FlexLayout', layer: 'utility', props: ['direction', 'gap'] },
  { name: 'Inline', status: 'renamed', dsui: 'FlexRow', layer: 'utility', props: ['gap', 'align'] },
  { name: 'Badge', status: 'renamed', dsui: 'StatusBadge', layer: 'primitive', props: ['kind', 'size'] },
  { name: 'FileUpload', status: 'renamed', dsui: 'FileDrop', layer: 'composite', props: ['accept', 'multiple'] },

  // ProtoLab-only (no ds-ui equivalent)
  { name: 'AIBadge', status: 'protolab-only', layer: 'composite', note: 'AI-specific badge', props: [] },
  { name: 'AIChat', status: 'protolab-only', layer: 'pattern', note: 'Chat interface pattern', props: [] },
  { name: 'AgentPanel', status: 'protolab-only', layer: 'pattern', note: 'AI agent canvas', props: [] },
  { name: 'AgreementTableView', status: 'protolab-only', layer: 'layout', note: 'Full agreement page layout', props: [] },
  { name: 'DataTable', status: 'protolab-only', layer: 'pattern', note: 'Enhanced table with sort/filter/select', props: ['columns', 'selectable'] },
  { name: 'DatePicker', status: 'protolab-only', layer: 'composite', note: 'Date selection', props: [] },
  { name: 'Divider', status: 'protolab-only', layer: 'primitive', note: 'Visual separator', props: ['orientation'] },
  { name: 'DocuSignShell', status: 'protolab-only', layer: 'layout', note: 'Full app shell (Header + SideNav + content)', props: [] },
  { name: 'FilterBar', status: 'protolab-only', layer: 'pattern', note: 'Search + filter controls bar', props: [] },
  { name: 'PageHeader', status: 'protolab-only', layer: 'pattern', note: 'Title + actions header', props: ['title'] },
  { name: 'Container', status: 'protolab-only', layer: 'utility', note: 'Max-width wrapper', props: ['maxWidth'] },
  { name: 'Portal', status: 'protolab-only', layer: 'utility', note: 'React portal wrapper', props: [] },
  { name: 'Spacer', status: 'protolab-only', layer: 'utility', note: 'Spacing element', props: ['size'] },
  { name: 'Spinner', status: 'protolab-only', layer: 'primitive', note: 'Loading spinner', props: ['size'] },

  // ds-ui Ink missing from ProtoLab (notable ones)
  { name: 'AvatarGroup', status: 'missing', layer: 'primitive', props: [] },
  { name: 'ButtonGroup', status: 'missing', layer: 'primitive', props: [] },
  { name: 'CheckboxGroup', status: 'missing', layer: 'primitive', props: [] },
  { name: 'ChipGroup', status: 'missing', layer: 'composite', props: [] },
  { name: 'EmptyState', status: 'missing', layer: 'composite', props: [] },
  { name: 'Heading', status: 'missing', layer: 'primitive', props: [] },
  { name: 'Image', status: 'missing', layer: 'primitive', props: [] },
  { name: 'InlineMessage', status: 'missing', layer: 'composite', props: [] },
  { name: 'Menu', status: 'missing', layer: 'composite', props: [] },
  { name: 'Panel', status: 'missing', layer: 'composite', props: [] },
  { name: 'PreviewCard', status: 'missing', layer: 'composite', props: [] },
  { name: 'ProgressCircle', status: 'missing', layer: 'primitive', props: [] },
  { name: 'ProgressStepper', status: 'missing', layer: 'composite', props: [] },
  { name: 'RadioButton', status: 'missing', layer: 'primitive', props: [] },
  { name: 'RadioButtonGroup', status: 'missing', layer: 'primitive', props: [] },
  { name: 'RoundButton', status: 'missing', layer: 'primitive', props: [] },
  { name: 'SideNav', status: 'missing', layer: 'composite', props: [] },
  { name: 'StatusBadge', status: 'missing', layer: 'primitive', props: [] },
  { name: 'Tag', status: 'missing', layer: 'composite', props: [] },
  { name: 'TagGroup', status: 'missing', layer: 'composite', props: [] },
  { name: 'TextBox', status: 'missing', layer: 'primitive', props: [] },
  { name: 'TextEllipsis', status: 'missing', layer: 'primitive', props: [] },
  { name: 'Timeline', status: 'missing', layer: 'composite', props: [] },
  { name: 'ToastMessage', status: 'missing', layer: 'composite', props: [] },
  { name: 'ToggleButton', status: 'missing', layer: 'primitive', props: [] },
  { name: 'Tree', status: 'missing', layer: 'composite', props: [] },
  { name: 'WorkflowStepper', status: 'missing', layer: 'composite', props: [] },
  { name: 'Header', status: 'missing', layer: 'pattern', props: [] },
  { name: 'Meter', status: 'missing', layer: 'primitive', props: [] },
  { name: 'StackedList', status: 'missing', layer: 'composite', props: [] },
  { name: 'StarRating', status: 'missing', layer: 'primitive', props: [] },
  { name: 'ZoomControl', status: 'missing', layer: 'composite', props: [] },
  { name: 'SelectTile', status: 'missing', layer: 'primitive', props: [] },
  { name: 'ClickableCard', status: 'missing', layer: 'composite', props: [] },
  { name: 'QuickActions', status: 'missing', layer: 'composite', props: [] },
  { name: 'ColorPicker', status: 'missing', layer: 'composite', props: [] },
  { name: 'FileDrop', status: 'missing', layer: 'composite', props: [] },
];

const STATUS_CONFIG: Record<Status, { label: string; color: string; bg: string }> = {
  'match': { label: 'match', color: 'var(--t-green)', bg: 'color-mix(in srgb, var(--t-green) 12%, transparent)' },
  'renamed': { label: 'renamed', color: '#FF9F43', bg: 'color-mix(in srgb, #FF9F43 12%, transparent)' },
  'protolab-only': { label: 'protolab only', color: 'var(--t-yellow)', bg: 'color-mix(in srgb, var(--t-yellow) 12%, transparent)' },
  'missing': { label: 'not in protolab', color: '#666', bg: 'color-mix(in srgb, #666 12%, transparent)' },
};

/* ═══════════════════════════════════════
   Page
   ═══════════════════════════════════════ */

export default function ComparePage() {
  const [filter, setFilter] = useState<Status | 'all'>('all');

  const counts = {
    all: COMPONENTS.length,
    match: COMPONENTS.filter(c => c.status === 'match').length,
    renamed: COMPONENTS.filter(c => c.status === 'renamed').length,
    'protolab-only': COMPONENTS.filter(c => c.status === 'protolab-only').length,
    missing: COMPONENTS.filter(c => c.status === 'missing').length,
  };

  const filtered = filter === 'all' ? COMPONENTS : COMPONENTS.filter(c => c.status === filter);

  return (
    <div style={st.page}>
      <header style={st.header}>
        <a href="/" style={st.backLink}>&larr; protolab</a>
        <h1 style={st.title}>
          <span style={{ color: 'var(--t-green)' }}>$</span> protolab vs ds-ui
        </h1>
        <p style={st.subtitle}>
          Component mapping audit — 63 ProtoLab components vs 126 ds-ui components (Ink only, Olive excluded)
        </p>
      </header>

      {/* Stats */}
      <div style={st.stats}>
        {(Object.entries(counts) as [Status | 'all', number][]).map(([key, count]) => (
          <button
            key={key}
            onClick={() => setFilter(key as any)}
            style={{
              ...st.statCard,
              borderColor: filter === key ? (key === 'all' ? 'var(--t-text-dim)' : STATUS_CONFIG[key as Status]?.color || 'var(--t-border)') : 'var(--t-border)',
            }}
            className="path-card"
          >
            <span style={{
              ...st.statCount,
              color: key === 'all' ? 'var(--t-text-bright)' : STATUS_CONFIG[key as Status]?.color,
            }}>
              {count}
            </span>
            <span style={st.statLabel}>
              {key === 'all' ? 'total' : STATUS_CONFIG[key as Status]?.label}
            </span>
          </button>
        ))}
      </div>

      {/* Table */}
      <div style={st.table}>
        <div style={st.tableHeader}>
          <span style={{ ...st.col, flex: 2 }}>ProtoLab</span>
          <span style={{ ...st.col, flex: 1 }}>Status</span>
          <span style={{ ...st.col, flex: 2 }}>ds-ui Equivalent</span>
          <span style={{ ...st.col, flex: 2 }}>Annotation Props</span>
          <span style={{ ...st.col, flex: 1 }}>Layer</span>
        </div>
        {filtered.map((c) => {
          const cfg = STATUS_CONFIG[c.status];
          return (
            <div key={c.name} style={st.tableRow}>
              <span style={{ ...st.col, flex: 2, color: 'var(--t-text-bright)', fontWeight: 500 }}>
                {c.status === 'missing' ? <span style={{ opacity: 0.4 }}>—</span> : c.name}
              </span>
              <span style={{ ...st.col, flex: 1 }}>
                <span style={{ ...st.badge, color: cfg.color, background: cfg.bg }}>{cfg.label}</span>
              </span>
              <span style={{ ...st.col, flex: 2 }}>
                {c.status === 'match' ? (
                  <span style={{ color: 'var(--t-green)' }}>{c.name}</span>
                ) : c.status === 'renamed' ? (
                  <span style={{ color: '#FF9F43' }}>{c.dsui}</span>
                ) : c.status === 'missing' ? (
                  <span style={{ color: 'var(--t-text-dim)' }}>{c.name}</span>
                ) : (
                  <span style={{ color: 'var(--t-text-muted)' }}>{c.note || '—'}</span>
                )}
              </span>
              <span style={{ ...st.col, flex: 2 }}>
                {c.props && c.props.length > 0 ? (
                  <span style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
                    {c.props.map(p => (
                      <code key={p} style={st.propTag}>{p}</code>
                    ))}
                  </span>
                ) : (
                  <span style={{ color: 'var(--t-text-muted)' }}>—</span>
                )}
              </span>
              <span style={{ ...st.col, flex: 1, color: 'var(--t-text-dim)', fontSize: 11 }}>{c.layer}</span>
            </div>
          );
        })}
      </div>

      {/* Annotation example */}
      <div style={st.example}>
        <h2 style={{ ...st.title, fontSize: 16, marginBottom: 12 }}>
          <span style={{ color: 'var(--t-green)' }}>$</span> annotation example
        </h2>
        <pre style={st.code}>{`<!-- Direct match: annotation uses same name -->
<button
  data-ink-component="Button"
  data-ink-prop-kind="primary"
  data-ink-prop-size="small"
>Submit</button>

<!-- Renamed: annotation uses ds-ui name -->
<input
  data-ink-component="TextBox"
  data-ink-prop-placeholder="Search..."
  data-ink-mapped-from="Input"
/>

<!-- ProtoLab-only: uses own name + source flag -->
<div
  data-ink-component="DataTable"
  data-ink-prop-selectable="true"
  data-ink-source="protolab"
/>`}</pre>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════
   Styles
   ═══════════════════════════════════════ */

const st: Record<string, React.CSSProperties> = {
  page: { maxWidth: 1100, margin: '0 auto', padding: '24px 20px 80px', fontFamily: 'var(--t-font)' },
  header: { marginBottom: 32 },
  backLink: { display: 'inline-block', color: 'var(--t-text-dim)', textDecoration: 'none', fontSize: 13, marginBottom: 16 },
  title: { fontSize: 20, fontWeight: 600, color: 'var(--t-text-bright)', margin: 0 },
  subtitle: { fontSize: 13, color: 'var(--t-text-dim)', marginTop: 6 },
  stats: { display: 'flex', gap: 8, marginBottom: 24, flexWrap: 'wrap' as const },
  statCard: {
    display: 'flex', flexDirection: 'column' as const, alignItems: 'center', gap: 2,
    padding: '12px 20px', background: 'var(--t-surface)', border: '1px solid var(--t-border)',
    borderRadius: 'var(--t-radius-sm)', cursor: 'pointer', fontFamily: 'var(--t-font)',
    transition: 'border-color 0.15s',
  },
  statCount: { fontSize: 24, fontWeight: 700 },
  statLabel: { fontSize: 11, color: 'var(--t-text-dim)', textTransform: 'uppercase' as const, letterSpacing: '0.05em' },
  table: { background: 'var(--t-surface)', border: '1px solid var(--t-border)', borderRadius: 'var(--t-radius-sm)', overflow: 'hidden' },
  tableHeader: {
    display: 'flex', gap: 8, padding: '10px 16px',
    borderBottom: '1px solid var(--t-border)', color: 'var(--t-text-dim)', fontSize: 11,
    textTransform: 'uppercase' as const, letterSpacing: '0.05em',
  },
  tableRow: {
    display: 'flex', gap: 8, padding: '8px 16px', fontSize: 13,
    borderBottom: '1px solid var(--t-border-subtle)', alignItems: 'center',
  },
  col: { overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' as const },
  badge: { fontSize: 11, padding: '2px 8px', borderRadius: 4, fontFamily: 'var(--t-font)', whiteSpace: 'nowrap' as const },
  propTag: { fontSize: 11, padding: '1px 6px', borderRadius: 3, background: 'var(--t-chrome)', color: 'var(--t-text)', fontFamily: 'var(--t-font)' },
  example: { marginTop: 32, padding: 20, background: 'var(--t-surface)', border: '1px solid var(--t-border)', borderRadius: 'var(--t-radius-sm)' },
  code: {
    fontSize: 12, lineHeight: 1.6, color: 'var(--t-text)', background: 'var(--t-chrome)',
    padding: 16, borderRadius: 'var(--t-radius-sm)', overflow: 'auto', margin: 0,
    fontFamily: 'var(--t-font)',
  },
};
