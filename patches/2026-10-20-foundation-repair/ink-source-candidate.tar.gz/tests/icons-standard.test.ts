import { describe, expect, it } from 'vitest';
import * as React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { Icon } from '../protolab-source/src/design-system/3-primitives/Icon/Icon';
import { getSystemIconAsset } from '../protolab-source/src/design-system/3-primitives/Icon/assets/system/systemIcons';
import { legacyIconFallbacks } from '../protolab-source/src/design-system/3-primitives/Icon/assets/system/legacyIconFallbacks';
const root = path.resolve(__dirname, '../protolab-source/src/design-system/3-primitives/Icon/assets/system');
const provenance = JSON.parse(fs.readFileSync(path.join(root, 'provenance.json'), 'utf8')) as { exports: { id: string; name: string; canonicalName: string; size: string; file: string; width: number; height: number; sha256: string }[] };
const h = React.createElement;
const render = (name: string, props: Partial<React.ComponentProps<typeof Icon>> = {}) => renderToStaticMarkup(h(Icon, { name, ...props }));
describe('exact active System export contract', () => {
  it('retains all582unique current masters and291independent size pairs', () => {
    expect(provenance.exports).toHaveLength(582); expect(new Set(provenance.exports.map(asset => asset.id)).size).toBe(582);
    const families = new Set(provenance.exports.map(asset => asset.canonicalName)); expect(families.size).toBe(291);
    for (const family of families) expect(provenance.exports.filter(asset => asset.canonicalName === family).map(asset => asset.width).sort()).toEqual([20,24]);
  });
  it('preserves each exported byte sequence and root bounds, with a usable Vite URL', () => {
    for (const asset of provenance.exports) {
      const source = fs.readFileSync(path.join(root, asset.file));
      expect(crypto.createHash('sha256').update(source).digest('hex')).toBe(asset.sha256);
      expect(source.toString()).toMatch(new RegExp(`<svg width="${asset.width}" height="${asset.height}" viewBox="0 0 ${asset.width} ${asset.height}"`));
      expect(getSystemIconAsset(asset.canonicalName, asset.size === 'small')?.url).toContain('.svg');
    }
  });
  it('uses different exact masters for small20andmedium24', () => {
    const small = render('chevron-down', { size: 'small' }), medium = render('chevron-down', { size: 'medium' });
    expect(small).toContain('width="20" height="20"'); expect(small).toContain('chevron-down.small.svg');
    expect(medium).toContain('width="24" height="24"'); expect(medium).toContain('chevron-down.medium.svg');
  });
  it('keeps numeric dimensions explicit while choosing the suitable optical master', () => {
    expect(render('check', { size: 14 })).toContain('width="14" height="14"');
    expect(render('check', { size: 14 })).toContain('data-ink-icon-master="small"');
    expect(render('check', { size: 32 })).toContain('width="32" height="32"');
  });
  it('provides analyze/split/copy glyphs in both naming conventions and sizes', () => {
    for (const name of ['document-analyze','documentAnalyze','document-split','documentSplit','folder-copy','folderCopy']) {
      expect(render(name, { size: 'small' })).toContain('data-ink-icon-master="small"');
      expect(render(name)).toContain('data-ink-icon-master="medium"');
    }
  });
  it('retains all nine documented name aliases and six extension paths', () => {
    for (const name of ['settings','spark','table-border-slash','transaction','edit','info','database','more-vertical','user']) expect(render(name)).toContain('<svg');
    expect(Object.keys(legacyIconFallbacks)).toHaveLength(6);
    for (const name of Object.keys(legacyIconFallbacks)) expect(render(name)).toContain('<svg');
  });
  it('recolors through a mask without inlining the provided SVG paths', () => {
    const output = render('documentAnalyze', { color: 'var(--ink-red-90)', className: 'test-icon', opacity: 0.5, 'aria-label': 'Analyze document' });
    expect(output).toContain('mask-type:alpha'); expect(output).toContain('<image href='); expect(output).toContain('fill="var(--ink-red-90)"'); expect(output).toContain('opacity="0.5"'); expect(output).toContain('role="img"'); expect(output).not.toContain('<path');
  });
  it('normalizes base90percent source alpha before applying caller paint opacity', () => {
    const delegated = new Set(['ai-iris', 'ai-iris-inverse', 'ai-spark', 'ai-spark-filled']);
    const monochrome = provenance.exports.filter(asset => !delegated.has(asset.canonicalName));
    expect(monochrome).toHaveLength(574);
    for (const asset of monochrome) {
      const source = fs.readFileSync(path.join(root, asset.file), 'utf8');
      const paintOpacities = [...source.matchAll(/fill-opacity="([^"]+)"/g)].map(match => match[1]);
      expect(paintOpacities.length).toBeGreaterThan(0); expect(new Set(paintOpacities)).toEqual(new Set(['0.9']));
    }
    for (const color of ['var(--ink-font-color-default)', 'white', 'rgba(19,0,50,0.5)']) {
      const output = render('document-analyze', { color });
      const filter = /<filter id="([^"]+)"/.exec(output)?.[1];
      expect(filter).toBeTruthy(); expect(output).toContain(`<feFuncA type="linear" slope="${1 / 0.9}"></feFuncA>`);
      expect(output).toMatch(new RegExp(`<image[^>]+filter="url\\(#${filter}\\)"`));
      expect(output).toContain(`fill="${color}"`);
    }
  });
  it('assigns independent mask IDs to repeated instances and retains external label IDs', () => {
    const output = renderToStaticMarkup(h(React.Fragment, {}, h(Icon, { name: 'check' }), h(Icon, { name: 'check' })));
    const ids = [...output.matchAll(/<mask id="([^"]+)"/g)].map(match => match[1]); expect(ids).toHaveLength(2); expect(new Set(ids).size).toBe(2);
    expect(render('person', { 'aria-labelledby': 'person-label' })).toContain('aria-hidden="false"');
  });
  it('delegates every current AI name plus the explicit filled-Iris compatibility alias', () => {
    for (const name of ['ai-iris','ai-iris-filled','ai-iris-inverse','ai-spark','ai-spark-filled']) expect(render(name)).toContain('data-ink-component="AIIcon"');
  });
});
