import { defineConfig } from 'vitest/config';
import path from 'node:path';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const aiRoot = process.env.AI_SOURCE_ROOT;
if (!aiRoot) throw new Error('Set AI_SOURCE_ROOT to the canonical AI source or prepared used-set candidate.');
export default defineConfig({
  esbuild: { jsx: 'automatic' },
  resolve: { alias: {
    '@ai': path.resolve(aiRoot),
    '@ink': path.resolve(__dirname, '../protolab-source/src/design-system'),
    '@/design-system': path.resolve(__dirname, '../protolab-source/src/design-system'),
    '@/lib/utils': path.resolve(__dirname, '../protolab-source/src/lib/utils.ts'),
    react: path.dirname(require.resolve('react/package.json')),
    'react-dom': path.dirname(require.resolve('react-dom/package.json')),
  } },
  test: { include: [process.env.AI_USED_SET === '1' ? 'tests/ai-used-set.spec.mjs' : 'tests/ai-source.spec.mjs'], environment: 'node' },
});
