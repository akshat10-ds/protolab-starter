import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Icon, Inline, Stack, Text, Heading, AIBadge, Button } from '@/design-system';
import { getSystemIconAsset } from '../../protolab-source/src/design-system/3-primitives/Icon/assets/system/systemIcons';
import '../../protolab-source/src/design-system/1-tokens/tokens.css';
const glyphs = ['document-analyze','document-split','folder-copy','chevron-down','gear','check','person','status-error'];
function Probe() {
 const [clicks, setClicks] = useState(0);
 return <Stack gap="large" style={{ padding: 'var(--ink-spacing-400)', color: 'var(--ink-neutral-140)', fontFamily: 'var(--ink-font-family)' }}>
  <Heading level={1}>Exact System exports</Heading>
  <Text>Each row shows the original exported SVG, then the tinted renderer at20px and24px.</Text>
  {glyphs.map(name => <Inline gap="large" key={name}>
   <Text style={{ width: 180 }}>{name}</Text>
   <img src={getSystemIconAsset(name, true)?.url} width={20} height={20} alt={`${name} original small`} />
   <Icon name={name} size="small" color="var(--ink-font-color-default)" aria-label={`${name} rendered small`} />
   <img src={getSystemIconAsset(name, false)?.url} width={24} height={24} alt={`${name} original medium`} />
   <Icon name={name} size="medium" color="var(--ink-font-color-default)" aria-label={`${name} rendered medium`} />
   <Icon name={name} size={32} color="var(--ink-red-90)" aria-label={`${name} red numeric`} />
  </Inline>)}
  <Inline gap="large"><Icon name="settings" size="small" /><Icon name="ai-iris" /><Icon name="ai-iris-inverse" /><Icon name="ai-spark" /><Icon name="ai-spark-filled" /></Inline>
  <Stack gap="large" style={{ paddingTop: 'var(--ink-spacing-700)' }}>
   <Heading level={2}>AI badge interactions</Heading>
   <Inline gap="large">
    <AIBadge id="badge-bottom" infoTitle="Bottom explanation" infoContent="This heading must remain visible." onClick={() => setClicks(value => value + 1)}>About AI below</AIBadge>
    <AIBadge id="badge-top" calloutPosition="top" infoTitle="Top explanation" infoContent="Above the trigger.">About AI above</AIBadge>
    <AIBadge infoContent={false}>Static AI</AIBadge>
    <Button id="outside-action" kind="secondary">Outside action</Button>
   </Inline>
   <Text id="consumer-click-count">Consumer clicks: {clicks}</Text>
  </Stack>
 </Stack>;
}
createRoot(document.getElementById('root')!).render(<Probe />);
