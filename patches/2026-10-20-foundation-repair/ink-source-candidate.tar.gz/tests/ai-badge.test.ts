import { describe, expect, it } from 'vitest';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { AIBadge } from '../protolab-source/src/design-system/4-composites/AIBadge';
const h = React.createElement;
const render = (props: React.ComponentProps<typeof AIBadge>) => renderToStaticMarkup(h(AIBadge, props));
describe('AI badge semantic callout contract', () => {
  it('uses a named native button and associates its nonmodal dialog', () => {
    const output = render({ open: true, infoTitle: 'How AI helps', children: 'AI-Assisted', infoContent: 'Explanation' });
    expect(output).toMatch(/<button[^>]*type="button"/); expect(output).toContain('aria-haspopup="dialog"');
    const controlled = /aria-controls="([^"]+)"/.exec(output)?.[1]; expect(controlled).toBeTruthy(); expect(output).toContain(`id="${controlled}" role="dialog"`);
    const labelledBy = /role="dialog" aria-labelledby="([^"]+)"/.exec(output)?.[1]; expect(output).toContain(`<span id="${labelledBy}">How AI helps</span>`);
    expect(output).toContain('Explanation'); expect(output).not.toContain('aria-modal');
  });
  it('passes top/bottom positions to the actual Callout API', () => {
    expect(render({ open: true, calloutPosition: 'top' })).toContain('location-above');
    expect(render({ open: true, calloutPosition: 'bottom' })).toContain('location-below');
  });
  it('keeps static denotation as a span with consumer-compatible span events', () => {
    const onClick: React.MouseEventHandler<HTMLSpanElement> = () => {};
    const output = render({ infoContent: false, onClick, children: 'AI generated' });
    expect(output).not.toContain('<button'); expect(output).not.toContain('role="button"'); expect(output).toContain('AI generated');
  });
  it('does not expose a dangling controls ID while closed', () => {
    const output = render({ open: false }); expect(output).toContain('aria-expanded="false"'); expect(output).not.toContain('aria-controls');
  });
});
