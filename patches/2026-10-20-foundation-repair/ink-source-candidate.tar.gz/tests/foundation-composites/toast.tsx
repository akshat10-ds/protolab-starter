import React from 'react';
import { createRoot } from 'react-dom/client';
import { Button, Stack, Text, Toast, ToastProvider, useToast } from '@/design-system';
import '@/design-system/1-tokens/tokens.css';
function Fixture() {
  const { toast, dismiss } = useToast();
  const [controlledOpen, setControlledOpen] = React.useState(true);
  const [acceptClose, setAcceptClose] = React.useState(false);
  const [requests, setRequests] = React.useState(0);
  const [timedOpen, setTimedOpen] = React.useState(false);
  const [expirations, setExpirations] = React.useState(0);
  return <Stack gap="medium">
    <Text>Toast behavior verification</Text>
    <Button onClick={() => toast({ children: 'First provider notification', duration: 0, action: <Button onClick={() => toast({ children: 'Replacement provider notification', duration: 0 })}>Replace notification</Button> })}>Show eviction test</Button>
    <Button onClick={() => { let id = ''; id = toast({ children: 'Dismissible provider notification', duration: 0, action: <Button onClick={() => dismiss(id)}>Dismiss from action</Button> }); }}>Show provider dismiss test</Button>
    <Button onClick={() => toast({ children: 'Background notification', duration: 1000 })}>Show background expiry</Button>
    <Button>Keep external focus</Button>
    <Button onClick={() => setAcceptClose(value => !value)}>Accept controlled close: {acceptClose ? 'yes' : 'no'}</Button>
    <Button onClick={() => setControlledOpen(value => !value)}>Toggle controlled notification</Button>
    <Text>Controlled close requests: {requests}</Text>
    <Toast open={controlledOpen} duration={0} closeLabel="Dismiss controlled" onClose={() => { setRequests(value => value + 1); if (acceptClose) setControlledOpen(false); }}>Controlled notification</Toast>
    <Toast duration={0} closeLabel="Dismiss standalone">Standalone notification</Toast>
    <Toast duration={0} closeButton={false} action={<Button>Hidden-close action</Button>}>Notification without dismiss button</Toast>
    <Button onClick={() => setTimedOpen(true)}>Start timed controlled notification</Button>
    <Text>Controlled expirations: {expirations}</Text>
    <Toast open={timedOpen} duration={1000} onClose={() => { setTimedOpen(false); setExpirations(value => value + 1); }}>Timed controlled notification</Toast>
  </Stack>;
}
createRoot(document.getElementById('root')!).render(<ToastProvider limit={1}><Fixture /></ToastProvider>);
