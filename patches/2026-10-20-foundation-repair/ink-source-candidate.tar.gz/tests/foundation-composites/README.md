# Composite repair verification

The fixture imports the authoritative `protolab-source` through the public barrel.
Run Vite with `vite --config tests/foundation-composites/vite.config.mjs`, then use
`cua_repl` to inspect and interact with `http://127.0.0.1:5186`.
No separate npm packages are required; use the already-installed starter Vite/React
runtime if the source service checkout has no browser dependencies.

`archived-playwright-verify.cjs` preserves the exact historical method of the first
31 runtime assertions. It used the installed Playwright library and local Chromium,
with animation disabled during geometry measurement. Those results were followed
by independent `cua_repl` checks of tabs, accordion, Panel, Timeline and modal
Tab/reverse-Tab/Escape/focus restoration. Further browser checks use `cua_repl`.
This archival script is not an instruction to bypass the current browser workflow.

Offline template checks use the accepted gzip snapshots, without Figma mutations:

```sh
FIGMA_EVIDENCE_DIR=/absolute/path/to/starter/docs/figma-library-review-2026-10-20/evidence python3 tests/foundation-composites/template-schema-check.py
FIGMA_EVIDENCE_DIR=/absolute/path/to/starter/docs/figma-library-review-2026-10-20/evidence node tests/foundation-composites/validate-templates.cjs
tsc --noEmit -p tests/foundation-composites/tsconfig.json
```

`PROTOLAB_SOURCE`, `TYPESCRIPT_MODULE` and `TEMPLATE_OUTPUT` optionally override the
source path, TypeScript package and generated probe destination. The default
TypeScript config expects the default `output/` location. It is strict and has
`noEmit: true`; the checker never calls `program.emit` or writes JS beside TSX.

The template harness evaluates actual variant root values and captured child
properties/layers, verifies exact getter types and JSX syntax, then emits a typed
probe. The actual Figma template service is not mocked completely: unconnected
foreign descendants and asset bytes are not recreated. Contextual application
bindings (real image source/alt, action names, TreeNode hierarchy, hidden avatars,
submenu data and field limits) are declared with their real prop types. They are
not fabricated content. This checks emitted API contracts; it does not establish
Dev Mode registration, arbitrary slot permutations or pixel parity.

Toast regression fixture (`toast.html` + `toast.tsx`) exercises explicit controlled acceptance/rejection, an absent dismiss button with retained action, standalone dismissal, provider `dismiss(id)`, capacity eviction initiated by the focused toast action, neutral background expiry, and controlled timer reopening. Drive this fixture only through `cua_repl`; source/SSR assertions live in `tests/toast-source.test.ts`. An explicit `open` prop owns display: close requests call `onClose`; an omitted `open` prop uses internal dismissal. Focus recovers only when the removed notification owns focus. Timers pause on focus, hover, or document visibility loss.
