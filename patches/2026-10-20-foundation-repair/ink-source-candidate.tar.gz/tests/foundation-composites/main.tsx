import React from 'react';
import { createRoot } from 'react-dom/client';
import { Chip, Tabs, Accordion, Card, Callout, Modal, Button, Panel, Rail, Pagination, Stepper, Timeline, Table, Text, Icon, Banner, TaskCard, Breadcrumb, Stack, Inline } from '@/design-system';
import '@/design-system/1-tokens/tokens.css';
function App() {
 const [modal,setModal]=React.useState(false), [collapsed,setCollapsed]=React.useState(false), [removed,setRemoved]=React.useState(false),[selected,setSelected]=React.useState(false),[page,setPage]=React.useState(2),[perPage,setPerPage]=React.useState(10),[openIds,setOpenIds]=React.useState<string[]>([]);
 return <Stack gap="large" style={{padding:'var(--ink-spacing-300)'}}>
 <Banner kind="subtle" alignment="start" borderRule="both" action={{label:'Review details'}} closable={false}>Foundation component verification</Banner>
 <Inline>{!removed && <Chip kind="AI" size="small" selected={selected} onClick={()=>setSelected(v=>!v)} onRemove={()=>setRemoved(true)}>Review AI</Chip>}<Chip selected>Neutral selected</Chip></Inline>
 <Tabs fullWidth extended tabs={[{id:'one',label:'First',content:'First content',icon:<Icon name="check"/>},{id:'two',label:'Disabled',disabled:true},{id:'three',label:'Last',content:'Last content',badge:<Text>3</Text>}]} />
 <Accordion allowMultiple items={[{id:'one',title:'Expand first',content:<Button>Inside accordion</Button>,itemHeight:'compact'},{id:'two',title:'Unavailable',disabled:true,content:'No content'},{id:'three',title:'Expand third',subtitle:'Helpful subtitle',metadata:'Metadata',bordered:false,content:'Third content',itemHeight:'tall'}]}/>
 <Accordion items={[{id:'one',title:'Other first',content:'Second accordion'}]}/>
 <Card imagePosition="start"><Card.Image src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='160' height='90'%3E%3Crect width='160' height='90' fill='gray'/%3E%3C/svg%3E" alt="Sample" ratio="16:9" imageSpacing="floating"/><Card.Body>Card start image</Card.Body></Card>
 <Callout heading="Callout heading" location="before" image={<Text>Image slot</Text>} imagePosition="top" footer={<Button>Callout footer</Button>}>Callout body</Callout>
 <Inline align="stretch" style={{minHeight:'calc(var(--ink-spacing-700) * 4)'}}><Panel header={<Text>Supplemental</Text>} collapsible collapsed={collapsed} onCollapsedChange={setCollapsed} footer={<Button>Panel action</Button>} onClose={()=>{}}>Panel body</Panel><Rail><Button>Tools</Button></Rail></Inline>
 <Stepper compact activeStep={3} steps={[1,2,3,4,5].map(n=>({id:String(n),title:`Step ${n}`}))}/>
 <Stepper steps={[{id:'one',title:'Visited',status:'visited',completed:false},{id:'two',title:'Current',status:'active',completed:true}]}/>
 <Pagination currentPage={page} totalPages={10} totalItems={100} showInfo showItemsPerPage size="small" itemsPerPage={perPage} onItemsPerPageChange={setPerPage} onPageChange={setPage}/>
 <Timeline openIds={openIds} onOpenIdsChange={setOpenIds} items={[{id:'e1',label:'First event',description:'First description',collapsible:true},{id:'e2',label:'Second event',description:'Always visible',collapsible:false,status:'warning'}]}/>
 <Table borderRule="columns" columns={[{key:'name',header:'Name'},{key:'value',header:'Value'}]} data={[{name:'Example',value:'One'}]}/>
 <TaskCard><TaskCard.Header heading="Task heading"/><TaskCard.Body>Task body</TaskCard.Body><TaskCard.Footer metadata="Metadata"/></TaskCard>
 <Breadcrumb rootIcon items={[{label:'Home',href:'#home'},{label:'Here',current:true}]}/>
 <Button onClick={()=>setModal(true)}>Open small modal</Button><Modal open={modal} onClose={()=>setModal(false)} title="Small modal" size="small" footer={<Button onClick={()=>setModal(false)}>Done</Button>}><Button>Modal first action</Button></Modal>
 </Stack>;
}
createRoot(document.getElementById('root')!).render(<App/>);
