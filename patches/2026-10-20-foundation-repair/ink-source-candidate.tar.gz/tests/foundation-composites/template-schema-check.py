import json,gzip,re,pathlib,os
base=pathlib.Path(os.environ['FIGMA_EVIDENCE_DIR'])
owners={}
for f in base.glob('page-*.json.gz'):
 for o in json.load(gzip.open(f,'rt'))['owners']:owners[o['id']]=o
p=pathlib.Path(os.environ.get('PROTOLAB_SOURCE',pathlib.Path(__file__).resolve().parents[2]/'protolab-source/src/design-system'))
errors=[];reads=0;files=0
for f in p.rglob('*.figma.ts'):
 s=f.read_text();node=re.search(r'node-id=(\d+)-(\d+)',s)
 if not node:continue
 id=':'.join(node.groups());o=owners.get(id)
 if not o:errors.append([str(f.relative_to(p)),'unresolved-target',id]);continue
 props={k.split('#')[0]:v for k,v in o['properties'].items()}
 for m in re.finditer(r'instance\.(getBoolean|getEnum|getString|getInstanceSwap|getSlot)\([\'\"]([^\'\"]+)',s):
  reads+=1;method,prop=m.groups();expected={'getBoolean':'BOOLEAN','getEnum':'VARIANT','getString':'TEXT','getInstanceSwap':'INSTANCE_SWAP','getSlot':'SLOT'}[method]
  if prop not in props:errors.append([str(f.relative_to(p)),prop,'missing'])
  elif props[prop]['type']!=expected:errors.append([str(f.relative_to(p)),prop,props[prop]['type'],expected])
 files+=1
print(json.dumps({'files':files,'reads':reads,'errors':errors},indent=2))
