import { defineConfig } from 'vite';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = fileURLToPath(new URL('.', import.meta.url));
export default defineConfig({root,resolve:{alias:{'@':path.resolve(root,'../../protolab-source/src')}},server:{host:'127.0.0.1',port:5186,fs:{allow:[path.resolve(root,'../..')]}}});
