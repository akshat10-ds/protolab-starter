import { defineConfig } from 'vite';
import path from 'node:path';
export default defineConfig({
 cacheDir: '/private/tmp/protolab-foundation-repair/.vite-icons',
 resolve: { alias: { '@': path.resolve(__dirname, '../protolab-source/src') } },
 server: { host: '127.0.0.1', port: 5187, strictPort: true },
 build: { outDir: '/private/tmp/protolab-foundation-repair/icon-build', emptyOutDir: true, rollupOptions: { input: path.resolve(__dirname, 'fixtures/standard-icons.html') } },
});
