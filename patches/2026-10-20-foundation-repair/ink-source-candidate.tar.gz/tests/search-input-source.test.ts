import { it, expect } from 'vitest';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { SearchInput } from '@/design-system';

it.each([0, 200])('renders the controlled initial search value before effects with debounce=%s', debounceMs => {
  const html = renderToStaticMarkup(React.createElement(SearchInput, { value: 'Acme NDA', debounceMs, 'aria-label': 'Search agreements' }));
  expect(html).toContain('value="Acme NDA"');
  expect(html).toContain('aria-label="Search agreements"');
});
it('renders an uncontrolled default search value', () => {
  expect(renderToStaticMarkup(React.createElement(SearchInput, { defaultValue: 'Drafts', debounceMs: 200 }))).toContain('value="Drafts"');
});
