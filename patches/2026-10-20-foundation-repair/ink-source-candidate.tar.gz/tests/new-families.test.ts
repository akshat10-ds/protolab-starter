import { describe, expect, it } from 'vitest';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { AIIcon } from '../protolab-source/src/design-system/3-primitives/Icon/AIIcon';
import { ToggleButton } from '../protolab-source/src/design-system/3-primitives/ToggleButton';
import { Hotspot } from '../protolab-source/src/design-system/3-primitives/Hotspot';
import { Meter } from '../protolab-source/src/design-system/3-primitives/Meter';
import { Tag } from '../protolab-source/src/design-system/3-primitives/Tag';
import { SegmentedControl } from '../protolab-source/src/design-system/4-composites/SegmentedControl';
import { ZoomControl } from '../protolab-source/src/design-system/4-composites/ZoomControl';
import { EmptyState } from '../protolab-source/src/design-system/4-composites/EmptyState';
import { PreviewCard } from '../protolab-source/src/design-system/4-composites/PreviewCard';
import { SelectTile, SelectTileGroup } from '../protolab-source/src/design-system/4-composites/SelectTile';
import { StarRating } from '../protolab-source/src/design-system/4-composites/StarRating';
import { Toast } from '../protolab-source/src/design-system/4-composites/Toast';
import { Tree } from '../protolab-source/src/design-system/4-composites/Tree';
import { getSelectableTreeDescendantIds } from '../protolab-source/src/design-system/4-composites/Tree/Tree';
import { WorkflowStepper } from '../protolab-source/src/design-system/4-composites/WorkflowStepper';
import { ColorPicker } from '../protolab-source/src/design-system/4-composites/ColorPicker';
import { hexToHSV, hsvToHex, normalizeHex } from '../protolab-source/src/design-system/4-composites/ColorPicker/color';

const h = React.createElement;
const render = (node: React.ReactElement) => renderToStaticMarkup(node);
describe('new family semantic contracts', () => {
  it('names icon-only toggles and exposes pressed and native disabled states', () => { const out = render(h(ToggleButton, { text: 'Bold', icon: h('svg'), selected: true, inactive: true })); expect(out).toContain('aria-pressed="true"'); expect(out).toContain('Bold'); expect(out).toMatch(/<button[^>]*disabled/); });
  it('keeps text-only toggles visibly named by default', () => expect(render(h(ToggleButton, { text: 'Show labels' }))).toContain('Show labels'));
  it('names Hotspot and preserves the local asset intrinsic geometry', () => { const out = render(h(Hotspot, { label: 'About this field' })); expect(out).toContain('About this field'); expect(out).toContain('width="32" height="32"'); expect(out).toMatch(/src="(?:data:image\/svg\+xml,|[^"]+hotspot.svg)/); });
  it('clamps a Meter value and provides its textual result', () => { const out = render(h(Meter, { label: 'Strength', content: 'Strong', value: 120, max: 100 })); expect(out).toContain('role="meter"'); expect(out).toContain('aria-valuenow="100"'); expect(out).toContain('aria-valuetext="Strong"'); });
  it('keeps invalid Meter bounds finite', () => expect(render(h(Meter, { label: 'Strength', content: 'Unknown', value: NaN, min: 20, max: 0 }))).not.toMatch(/NaN|Infinity/));
  it('makes Tag removal item-specific and disabled when requested', () => { const out = render(h(Tag, { text: 'Legal', onRemove() {}, disabled: true })); expect(out).toContain('Remove Legal'); expect(out).toMatch(/<button[^>]*disabled/); });
  it('renders configured segmented choices with only one roving tab stop', () => { const out = render(h(SegmentedControl, { label: 'View', defaultValue: 'b', items: [{ value: 'a', label: 'List' }, { value: 'b', label: 'Grid' }] })); expect(out).toContain('role="radiogroup"'); expect(out.match(/tabindex="0"/g)).toHaveLength(1); expect(out.match(/aria-checked="true"/g)).toHaveLength(1); });
  it('accepts composed segmented options and disables an individual choice', () => { const out = render(h(SegmentedControl, { label: 'View' }, h(SegmentedControl.Option, { value: 'a', label: 'List' }), h(SegmentedControl.Option, { value: 'b', label: 'Grid', disabled: true }))); expect(out).toContain('List'); expect(out).toContain('Grid'); expect(out).toMatch(/<button[^>]*disabled/); });
  it('disables zoom-in at the upper limit and clamps external values', () => { const out = render(h(ZoomControl, { value: 500, max: 400 })); expect(out).toContain('>400%</output>'); expect(out).toMatch(/<button[^>]*aria-label="Zoom in"[^>]*disabled|<button[^>]*disabled[^>]*aria-label="Zoom in"/); });
  it('preserves custom EmptyState header, body and action slots', () => { const out = render(h(EmptyState, { header: h(EmptyState.Header, { text: 'No results' }), callToAction: 'Try a new search', footer: h(EmptyState.Footer, null, 'Help') }, 'Search another term')); for (const text of ['No results', 'Try a new search', 'Help', 'Search another term']) expect(out).toContain(text); expect(out).toContain('<h2'); });
  it('keeps PreviewCard open and heading actions as sibling buttons', () => { const out = render(h(PreviewCard, { heading: h(PreviewCard.Heading, { text: 'Agreement', action: h('button', null, 'Menu') }), onOpen() {}, openLabel: 'Open Agreement' }, h(PreviewCard.Image, { src: '/agreement.png', alt: 'Agreement preview', ratio: '1:1' }))); expect(out.match(/<button/g)).toHaveLength(2); expect(out).not.toMatch(/<button[^>]*>[^]*<button[^]*<\/button>[^]*<\/button>/); expect(out).toContain('Open Agreement'); expect(out).toContain('aspect-ratio:1/1'); });
  it('names and describes SelectTile native choices', () => { const out = render(h(SelectTileGroup, { label: 'Delivery', defaultValue: 'email', children: [h(SelectTile, { key: 'email', value: 'email', label: 'Email', description: 'Send a link' }), h(SelectTile, { key: 'sms', value: 'sms', label: 'SMS' })] })); expect(out.match(/type="radio"/g)).toHaveLength(2); expect(out.match(/checked=""/g)).toHaveLength(1); expect(out).toContain('aria-describedby='); expect(out).toContain('Delivery'); });
  it('represents multiple tile selection with native checkboxes', () => { const out = render(h(SelectTileGroup, { label: 'Channels', multiple: true, defaultValue: ['a', 'b'], children: [h(SelectTile, { key: 'a', value: 'a', label: 'A' }), h(SelectTile, { key: 'b', value: 'b', label: 'B' })] })); expect(out.match(/type="checkbox"/g)).toHaveLength(2); expect(out.match(/checked=""/g)).toHaveLength(2); });
  it('provides five named StarRating choices and a text result', () => { const out = render(h(StarRating, { label: 'Experience', value: 4 })); expect(out.match(/role="radio"/g)).toHaveLength(5); expect(out).toContain('4 out of 5: Above average'); expect(out.match(/aria-checked="true"/g)).toHaveLength(1); });
  it('preserves the zero/unrated StarRating state', () => { const out = render(h(StarRating, { label: 'Experience', value: 0 })); expect(out).toContain('Not rated'); expect(out).not.toContain('aria-checked="true"'); expect(out.match(/tabindex="0"/g)).toHaveLength(1); });
  it('announces danger Toasts assertively and informational messages politely', () => { expect(render(h(Toast, { kind: 'danger', duration: 0, children: 'Failed' }))).toContain('role="alert"'); expect(render(h(Toast, { duration: 0, children: 'Saved' }))).toContain('role="status"'); });
  it('does not render a closed Toast', () => expect(render(h(Toast, { open: false, children: 'Saved' }))).toBe(''));
  it('exposes Tree expansion, hierarchy, partial selection and visible descendants', () => { const out = render(h(Tree, { label: 'Folders', items: [{ id: 'p', label: 'Parent', children: [{ id: 'a', label: 'A' }, { id: 'b', label: 'B' }] }], selectionMode: 'multiple', expandedIds: ['p'], selectedIds: ['a'] })); expect(out).toContain('aria-multiselectable="true"'); expect(out).toContain('aria-checked="mixed"'); expect(out).toContain('aria-level="2"'); expect(out.match(/role="treeitem"/g)).toHaveLength(3); });
  it('excludes disabled branches from descendant selection', () => expect(getSelectableTreeDescendantIds({ id: 'root', label: 'Root', children: [{ id: 'ok', label: 'Enabled' }, { id: 'blocked', label: 'Disabled', disabled: true, children: [{ id: 'secret', label: 'Hidden child' }] }] })).toEqual(['root', 'ok']));
  it('omits collapsed Tree descendants from the accessible structure', () => { const out = render(h(Tree, { label: 'Folders', items: [{ id: 'p', label: 'Parent', children: [{ id: 'a', label: 'A' }] }] })); expect(out.match(/role="treeitem"/g)).toHaveLength(1); expect(out).toContain('aria-expanded="false"'); });
  it('keeps workflow current and completion independent and content disclosure controlled', () => { const out = render(h(WorkflowStepper, { items: [{ id: 'a', text: 'Review', status: 'current', isComplete: false, expanded: false, children: 'Details' }, { id: 'b', text: 'Complete', status: 'visited', isComplete: true }] })); expect(out).toContain('aria-current="step"'); expect(out).toContain('aria-expanded="false"'); expect(out).toContain('hidden=""'); expect(out.match(/<li/g)).toHaveLength(2); });
  it('names ColorPicker channels, value field and palette choices', () => { const out = render(h(ColorPicker, { label: 'Highlight', value: '#f00' })); expect(out).toContain('aria-label="Saturation"'); expect(out).toContain('aria-label="Brightness"'); expect(out).toContain('aria-label="Hue"'); expect(out).toContain('value="#FF0000"'); expect(out).toContain('Save current color'); });
});
describe('color data normalization and color-space behavior', () => {
  it('normalizes short and long hex without accepting invalid CSS', () => { expect(normalizeHex(' abc ')).toBe('#AABBCC'); expect(normalizeHex('#12aB34')).toBe('#12AB34'); for (const text of ['#12', 'red', '#GG0000', 'url(test)', '#12345678']) expect(normalizeHex(text)).toBeNull(); });
  for (const hex of ['#000000', '#FFFFFF', '#FF0000', '#00FF00', '#0000FF', '#DE483D', '#674EA7', '#FFFF00', '#00FFFF', '#FF00FF']) it(`round trips ${hex}`, () => expect(hsvToHex(hexToHSV(hex))).toBe(hex));
  it('clamps invalid channels and wraps hue across the spectrum', () => { expect(hsvToHex({ h: 360, s: 100, v: 100 })).toBe('#FF0000'); expect(hsvToHex({ h: -120, s: 200, v: 100 })).toBe('#0000FF'); expect(hsvToHex({ h: NaN, s: 100, v: -10 })).toBe('#000000'); });
});

describe('exact AI artwork containers', () => {
  it('uses separate20/24masters and distinct advertised artwork', () => { const iris = render(h(AIIcon, { name: 'ai-iris', size: 'small' })); const spark = render(h(AIIcon, { name: 'ai-spark' })); const filled = render(h(AIIcon, { name: 'ai-spark-filled' })); expect(iris).toContain('viewBox="0 0 20 20"'); expect(iris.match(/<image/g)).toHaveLength(2); expect(spark).toContain('viewBox="0 0 24 24"'); expect(spark).not.toBe(filled); });
  it('preserves externally associated image labels', () => { const out = render(h(AIIcon, { name: 'ai-iris', 'aria-labelledby': 'iris-title' })); expect(out).toContain('aria-labelledby="iris-title"'); expect(out).toContain('aria-hidden="false"'); expect(out).toContain('role="img"'); });
  it('keeps embedded asset gradients isolated and names explicit images', () => { const out = render(h(AIIcon, { name: 'ai-iris-inverse', 'aria-label': 'Iris' })); expect(out).toContain('role="img"'); expect(out).toContain('aria-hidden="false"'); expect(out).not.toContain('<linearGradient'); expect(out.match(/<image/g)).toHaveLength(2); });
});
