import { describe, it, expect } from 'vitest';
import React from 'react';
import { renderToStaticMarkup as render } from 'react-dom/server';
import { ChatInput, SourceListView, AgreementView, IrisAgent, PanelShell, usePanelMode } from '@ai';
const h = React.createElement;
describe('Prepared AI used-set compatibility', () => {
  it('preserves the three composed agent entry points', () => {
    expect(typeof IrisAgent).toBe('function');
    expect(typeof PanelShell).toBe('function');
    expect(typeof usePanelMode).toBe('function');
  });
  it('renders source context through the supported FilterTag leading slot', () => {
    const html = render(h(ChatInput, { onSend() {}, contextSource: { label: 'Acme NDA', icon: 'folder' } }));
    expect(html).toContain('data-ink-component="FilterTag"');
    expect(html).toContain('data-ink-prop-name="folder"');
    expect(html).toContain('Acme NDA');
  });
  it('provides named selection controls and primary source confirmation', () => {
    const html = render(h(SourceListView, { sources: [{ id: 'one', number: 1, title: 'Acme NDA', excerpt: 'Mutual confidentiality' }], onSelectionConfirm() {} }));
    expect(html).toContain('data-ink-prop-kind="primary"');
    expect(html).toContain('Select Acme NDA');
    expect(html).toMatch(/<label[^>]*for="[^"]+"[^>]*>Select all sources<\/label>/);
  });
  it('preserves named document navigation and supported download styling', () => {
    const html = render(h(AgreementView, { title: 'Acme NDA', sections: [], onPrevDocument() {}, onNextDocument() {}, onDownload() {} }));
    expect(html).toContain('aria-label="Previous document"');
    expect(html).toContain('aria-label="Next document"');
    expect(html).toContain('data-ink-prop-kind="secondary"');
  });
});
