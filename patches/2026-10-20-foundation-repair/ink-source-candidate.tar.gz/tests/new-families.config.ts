import { defineConfig } from 'vitest/config';
import path from 'node:path';
export default defineConfig({ resolve: { alias: { '@': path.resolve(__dirname, '../protolab-source/src') } }, test: { include: ['tests/new-families.test.ts'], environment: 'node' } });
