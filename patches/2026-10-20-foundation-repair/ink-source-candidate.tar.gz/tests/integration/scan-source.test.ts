/**
 * Tests for scan_prototype tool — SSRF validation + MCP integration.
 */
import { describe, test, expect, beforeAll, afterAll } from 'vitest';
import { validateScanUrl } from '@/src/tools/scan-source';
import { createTestClient } from '../fixtures/mcp-server';
import type { Client } from '@modelcontextprotocol/sdk/client/index.js';

/* ═══════════════════════════════════════
   Unit tests: validateScanUrl
   ═══════════════════════════════════════ */

describe('validateScanUrl', () => {
  // Blocked schemes
  test('rejects file:// scheme', () => {
    expect(validateScanUrl('file:///etc/passwd')).toContain('Blocked scheme');
  });

  test('rejects data: scheme', () => {
    expect(validateScanUrl('data:text/html,<h1>hi</h1>')).toContain('Blocked scheme');
  });

  test('rejects ftp: scheme', () => {
    expect(validateScanUrl('ftp://evil.com/file')).toContain('Blocked scheme');
  });

  test('rejects javascript: scheme', () => {
    expect(validateScanUrl('javascript:alert(1)')).toContain('Blocked scheme');
  });

  // Private IPs
  test('rejects AWS metadata endpoint', () => {
    expect(validateScanUrl('http://169.254.169.254/latest/meta-data/')).toContain('Blocked private');
  });

  test('rejects 10.x private IP', () => {
    expect(validateScanUrl('http://10.0.0.1:8080')).toContain('Blocked private');
  });

  test('rejects 192.168.x private IP', () => {
    expect(validateScanUrl('http://192.168.1.1')).toContain('Blocked private');
  });

  test('rejects 172.16.x private IP', () => {
    expect(validateScanUrl('http://172.16.0.1')).toContain('Blocked private');
  });

  // HTTP enforcement for non-localhost
  test('rejects http:// for non-localhost', () => {
    expect(validateScanUrl('http://example.com/page')).toContain('must use https');
  });

  // Allowed URLs
  test('allows https vercel.app URLs', () => {
    expect(validateScanUrl('https://protolab-starter-git-prototype-test.vercel.app')).toBeNull();
  });

  test('allows https github.io URLs', () => {
    expect(validateScanUrl('https://user.github.io/page')).toBeNull();
  });

  test('allows https any domain', () => {
    expect(validateScanUrl('https://example.com/prototype')).toBeNull();
  });

  test('allows http://localhost for dev', () => {
    expect(validateScanUrl('http://localhost:5173')).toBeNull();
  });

  test('allows http://127.0.0.1 for dev', () => {
    expect(validateScanUrl('http://127.0.0.1:3000')).toBeNull();
  });

  // Invalid URLs
  test('rejects garbage input', () => {
    expect(validateScanUrl('not-a-url')).toContain('Invalid URL');
  });
});

/* ═══════════════════════════════════════
   MCP integration tests: scan_prototype
   ═══════════════════════════════════════ */

describe('scan_prototype MCP tool', () => {
  let client: Client;
  let cleanup: () => Promise<void>;

  beforeAll(async () => {
    ({ client, cleanup } = await createTestClient());
  });

  afterAll(async () => {
    await cleanup();
  });

  test('rejects blocked URL with error response (not crash)', async () => {
    const result = await client.callTool({
      name: 'scan_prototype',
      arguments: { url: 'file:///etc/passwd' },
    });
    const text = (result.content as Array<{ text: string }>)[0].text;
    const parsed = JSON.parse(text);
    expect(parsed.error).toContain('Blocked scheme');
  });

  test('rejects private IP with error response', async () => {
    const result = await client.callTool({
      name: 'scan_prototype',
      arguments: { url: 'http://169.254.169.254/metadata' },
    });
    const text = (result.content as Array<{ text: string }>)[0].text;
    const parsed = JSON.parse(text);
    expect(parsed.error).toContain('Blocked private');
  });

  test('html mode works (unaffected by URL validation)', async () => {
    const result = await client.callTool({
      name: 'scan_prototype',
      arguments: {
        html: '<div data-ink-component="Button" data-ink-prop-kind="brand">Click me</div>',
      },
    });
    const text = (result.content as Array<{ text: string }>)[0].text;
    const parsed = JSON.parse(text);
    expect(parsed.summary.total).toBe(1);
    expect(parsed.components[0].component).toBe('Button');
  });

  test('requires url or html parameter', async () => {
    const result = await client.callTool({
      name: 'scan_prototype',
      arguments: {},
    });
    const text = (result.content as Array<{ text: string }>)[0].text;
    const parsed = JSON.parse(text);
    expect(parsed.error).toContain('Provide either');
  });
});
