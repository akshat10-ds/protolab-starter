import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { mkdtempSync, mkdirSync, writeFileSync, readFileSync, symlinkSync, rmSync } from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';
import os from 'node:os';
import ts from 'typescript';
import type { Client } from '@modelcontextprotocol/sdk/client/index.js';
import { createTestClient } from '../fixtures/mcp-server';

let client: Client;
let cleanup: () => Promise<void>;
beforeAll(async () => { ({ client, cleanup } = await createTestClient()); });
afterAll(async () => { await cleanup(); });

interface InlineScaffold { files: Record<string, string>; }
const cases = [
  ['Button'],
  ['Input', 'Select', 'ComboBox', 'PageHeader', 'DocuSignShell'],
  ['DataTable', 'AgreementTableView', 'FilterBar', 'Tabs', 'Banner', 'Breadcrumb', 'IconButton', 'Badge', 'PageHeader'],
  ['Panel', 'Hotspot', 'Tree', 'ColorPicker', 'Toast', 'Dropdown', 'AvatarGroup'],
];
describe('Generated subset contracts', () => {
  it.each(cases.map(components => [components.join(', '), components] as const))('typechecks a real %s scaffold', async (_label, components) => {
    const result = await client.callTool({ name: 'scaffold_project', arguments: { projectName: 'contract-check', components, mode: 'inline' } });
    const text = (result.content as Array<{ type: string; text?: string }>).find(item => item.type === 'text')?.text;
    expect(text).toBeDefined();
    const scaffold = JSON.parse(text!) as InlineScaffold;
    expect(scaffold.files).toBeDefined();
    const folder = mkdtempSync(path.join(os.tmpdir(), 'protolab-scaffold-contract-'));
    try {
      for (const [name, content] of Object.entries(scaffold.files)) {
        const destination = path.join(folder, name);
        mkdirSync(path.dirname(destination), { recursive: true });
        writeFileSync(destination, content);
      }
      symlinkSync(path.resolve('template/ink-starter/node_modules'), path.join(folder, 'node_modules'));
      const config = ts.readConfigFile(path.join(folder, 'tsconfig.json'), ts.sys.readFile);
      expect(config.config.compilerOptions.noEmit).toBe(true);
      const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, folder);
      const program = ts.createProgram(parsed.fileNames, { ...parsed.options, noEmit: true });
      const diagnostics = ts.getPreEmitDiagnostics(program);
      expect(diagnostics.map(diagnostic => ts.flattenDiagnosticMessageText(diagnostic.messageText, '\n'))).toEqual([]);
      expect(scaffold.files['src/design-system/index.ts']).toContain('export *');
      expect(JSON.parse(scaffold.files['package.json']).scripts.build).toContain('check-source-shadows.mjs');
      expect(JSON.parse(scaffold.files['package.json']).scripts.typecheck).toContain('check-source-shadows.mjs');
      const shadowTests = spawnSync(process.execPath, ['--test', 'scripts/check-source-shadows.test.mjs'], { cwd: folder, encoding: 'utf8' });
      expect(shadowTests.status, shadowTests.stderr || shadowTests.stdout).toBe(0);
      if (components.includes('Hotspot')) {
        expect(scaffold.files['src/design-system/3-primitives/Hotspot/assets/hotspot.svg']).toContain('<svg');
        expect(scaffold.files['src/design-system/figma-template.d.ts']).toContain("declare module 'figma'");
      }
    } finally { rmSync(folder, { recursive: true, force: true }); }
  });
  it('rejects a bundle that no longer matches its authoring source before validating output', () => {
    const folder = mkdtempSync(path.join(os.tmpdir(), 'protolab-stale-bundle-'));
    try {
      const bundle = JSON.parse(readFileSync('data/bundle.json', 'utf8'));
      const tokenPath = path.join(folder, 'src', bundle.tokens.path);
      mkdirSync(path.dirname(tokenPath), { recursive: true });
      writeFileSync(tokenPath, '/* newer authoring source */');
      const result = spawnSync(process.execPath, ['scripts/check-template-contracts.mjs'], {
        cwd: process.cwd(), encoding: 'utf8', env: { ...process.env, PROTOLAB_ROOT: folder },
      });
      expect(result.status).toBe(1);
      expect(result.stderr).toContain('Bundle is stale against authoring source');
    } finally { rmSync(folder, { recursive: true, force: true }); }
  });
  it('refuses compiler-created JavaScript shadows before mutating the bundle', () => {
    const folder = mkdtempSync(path.join(os.tmpdir(), 'protolab-shadow-contract-'));
    const previous = readFileSync('data/bundle.json', 'utf8');
    try {
      mkdirSync(path.join(folder, 'src'), { recursive: true });
      writeFileSync(path.join(folder, 'component-registry.json'), '{}');
      writeFileSync(path.join(folder, 'src/Example.ts'), 'export const source = true;');
      writeFileSync(path.join(folder, 'src/Example.js'), 'export const source = false;');
      const hook = createRequire(import.meta.url).resolve('tsx/cjs');
      const result = spawnSync(process.execPath, ['--require', hook, 'scripts/bundle-data.ts'], {
        cwd: process.cwd(), encoding: 'utf8', env: { ...process.env, PROTOLAB_ROOT: folder },
      });
      expect(result.status).toBe(1);
      expect(result.stderr).toContain('Refusing JavaScript shadow');
      expect(readFileSync('data/bundle.json', 'utf8')).toBe(previous);
    } finally { rmSync(folder, { recursive: true, force: true }); }
  });

});
