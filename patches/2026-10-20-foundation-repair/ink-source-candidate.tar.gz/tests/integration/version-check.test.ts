import bundleData from '@/data/bundle.json';
/**
 * Tests for check_template_version tool + template-version resource.
 * Verifies bundle hash consistency and version comparison logic.
 */
import { describe, test, expect, beforeAll, afterAll } from 'vitest';
import { createTestClient, bundleHash } from '../fixtures/mcp-server';
import type { Client } from '@modelcontextprotocol/sdk/client/index.js';

describe('check_template_version', () => {
  let client: Client;
  let cleanup: () => Promise<void>;

  beforeAll(async () => {
    ({ client, cleanup } = await createTestClient());
  });

  afterAll(async () => {
    await cleanup();
  });

  test('returns upToDate=true when hash matches', async () => {
    const result = await client.callTool({
      name: 'check_template_version',
      arguments: { localBundleHash: bundleHash },
    });
    const text = (result.content as Array<{ text: string }>)[0].text;
    const parsed = JSON.parse(text);
    expect(parsed.upToDate).toBe(true);
    expect(parsed.serverBundleHash).toBe(bundleHash);
    expect(parsed.message).toContain('up to date');
  });

  test('returns upToDate=false when hash does not match', async () => {
    const result = await client.callTool({
      name: 'check_template_version',
      arguments: { localBundleHash: 'wrong_hash_value' },
    });
    const text = (result.content as Array<{ text: string }>)[0].text;
    const parsed = JSON.parse(text);
    expect(parsed.upToDate).toBe(false);
    expect(parsed.serverBundleHash).toBe(bundleHash);
    expect(parsed.localBundleHash).toBe('wrong_hash_value');
    expect(parsed.message).toContain('outdated');
    expect(parsed.downloadUrl).toContain('/downloads/ink-starter-kit.zip');
    expect(parsed.githubRepoUrl).toContain('protolab-starter');
  });

  test('returns upToDate=false when no hash provided', async () => {
    const result = await client.callTool({
      name: 'check_template_version',
      arguments: {},
    });
    const text = (result.content as Array<{ text: string }>)[0].text;
    const parsed = JSON.parse(text);
    expect(parsed.upToDate).toBe(false);
  });

  test('response does not contain buildTimestamp', async () => {
    const result = await client.callTool({
      name: 'check_template_version',
      arguments: { localBundleHash: bundleHash },
    });
    const text = (result.content as Array<{ text: string }>)[0].text;
    const parsed = JSON.parse(text);
    expect(parsed).not.toHaveProperty('buildTimestamp');
    expect(parsed).not.toHaveProperty('daysOld');
  });
});

describe('template-version resource', () => {
  let client: Client;
  let cleanup: () => Promise<void>;

  beforeAll(async () => {
    ({ client, cleanup } = await createTestClient());
  });

  afterAll(async () => {
    await cleanup();
  });

  test('returns same bundleHash as check_template_version tool', async () => {
    const resource = await client.readResource({ uri: 'ink://template-version' });
    const text = (resource.contents as Array<{ text: string }>)[0].text;
    const parsed = JSON.parse(text);
    expect(parsed.bundleHash).toBe(bundleHash);
    expect(parsed.componentCount).toBe(bundleData.registry.totalComponents);
    expect(parsed.version).toBe('1.0.0');
  });

  test('resource does not contain buildTimestamp', async () => {
    const resource = await client.readResource({ uri: 'ink://template-version' });
    const text = (resource.contents as Array<{ text: string }>)[0].text;
    const parsed = JSON.parse(text);
    expect(parsed).not.toHaveProperty('buildTimestamp');
  });
});
