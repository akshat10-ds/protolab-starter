import { defineConfig } from 'vite';
import path from 'node:path';
export default defineConfig({ root: path.resolve(__dirname, '../..'), resolve: { alias: { '@': path.resolve(__dirname, '../../protolab-source/src'), '@ink': path.resolve(__dirname, '../../protolab-source/src/design-system') } }, server: { host: '127.0.0.1', port: 5190, strictPort: true, fs: { allow: [path.resolve(__dirname, '../..'), '/Users/akshat.mishra/Documents/Work/protolab-starter'] } } });
