import { describe, expect, it } from 'vitest';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { Button } from '../protolab-source/src/design-system/3-primitives/Button';
import { ComboButton } from '../protolab-source/src/design-system/4-composites/ComboButton';
import { Avatar, AvatarGroup } from '../protolab-source/src/design-system/3-primitives/Avatar';
import { IconButton } from '../protolab-source/src/design-system/3-primitives/IconButton';
import { Badge } from '../protolab-source/src/design-system/3-primitives/Badge';
import { AlertBadge } from '../protolab-source/src/design-system/3-primitives/AlertBadge';
import { Input } from '../protolab-source/src/design-system/3-primitives/Input';
import { TextArea } from '../protolab-source/src/design-system/3-primitives/TextArea';
import { Switch } from '../protolab-source/src/design-system/3-primitives/Switch';
import { Radio } from '../protolab-source/src/design-system/3-primitives/Radio';
import { Spinner } from '../protolab-source/src/design-system/3-primitives/Spinner';
import { ComboBox } from '../protolab-source/src/design-system/4-composites/ComboBox';
import { DatePicker } from '../protolab-source/src/design-system/4-composites/DatePicker';
import { FileUpload } from '../protolab-source/src/design-system/4-composites/FileUpload';
import { FilterTag } from '../protolab-source/src/design-system/4-composites/FilterTag';
import { addDays, addMonths, dayValue, formatDate, inDateBounds, nextRange, parseDate } from '../protolab-source/src/design-system/4-composites/DatePicker/dateUtils';
const h = React.createElement;
const render = (element: React.ReactElement) => renderToStaticMarkup(element);

describe('primitive rendered semantics', () => {
  it('names compact and dropdown split actions with internal text', () => {
    const output = render(h(ComboButton, { compact: true, startIcon: 'plus', accessibilityText: 'Create agreement', dropdownLabel: 'Create options' }));
    expect(output).toMatch(/<button[^>]*>.*Create agreement.*<\/button>/);
    expect(output).toContain('Create options'); expect(output).toContain('aria-haspopup="menu"');
  });
  it('supports Button accessibility text with no visual children', () => expect(render(h(Button, { accessibilityText: 'Save' }))).toContain('Save'));
  it('renders the square entity fallback and both Avatar optional treatments', () => {
    const output = render(h(Avatar, { shape: 'square', shadow: true, border: true, badge: true, alt: 'Acme' }));
    expect(output).toContain('data-ink-component="AlertBadge"'); expect(output).toContain('aria-label="Acme"'); expect(output).toContain('role="img"');
    expect(output).not.toEqual(render(h(Avatar, { shape: 'circle' })));
  });
  it('exports AvatarGroup and clamps negative visible limits', () => {
    const output = render(h(AvatarGroup, { avatars: [{ initials: 'AM' }, { initials: 'JS' }], max: -1 }));
    expect(output).toContain('2 more people'); expect(output).not.toContain('data-ink-component="Avatar"');
  });
  it('supports an IconButton dot and count including zero', () => {
    expect(render(h(IconButton, { icon: 'bell', 'aria-label': 'Notifications', badge: true }))).toContain('Alert indicator');
    expect(render(h(IconButton, { icon: 'bell', 'aria-label': 'Notifications', badge: 0 }))).toContain('0 alerts');
  });
  it('makes menu badges native named buttons', () => {
    const output = render(h(Badge, { text: 'Pending', menuTrigger: true }));
    expect(output).toMatch(/^<button/); expect(output).toContain('aria-haspopup="menu"'); expect(output).toContain('Pending');
    expect(render(h(Badge, { text: 'Sent' }))).toMatch(/^<span/);
  });
  it('preserves explicit 99+ and zero AlertBadge values', () => {
    expect(render(h(AlertBadge, { value: '99+' }))).toContain('>99+</div>');
    expect(render(h(AlertBadge, { value: 0 }))).toContain('>0</div>');
  });
  it('connects Input help/error/count without dangling hidden-description references', () => {
    const output = render(h(Input, { label: 'Name', id: 'name', description: 'Hidden by error', error: 'Required', characterCount: true, maxLength: 12, defaultValue: 'Acme', startElement: 'Start', endElement: 'End', inputHelp: 'Help', 'aria-describedby': 'external' }));
    expect(output).toContain('aria-describedby="external name-error name-count"'); expect(output).toContain('4/12');
    for (const slot of ['Start','End','Help']) expect(output).toContain(slot);
  });
  it('retains multiline Input and forwards the native maximum only when requested', () => {
    expect(render(h(Input, { label: 'Notes', multiline: true, maxLength: 5, allowOverLimit: false }))).toContain('maxLength="5"');
    expect(render(h(Input, { label: 'Notes', maxLength: 5 }))).not.toContain('maxLength=');
  });
  it('counts uncontrolled initial TextArea content and provides its start slot', () => {
    const output = render(h(TextArea, { label: 'Notes', id: 'notes', defaultValue: 'Draft', maxLength: 200, characterCount: true, startElement: 'Context' }));
    expect(output).toContain('5/200'); expect(output).toContain('Context'); expect(output).toContain('notes-count');
  });
  it('associates Switch copy and keeps description-only controls named', () => {
    const output = render(h(Switch, { id: 'notify', label: 'Notify', description: 'Email updates', disabled: true }));
    expect(output).toContain('<label for="notify"'); expect(output).toContain('aria-labelledby="notify-label"'); expect(output).toContain('aria-describedby="notify-description"');
    expect(render(h(Switch, { id: 'only', description: 'Email updates' }))).toContain('aria-labelledby="only-description"');
  });
  it('includes the Radio error icon beside copy', () => {
    expect(render(h(Radio, { label: 'Select', error: 'Required' }))).toMatch(/<svg.*Required/);
  });
  for (const [size, pixels, stroke] of [['small', 16, 2], ['medium', 40, 4], ['large', 80, 8]] as const) {
    it(`draws the full ${pixels}px Spinner ring with ${stroke}px inside stroke`, () => {
      const output = render(h(Spinner, { size }));
      const radius = Number(/ r="([\d.]+)"/.exec(output)?.[1]); const width = Number(/stroke-width="([\d.]+)"/.exec(output)?.[1]);
      expect((2 * radius + width) * pixels / 50).toBe(pixels); expect(width * pixels / 50).toBe(stroke);
    });
  }
  it('exposes the noneditable ComboBox family without changing the editable default', () => {
    const props = { label: 'Party', options: [{ value: 'a', label: 'Acme' }], value: 'a', onChange() {} };
    const output = render(h(ComboBox, { ...props, editable: false, size: 'small', clearable: false }));
    expect(output).toContain('readOnly=""'); expect(output).toContain('aria-autocomplete="none"'); expect(output).not.toContain('Clear Party');
    expect(render(h(ComboBox, props))).toContain('aria-autocomplete="list"');
  });
  it('DateInput associates its label, formatting and helper instructions', () => {
    const output = render(h(DatePicker, { id: 'due', label: 'Due', helperText: 'Choose a business day', size: 'small' }));
    expect(output).toContain('<label for="due"'); expect(output).toContain('aria-describedby="due-format due-help"'); expect(output).toContain('aria-label="Choose Due"');
  });
  it('supports typed DateInput without a picker, and a standalone ranged calendar', () => {
    expect(render(h(DatePicker, { usePicker: false }))).not.toContain('Choose date');
    const output = render(h(DatePicker, { standalone: true, selectionMode: 'range', rangeValue: [new Date(2026, 9, 2), new Date(2026, 9, 5)], showMonthYearSelector: true }));
    expect(output).toContain('role="grid"'); expect(output).toContain('aria-multiselectable="true"'); expect(output).toContain('aria-selected="true"'); expect(output).toContain('data-ink-component="Select"');
  });
  it('FileUpload exposes a native browse action and derives limit copy from validation', () => {
    const output = render(h(FileUpload, { label: 'Documents', maxSize: 20 * 1024 * 1024, small: true, background: true, secondaryAction: h(Button, { kind: 'secondary' }, 'Choose source') }));
    expect(output).toContain('Browse files'); expect(output).toContain('Choose source'); expect(output).toContain('Max file size: 20 MB'); expect(output).toContain('role="group"');
    expect(render(h(FileUpload, { showBodyText: false, helperText: 'Formats' }))).not.toContain('Formats');
  });
  it('FilterTag preserves leading and trigger slots in both split branches', () => {
    for (const dismissible of [false, true]) {
      const output = render(h(FilterTag, { label: 'Status', startElement: 'Lead', dismissible }));
      expect(output.match(/Lead/g)).toHaveLength(1); expect(output).toContain('<svg');
    }
  });
});
describe('date parsing, bounds and selection behavior', () => {
  for (const [text, format] of [['02/29/2024', 'MM/DD/YYYY'], ['29/02/2024', 'DD/MM/YYYY'], ['2024-02-29', 'YYYY-MM-DD']] as const) it(`strictly round-trips ${format}`, () => expect(formatDate(parseDate(text, format), format)).toBe(text));
  for (const text of ['02/29/2023','04/31/2026','13/01/2026','2/2/2026','hello','00/12/2026']) it(`rejects impossible or malformed ${text}`, () => expect(parseDate(text, 'MM/DD/YYYY')).toBeNull());
  it('compares date boundaries by day regardless of time', () => expect(inDateBounds(new Date(2026, 9, 20, 0), new Date(2026, 9, 20, 18), new Date(2026, 9, 20, 1))).toBe(true));
  it('clamps month navigation at short month ends and leap years', () => {
    expect(formatDate(addMonths(new Date(2024, 0, 31), 1), 'YYYY-MM-DD')).toBe('2024-02-29');
    expect(formatDate(addMonths(new Date(2023, 0, 31), 1), 'YYYY-MM-DD')).toBe('2023-02-28');
  });
  it('navigates calendar days across a month boundary', () => expect(formatDate(addDays(new Date(2026, 9, 31), 1), 'YYYY-MM-DD')).toBe('2026-11-01'));
  it('orders reverse ranges, then begins a fresh range after completion', () => {
    const start = new Date(2026, 9, 20); const end = new Date(2026, 9, 10);
    const range = nextRange([start, null], end); expect(range.map(date => date && dayValue(date))).toEqual([dayValue(end), dayValue(start)]);
    expect(nextRange(range, start)).toEqual([start, null]);
  });
});
