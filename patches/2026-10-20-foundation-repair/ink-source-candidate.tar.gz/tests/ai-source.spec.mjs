import { describe, it, expect } from 'vitest';
import React from 'react';
import { renderToStaticMarkup as render } from 'react-dom/server';
import {
  ActivityTimeline, ChatInput, SourceDiscoveryView, SourceListView,
  AgreementView, useScreenAwareAgent,
} from '@ai';
const h = React.createElement;

describe('Canonical AI adapters against the current Ink contract', () => {
  it.each([[-1, 9], [21, 1], [Number.NaN, 0]])('normalizes external avatar palette index %s to recipient %s', (input, expected) => {
    const html = render(h(ActivityTimeline, { activities: [{
      id: 'assignment', type: 'assignment', actor: { name: 'Jane Smith', initials: 'JS', colorIndex: input },
      title: 'Assigned for review', timestamp: 'Today',
    }] }));
    expect(html).toContain(`color${expected}`);
    expect(html).toContain('Assigned for review');
  });
  it('renders a context source through FilterTag leading content without promising a menu', () => {
    const html = render(h(ChatInput, { onSend() {}, contextSource: { label: 'Acme NDA', icon: 'folder' } }));
    expect(html).toContain('data-ink-component="FilterTag"');
    expect(html).toMatch(/data-ink-prop-name="folder"/);
    expect(html).toContain('Acme NDA');
  });
  it('names the discovery search input and preserves its search glyph', () => {
    const html = render(h(SourceDiscoveryView, { agreements: [] }));
    expect(html).toMatch(/<label[^>]*>Search agreements<\/label>/);
    expect(html).toContain('data-ink-prop-name="search"');
  });
  it('uses the primary CTA contract when selected sources can be confirmed', () => {
    const html = render(h(SourceListView, { sources: [{ id: 'one', number: 1, title: 'Acme NDA', excerpt: 'Mutual confidentiality' }], onSelectionConfirm() {} }));
    expect(html).toContain('data-ink-prop-kind="primary"');
    expect(html).toContain('Chat with 1');
    expect(html).toContain('Select Acme NDA');
    expect(html).toMatch(/<label[^>]*for="[^"]+"[^>]*>Select all sources<\/label>/);
  });
  it('renders agreement navigation and secondary download through supported controls', () => {
    const html = render(h(AgreementView, { title: 'Acme NDA', sections: [], onPrevDocument() {}, onNextDocument() {}, onDownload() {} }));
    expect(html).toContain('aria-label="Previous document"');
    expect(html).toContain('aria-label="Next document"');
    expect(html).toContain('data-ink-prop-kind="secondary"');
    expect(html).toContain('Download');
  });
  it('initializes screen-aware state with omitted optional maps', () => {
    function Probe() { const agent = useScreenAwareAgent({ initialScreen: 'agreements' }); return h('output', null, `${agent.screen}:${agent.contextItems.length}`); }
    expect(render(h(Probe))).toContain('agreements:0');
  });
});
