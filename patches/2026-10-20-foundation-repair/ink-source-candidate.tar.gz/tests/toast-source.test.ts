import { describe, expect, it } from 'vitest';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { Toast } from '../protolab-source/src/design-system/4-composites/Toast';
const render = (props: React.ComponentProps<typeof Toast>) => renderToStaticMarkup(React.createElement(Toast, props));
describe('Toast close-button contracts', () => {
  it('retains the default named dismiss control', () => { const out = render({ children: 'Saved', duration: 0 }); expect(out).toContain('Dismiss notification'); expect(out.match(/<button/g)).toHaveLength(1); });
  it('can omit the dismiss button without omitting content or an action', () => { const out = render({ children: 'Saved', closeButton: false, duration: 0, action: React.createElement('button', null, 'Undo') }); expect(out).toContain('Saved'); expect(out).toContain('Undo'); expect(out).not.toContain('Dismiss notification'); expect(out.match(/<button/g)).toHaveLength(1); });
  it('keeps closed notifications absent with either close-button setting', () => { expect(render({ children: 'Saved', open: false, closeButton: false })).toBe(''); });
});
