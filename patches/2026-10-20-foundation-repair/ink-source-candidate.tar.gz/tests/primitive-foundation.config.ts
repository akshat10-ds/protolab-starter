import { defineConfig } from 'vitest/config';
import path from 'node:path';
export default defineConfig({
  resolve: { alias: { '@': path.resolve(__dirname, '../protolab-source/src') } },
  test: { include: ['tests/primitive-foundation.test.ts', 'tests/icons-standard.test.ts', 'tests/ai-badge.test.ts'], environment: 'node' },
});
