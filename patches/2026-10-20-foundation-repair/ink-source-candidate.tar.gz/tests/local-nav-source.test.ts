import { it, expect } from 'vitest';
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { LocalNav } from '@/design-system';

const sections = [{ id: 'agreements', items: [
  { id: 'folders', label: 'Folders', icon: 'folder' as const, hasMenu: true, active: true },
  { id: 'drafts', label: 'Drafts', icon: 'folder' as const, hasMenu: true },
] }];
const render = (isLocked = true) => renderToStaticMarkup(React.createElement(LocalNav, { sections, isLocked }));

it('provides independent named native navigation and item menu buttons', () => {
  const html = render();
  const buttons = [...html.matchAll(/<button\b([^>]*)>([\s\S]*?)<\/button>/g)];
  const folders = buttons.find(([, , content]) => content.includes('>Folders<'));
  expect(folders).toBeDefined();
  expect(folders![1]).toContain('type="button"');
  expect(folders![1]).toContain('aria-current="page"');
  expect(folders![2]).not.toContain('More options');
  expect(buttons.some(([, attrs]) => attrs.includes('aria-label="More options for Folders"'))).toBe(true);
  expect(buttons.some(([, attrs]) => attrs.includes('aria-label="More options for Drafts"'))).toBe(true);
  expect(html).not.toContain('role="button"');
});

it('never nests a native button inside another interactive navigation action', () => {
  const html = render();
  const stack: Array<{ tag: string; interactive: boolean }> = [];
  const voids = new Set(['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr']);
  for (const match of html.matchAll(/<(\/?)([a-z][a-z0-9]*)\b([^>]*)>/gi)) {
    const [, closing, tag, attrs] = match;
    if (closing) { stack.splice(stack.map(entry => entry.tag).lastIndexOf(tag)); continue; }
    if (tag === 'button') expect(stack.some(entry => entry.interactive), `Nested button in ${stack.map(entry => entry.tag).join('>')}`).toBe(false);
    if (!voids.has(tag) && !attrs.endsWith('/')) stack.push({ tag, interactive: tag === 'button' || tag === 'a' || /role="(?:button|link)"/.test(attrs) });
  }
});

it('preserves named icon-only collapsed rows without exposing expanded menu actions', () => {
  const html = render(false);
  expect(html).toMatch(/<button[^>]*aria-label="Folders"/);
  expect(html).not.toContain('More options for Folders');
});
