/** Full authoring-source contract gate. AI_SOURCE_ROOT optionally adds canonical AI. */
import { readFileSync, readdirSync, existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
const project = fileURLToPath(new URL('../', import.meta.url));
const require = createRequire(path.join(project, 'template/ink-starter/package.json'));
const ts = require('typescript');
const source = path.resolve(process.env.PROTOLAB_ROOT ?? path.join(project, 'protolab-source'));
const ink = path.join(source, 'src/design-system');
const ai = process.env.AI_SOURCE_ROOT && path.resolve(process.env.AI_SOURCE_ROOT);
const walk = dir => readdirSync(dir, { withFileTypes: true }).flatMap(entry =>
  entry.isDirectory() ? walk(path.join(dir, entry.name)) : [path.join(dir, entry.name)]);
const allSourceFiles = [ink, ...(ai ? [ai] : [])].flatMap(walk);
for (const file of allSourceFiles.filter(file => /\.jsx?$/.test(file))) {
  const stem = file.replace(/\.jsx?$/, '');
  if (existsSync(stem + '.ts') || existsSync(stem + '.tsx')) throw new Error(`JavaScript shadows authoring source: ${file}. Checks must use noEmit.`);
}
const sourceFiles = allSourceFiles
  .filter(file => /\.(?:tsx?|css)$/.test(file));
const definitions = new Set(sourceFiles.flatMap(file =>
  [...readFileSync(file, 'utf8').matchAll(/(--ink-[\w-]+)\s*:/g)].map(match => match[1])));
const missing = [];
for (const file of sourceFiles.filter(file => !file.endsWith('.figma.ts'))) {
  readFileSync(file, 'utf8').split('\n').forEach((line, index) => {
    for (const [, name] of line.matchAll(/var\((--ink-[\w-]+)/g)) {
      if (!definitions.has(name)) missing.push(`${path.relative(project, file)}:${index + 1}: ${name}`);
    }
  });
}
const ambientPath = path.join(source, 'src/__authoring_environment__.d.ts');
const viteClient = path.join(path.dirname(require.resolve('vite/package.json')), 'client.d.ts');
const ambient = `/// <reference path="${viteClient}" />`;
const options = {
  target: ts.ScriptTarget.ES2020, module: ts.ModuleKind.ESNext,
  moduleResolution: ts.ModuleResolutionKind.Bundler, jsx: ts.JsxEmit.ReactJSX,
  strict: true, skipLibCheck: true, noEmit: true, esModuleInterop: true,
  lib: ['lib.es2020.d.ts', 'lib.dom.d.ts', 'lib.dom.iterable.d.ts'], types: [],
  baseUrl: project,
  paths: { '@/*': [path.join(source, 'src/*')], '@ink': [ink], '@ink/*': [path.join(ink, '*')],
    ...(ai ? { '@ai': [ai], '@ai/*': [path.join(ai, '*')] } : {}) },
};
const host = ts.createCompilerHost(options);
const readFile = host.readFile.bind(host), fileExists = host.fileExists.bind(host);
host.readFile = file => file === ambientPath ? ambient : readFile(file);
host.fileExists = file => file === ambientPath || fileExists(file);
const program = ts.createProgram([...sourceFiles.filter(file => /\.tsx?$/.test(file)), ambientPath], options, host);
const diagnostics = ts.getPreEmitDiagnostics(program);
if (diagnostics.length || missing.length) {
  if (diagnostics.length) process.stderr.write(ts.formatDiagnosticsWithColorAndContext(diagnostics, {
    getCanonicalFileName: file => file, getCurrentDirectory: () => project, getNewLine: () => '\n',
  }));
  if (missing.length) process.stderr.write(`Undefined Ink tokens:\n${missing.join('\n')}\n`);
  process.exitCode = 1;
} else {
  console.log(`Full Ink${ai ? ' + AI candidate' : ''} source contracts pass; zero undefined token references.`);
}
