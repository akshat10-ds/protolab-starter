/** Prepare a private AI compatibility copy seeded by an existing released used set plus dependency closure.
 * This is not the live-prototype closure computation or a publication workflow.
 * Usage: node scripts/prepare-ai-used-set.mjs <canonical-ai> <current-used-set> <new-output>
 */
import { readdirSync, readFileSync, existsSync, mkdirSync, writeFileSync, copyFileSync } from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
const [canonicalArg, currentArg, outputArg] = process.argv.slice(2);
if (!outputArg) throw new Error('Expected canonical AI, current released used set, and new output paths.');
const canonical = path.resolve(canonicalArg), current = path.resolve(currentArg), output = path.resolve(outputArg);
if (existsSync(output)) throw new Error(`Output already exists; preserve it before preparing another candidate: ${output}`);
const walk = dir => readdirSync(dir, { withFileTypes: true }).flatMap(entry =>
  entry.isDirectory() ? walk(path.join(dir, entry.name)) : [path.join(dir, entry.name)]);
const seedFiles = walk(current).map(file => path.relative(current, file)).sort();
const fileSet = new Set(seedFiles);
const publicTargets = new Map();
const sourceBarrel = readFileSync(path.join(canonical, 'index.ts'), 'utf8');
for (const [, names, target] of sourceBarrel.matchAll(/export\s+(?:type\s+)?\{([\s\S]*?)\}\s+from\s+['"](\.[^'"]+)['"]/g)) {
  for (const item of names.split(',')) { const [name, alias] = item.trim().split(/\s+as\s+/); if (name) publicTargets.set(alias ?? name, target); }
}
const resolveSource = base => ['', '.ts', '.tsx', '.css', '/index.ts', '/index.tsx'].map(suffix => base + suffix).find(file => existsSync(file) && !readdirSafe(file));
function readdirSafe(file) { try { readdirSync(file); return true; } catch { return false; } }
const pending = [...seedFiles.filter(file => file !== 'index.ts' && /\.(?:tsx?|css)$/.test(file))];
const seen = new Set();
const unresolved = [];
while (pending.length) {
  const file = pending.shift();
  if (seen.has(file)) continue;
  seen.add(file);
  const text = readFileSync(path.join(canonical, file), 'utf8');
  const targets = [...text.matchAll(/(?:from\s*|import\s*|@import\s*)['"]([^'"]+)['"]/g)].map(match => match[1]);
  for (const [, names] of text.matchAll(/import\s+(?:type\s+)?\{([^{}]*)\}\s+from\s*['"]@ai['"]/g)) {
    for (const item of names.split(',')) { const name = item.trim().replace(/^type\s+/, '').split(/\s+as\s+/)[0]; const target = publicTargets.get(name); if (target) targets.push('@ai/' + target.slice(2)); }
  }
  for (const [, target] of text.matchAll(/(?:url\(|new URL\(\s*)['"](\.[^'"]+)['"]/g)) targets.push(target);
  for (const target of targets) {
    const base = target.startsWith('.') ? path.resolve(canonical, path.dirname(file), target) : target.startsWith('@ai/') ? path.resolve(canonical, target.slice(4)) : null;
    if (!base) continue;
    const resolved = resolveSource(base);
    if (!resolved) { unresolved.push(`${file}: ${target}`); continue; }
    if (!resolved.startsWith(canonical + path.sep)) throw new Error('AI source dependency escapes its canonical root.');
    const relative = path.relative(canonical, resolved);
    if (!fileSet.has(relative)) { fileSet.add(relative); if (/\.(?:tsx?|css)$/.test(relative)) pending.push(relative); }
  }
}
if (unresolved.length) throw new Error(`Canonical dependency resolution failed: ${unresolved.join('\n')}`);
// Specs and usage guidance travel with the components in the resulting closure.
for (const file of [...fileSet]) {
  for (const name of ['SPEC.md', 'README.md']) { const candidate = path.join(path.dirname(file), name); if (existsSync(path.join(canonical, candidate))) fileSet.add(candidate); }
}
const files = [...fileSet].sort();
const missing = files.filter(file => !existsSync(path.join(canonical, file)));
if (missing.length) throw new Error(`Current released paths missing in canonical source: ${missing.join(', ')}`);
for (const file of files) {
  const destination = path.join(output, file);
  mkdirSync(path.dirname(destination), { recursive: true });
  copyFileSync(path.join(canonical, file), destination);
}
const index = path.join(output, 'index.ts');
const removedExports = [];
let barrel = readFileSync(index, 'utf8').replace(/export\s+(?:type\s+)?(?:\{[\s\S]*?\}|\*)\s+from\s+['"](\.\/[^'"]+)['"];?/g, (statement, target) => {
  const base = path.resolve(output, target);
  if (['.ts', '.tsx', '/index.ts'].some(suffix => existsSync(base + suffix))) return statement;
  removedExports.push(target);
  return '';
});
if (removedExports.length) barrel += '\n// Unused parts remain lab-only. Canonical source: akshat-lab/system/ai-system.\n';
writeFileSync(index, barrel);
const readme = path.join(output, 'README.md');
writeFileSync(readme, '> **Generated. Do not edit here.** This directory is a released copy of the used set of `akshat-lab/system/ai-system`, replaced wholesale by the reviewed AI release workflow. Edits made here are lost on the next release. The canonical source is Lab HQ.\n\n' + readFileSync(readme, 'utf8'));
const hash = file => createHash('sha256').update(readFileSync(file)).digest('hex');
const manifest = {
  scope: 'Private compatibility candidate seeded by the existing released file set plus its canonical source/asset closure; not a published release or newly computed live-prototype used set.',
  canonical, current, output, fileCount: files.length, seedFileCount: seedFiles.length, addedPaths: files.filter(file => !seedFiles.includes(file)), removedExports,
  files: files.map(file => ({ path: file, canonicalSha256: hash(path.join(canonical, file)), outputSha256: hash(path.join(output, file)), transformed: file === 'index.ts' || file === 'README.md' })),
};
writeFileSync(output + '.manifest.json', JSON.stringify(manifest, null, 2) + '\n');
console.log(`Prepared ${files.length} AI used-set files at ${output}; relative source/asset closure passes.`);
