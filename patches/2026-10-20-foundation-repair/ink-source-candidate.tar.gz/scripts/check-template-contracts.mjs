/** Run after bundle + template generation and installing the template's dev dependencies. */
import { readFileSync, existsSync } from 'node:fs';
import { strict as assert } from 'node:assert';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const project = fileURLToPath(new URL('../', import.meta.url));
const authoringSource = path.join(path.resolve(process.env.PROTOLAB_ROOT ?? path.join(project, 'protolab-source')), 'src');
const template = fileURLToPath(new URL('../template/ink-starter/', import.meta.url));
const require = createRequire(path.join(template, 'package.json'));
const ts = require('typescript');
const configFile = ts.readConfigFile(path.join(template, 'tsconfig.json'), ts.sys.readFile);
if (configFile.error) throw new Error(ts.flattenDiagnosticMessageText(configFile.error.messageText, '\n'));
const config = ts.parseJsonConfigFileContent(configFile.config, ts.sys, template);
const probePath = path.join(template, 'src/__public_api_contracts__.tsx');
const bundle = JSON.parse(readFileSync(new URL('../data/bundle.json', import.meta.url), 'utf8'));
// Exact delivery parity catches lost barrels, types, motion and component assets.
const delivered = new Map([bundle.tokens, bundle.utility, ...Object.values(bundle.sources).flat(), ...(bundle.infrastructure ?? [])]
  .map(file => [file.path, file.content]));
for (const [file, content] of delivered) {
  if (existsSync(authoringSource)) {
    const authored = path.join(authoringSource, file);
    assert.ok(existsSync(authored), `Bundle retains a removed authoring file: ${file}`);
    assert.ok(readFileSync(authored, 'utf8') === content, `Bundle is stale against authoring source: ${file}`);
  }
  const output = path.join(template, 'src', file);
  assert.ok(existsSync(output), `Template lost source file: ${file}`);
  assert.equal(readFileSync(output, 'utf8'), content, `Template changed source contract: ${file}`);
}
const exampleNames = Object.keys(bundle.registry.components).filter(name => name !== 'Typography');
const exampleProbe = `import { ${exampleNames.join(', ')} } from '@/design-system';\n` +
  Object.entries(bundle.registry.components).map(([name, meta], index) =>
    `// ${name} registry example\nconst registryExample${index} = <>${meta.examples?.join('\n') ?? ''}</>;`
  ).join('\n');
const examplePath = path.join(template, 'src/__registry_examples__.tsx');
const probe = `
import * as React from 'react';
import { Button, IconButton, FilterTag, Text, Tooltip, Popover, Dropdown, Portal } from '@/design-system';
import type { DataTableColumn, LocalNavProps, DropdownItemProps } from '@/design-system';
import type { GlobalNavProps } from '@/design-system/5-patterns/GlobalNav';
const columns: DataTableColumn<{ id: string }>[] = [{ key: 'id', header: 'ID' }];
const nav: LocalNavProps = { sections: [] };
const globalNav: GlobalNavProps = {};
const items: DropdownItemProps[] = [{ label: 'Open' }];
const valid = <>
  <Button kind="primary">Save</Button>
  <IconButton icon="close" variant="tertiary" aria-label="Close" />
  <FilterTag label="Status" ref={React.createRef<HTMLButtonElement>()} />
  <FilterTag label="Status" dismissible ref={React.createRef<HTMLDivElement>()} />
  <Tooltip text="Help"><Button>Help</Button></Tooltip>
  <Popover content="Details"><Button>Details</Button></Popover>
  <Dropdown items={items}><Button>Actions</Button></Dropdown>
</>;
// @ts-expect-error Button uses kind.
const invalidButton = <Button variant="primary">Save</Button>;
// @ts-expect-error IconButton uses variant.
const invalidIconButton = <IconButton icon="close" kind="tertiary" aria-label="Close" />;
// @ts-expect-error Text uses size.
const invalidText = <Text variant="body">Copy</Text>;
// @ts-expect-error FilterTag cannot forward an SVG element ref.
const invalidRef = <FilterTag label="Status" ref={React.createRef<SVGSVGElement>()} />;
void [Portal, columns, nav, globalNav, valid, invalidButton, invalidIconButton, invalidText, invalidRef];
`;
const host = ts.createCompilerHost(config.options);
const readFile = host.readFile.bind(host);
const fileExists = host.fileExists.bind(host);
host.readFile = file => file === probePath ? probe : file === examplePath ? exampleProbe : readFile(file);
host.fileExists = file => file === probePath || file === examplePath || fileExists(file);
const program = ts.createProgram([...config.fileNames, probePath, examplePath], { ...config.options, noEmit: true }, host);
const diagnostics = [...config.errors, ...ts.getPreEmitDiagnostics(program)];
if (diagnostics.length) {
  process.stderr.write(ts.formatDiagnosticsWithColorAndContext(diagnostics, {
    getCanonicalFileName: file => file,
    getCurrentDirectory: () => template,
    getNewLine: () => '\n',
  }));
  process.exitCode = 1;
} else {
  console.log('Generated template, source delivery parity, registry examples and public API contracts pass.');
}
