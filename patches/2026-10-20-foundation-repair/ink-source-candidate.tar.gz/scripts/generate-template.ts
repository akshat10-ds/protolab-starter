/**
 * Generate a standalone template project with the complete ProtoLab component catalog.
 *
 * Reads from data/bundle.json (same source bundle-data.ts produces) and outputs
 * a complete Vite + React + TypeScript project to template/ink-starter/.
 *
 * Also generates a downloadable zip at public/downloads/ink-starter-kit.zip.
 *
 * Usage:
 *   npx tsx scripts/generate-template.ts
 *   npm run template
 */

import { readFileSync, writeFileSync, mkdirSync, copyFileSync, existsSync, readdirSync } from 'fs';
import { join, dirname } from 'path';
import { createHash } from 'crypto';
import { execSync } from 'child_process';
import {
  packageJson,
  VITE_CONFIG,
  TSCONFIG,
  indexHtml,
  MAIN_TSX,
  SOURCE_SHADOW_GUARD,
  SOURCE_SHADOW_TEST,
  INDEX_CSS_WITH_FONTS,
  LAYER_DIR,
  componentBarrel,
  layerBarrel,
  mainBarrel,
  generateFontsCss,
  FONT_VARIANTS,
} from '../src/shared/project-templates';

// ── Config ───────────────────────────────────────────────────────────

const PROJECT_ROOT = join(__dirname, '..');
const BUNDLE_PATH = join(PROJECT_ROOT, 'data/bundle.json');
const TEMPLATE_DIR = join(PROJECT_ROOT, 'template/ink-starter');
const DOWNLOADS_DIR = join(PROJECT_ROOT, 'public/downloads');
const FONTS_DIR = join(PROJECT_ROOT, 'public/fonts');
const LOGO_PATH = join(PROJECT_ROOT, 'public/docusign-logo.svg');

interface SourceFile {
  path: string;
  content: string;
}

interface ComponentMeta {
  name: string;
  layer: number;
  type: string;
  description: string;
  sourceComponent?: string;
  [key: string]: unknown;
}

interface Bundle {
  registry: { components: Record<string, ComponentMeta> };
  sources: Record<string, SourceFile[]>;
  tokens: SourceFile;
  utility: SourceFile;
  infrastructure?: SourceFile[];
}

// ── Helpers ──────────────────────────────────────────────────────────

function ensureDir(dir: string) {
  mkdirSync(dir, { recursive: true });
}

function writeFile(filePath: string, content: string) {
  ensureDir(dirname(filePath));
  writeFileSync(filePath, content, 'utf-8');
}

function copyFile(src: string, dest: string) {
  ensureDir(dirname(dest));
  copyFileSync(src, dest);
}

// ── Main ─────────────────────────────────────────────────────────────

function generate() {
  console.log('Generating template project...');

  // 1. Load bundle
  const bundle: Bundle = JSON.parse(readFileSync(BUNDLE_PATH, 'utf-8'));
  const components = Object.values(bundle.registry.components);
  console.log(`  Loaded ${components.length} components from bundle`);

  // 2. Clean output directory
  if (existsSync(TEMPLATE_DIR)) {
    execSync(`rm -rf "${TEMPLATE_DIR}"`);
  }
  ensureDir(TEMPLATE_DIR);

  // 3. Write boilerplate files
  writeFile(join(TEMPLATE_DIR, 'scripts/check-source-shadows.mjs'), SOURCE_SHADOW_GUARD);
  writeFile(join(TEMPLATE_DIR, 'scripts/check-source-shadows.test.mjs'), SOURCE_SHADOW_TEST);
  writeFile(join(TEMPLATE_DIR, 'package.json'), packageJson('protolab-starter'));
  writeFile(join(TEMPLATE_DIR, 'vite.config.ts'), VITE_CONFIG);
  writeFile(join(TEMPLATE_DIR, 'tsconfig.json'), TSCONFIG);
  writeFile(join(TEMPLATE_DIR, 'index.html'), indexHtml('ProtoLab Starter'));
  writeFile(join(TEMPLATE_DIR, 'src/main.tsx'), MAIN_TSX);
  writeFile(join(TEMPLATE_DIR, 'src/index.css'), INDEX_CSS_WITH_FONTS);
  console.log('  Wrote boilerplate files');

  // 4. Write all component source files
  const layerComponents = new Map<number, string[]>();
  const virtualToHost = new Map<string, string>();
  const hostVirtuals = new Map<string, string[]>();
  let fileCount = 0;

  // Build virtual component mappings
  for (const comp of components) {
    if (comp.sourceComponent) {
      virtualToHost.set(comp.name, comp.sourceComponent);
      const list = hostVirtuals.get(comp.sourceComponent) ?? [];
      list.push(comp.name);
      hostVirtuals.set(comp.sourceComponent, list);
    }
  }

  // Write source files and track layers
  for (const comp of components) {
    const layer = comp.layer;

    // Track layer membership (skip hosts that only exist for virtual exports)
    const isHostOnly = hostVirtuals.has(comp.name) && (hostVirtuals.get(comp.name)!.length > 0);
    if (!isHostOnly || !virtualToHost.has(comp.name)) {
      const layerList = layerComponents.get(layer) ?? [];
      // Virtual components appear in the layer list under their own name
      if (virtualToHost.has(comp.name)) {
        layerList.push(comp.name);
      } else if (!isHostOnly) {
        layerList.push(comp.name);
      }
      layerComponents.set(layer, layerList);
    }

    // Skip virtual components for file writing (their host's files contain them)
    if (virtualToHost.has(comp.name)) continue;

    const sourceKey = `${comp.name}:${layer}`;
    const sourceFiles = bundle.sources[sourceKey];
    if (!sourceFiles) {
      console.warn(`  Warning: No source files for ${sourceKey}`);
      continue;
    }

    for (const file of sourceFiles) {
      const destPath = join(TEMPLATE_DIR, 'src', file.path);
      writeFile(destPath, file.content);
      fileCount++;
    }
  }

  // Sort layer components
  for (const [layer, names] of layerComponents) {
    layerComponents.set(layer, [...new Set(names)].sort());
  }

  console.log(`  Wrote ${fileCount} component source files`);

  // 5. Generate barrel exports
  // Component-level barrels
  for (const comp of components) {
    if (virtualToHost.has(comp.name)) continue; // skip virtuals

    const layerDir = LAYER_DIR[comp.layer];
    if (!layerDir) continue;

    const barrelPath = join(TEMPLATE_DIR, `src/design-system/${layerDir}/${comp.name}/index.ts`);
    const virtualExports = hostVirtuals.get(comp.name);
    // The component's published index may also expose types/subcomponents.
    if (!existsSync(barrelPath)) {
      writeFile(barrelPath, componentBarrel(comp.name, virtualExports));
    }
  }

  // Layer-level barrels
  for (const [layer, names] of layerComponents) {
    const dir = LAYER_DIR[layer];
    if (!dir) continue;
    const barrelPath = join(TEMPLATE_DIR, `src/design-system/${dir}/index.ts`);
    writeFile(barrelPath, layerBarrel(names, virtualToHost));
  }

  // Main barrel
  writeFile(
    join(TEMPLATE_DIR, 'src/design-system/index.ts'),
    mainBarrel(layerComponents)
  );
  // Prefer the authoritative public API when a full source bundle includes it.
  // Legacy bundles retain the generated-barrel fallback above.
  for (const file of bundle.infrastructure ?? []) {
    writeFile(join(TEMPLATE_DIR, 'src', file.path), file.content);
  }
  console.log('  Generated barrel exports');

  // 6. Write infrastructure files
  writeFile(
    join(TEMPLATE_DIR, `src/${bundle.tokens.path}`),
    bundle.tokens.content
  );
  writeFile(
    join(TEMPLATE_DIR, `src/${bundle.utility.path}`),
    bundle.utility.content
  );

  // 7. Generate fonts.css (relative paths for local project)
  writeFile(
    join(TEMPLATE_DIR, 'src/styles/fonts.css'),
    generateFontsCss('/fonts')
  );

  // 8. Copy font files
  let fontsCopied = 0;
  for (const variant of FONT_VARIANTS) {
    const fontDir = `DSIndigo-${variant}`;
    const fontFile = `DSIndigo-${variant}.woff2`;
    const src = join(FONTS_DIR, fontDir, fontFile);
    if (existsSync(src)) {
      copyFile(src, join(TEMPLATE_DIR, `public/fonts/${fontDir}/${fontFile}`));
      fontsCopied++;
    }
  }
  console.log(`  Copied ${fontsCopied} font files`);

  // 9. Copy logo
  if (existsSync(LOGO_PATH)) {
    copyFile(LOGO_PATH, join(TEMPLATE_DIR, 'public/docusign-logo.svg'));
  }

  // 10. Write demo App.tsx
  writeFile(join(TEMPLATE_DIR, 'src/App.tsx'), generateDemoApp());

  // 11. Write version.json
  const bundleContent = readFileSync(BUNDLE_PATH, 'utf-8');
  const bundleHash = createHash('sha256').update(bundleContent).digest('hex').slice(0, 16);
  const version = {
    version: '1.0.0',
    buildTimestamp: new Date().toISOString(),
    componentCount: components.length,
    bundleHash,
  };
  writeFile(join(TEMPLATE_DIR, 'version.json'), JSON.stringify(version, null, 2));

  // 12. Write .gitignore for the template project
  writeFile(join(TEMPLATE_DIR, '.gitignore'), [
    'node_modules/',
    'dist/',
    '.DS_Store',
    '',
  ].join('\n'));

  console.log(`  Template ready at template/ink-starter/`);

  // 13. Generate zip for download
  generateZip();

  // Summary
  console.log(`\nTemplate generation complete:`);
  console.log(`  ${components.length} registered components (including host and virtual entries)`);
  console.log(`  ${fileCount} source files`);
  console.log(`  ${fontsCopied} font files`);
  console.log(`  Bundle hash: ${bundleHash}`);
}

function generateDemoApp(): string {
  return `import { useState } from 'react';
import {
  DocuSignShell,
  AgreementTableView,
  PageHeader,
  FilterBar,
  DataTable,
  Button,
  Badge,
  Icon,
} from '@/design-system';

/* ═══════════════════════════════════════
   GlobalNav Config
   ALWAYS include: logo, 5 navItems, showSearch,
   showNotifications, showSettings, and user.
   ═══════════════════════════════════════ */

const globalNavConfig = {
  logo: <img src="/docusign-logo.svg" alt="DocuSign" />,
  navItems: [
    { id: 'home', label: 'Home', href: '#' },
    { id: 'agreements', label: 'Agreements', href: '#', active: true },
    { id: 'templates', label: 'Templates', href: '#' },
    { id: 'reports', label: 'Reports', href: '#' },
    { id: 'admin', label: 'Admin', href: '#' },
  ],
  showSearch: true,
  showNotifications: true,
  notificationCount: 3,
  showSettings: true,
  user: { name: 'Jane Smith' },
};

/* ═══════════════════════════════════════
   LocalNav Config
   Use headerLabel + headerMenuItems for the
   "Start" button dropdown. Include 4-5 items.
   ═══════════════════════════════════════ */

const localNavConfig = {
  headerLabel: 'Start',
  headerIcon: 'plus' as const,
  headerMenuItems: [
    { id: 'new-agreement', label: 'New Agreement', icon: 'edit' as const },
    { id: 'new-template', label: 'New Template', icon: 'star' as const },
    { id: 'upload', label: 'Upload Document', icon: 'upload' as const },
  ],
  sections: [
    {
      id: 'agreements',
      items: [
        { id: 'all-agreements', label: 'All Agreements', icon: 'inbox' as const, active: true },
        { id: 'drafts', label: 'Drafts', nested: true },
        { id: 'in-progress', label: 'In Progress', nested: true },
        { id: 'completed', label: 'Completed', nested: true },
        { id: 'deleted', label: 'Deleted', nested: true },
      ],
    },
    {
      id: 'folders',
      title: 'Folders',
      collapsible: true,
      defaultExpanded: true,
      items: [
        { id: 'folders-item', label: 'Folders', icon: 'folder' as const, hasMenu: true },
      ],
      hasDivider: true,
    },
    {
      id: 'features',
      hasDivider: true,
      items: [
        { id: 'parties', label: 'Parties', icon: 'users' as const, badge: 'New' },
        { id: 'requests', label: 'Requests', icon: 'send' as const, badge: 'New' },
        { id: 'maestro', label: 'Maestro Workflows', icon: 'list' as const, badge: 'New' },
        { id: 'workspaces', label: 'Workspaces', icon: 'grid' as const },
        { id: 'powerforms', label: 'PowerForms', icon: 'zap' as const },
        { id: 'bulk-send', label: 'Bulk Send', icon: 'copy' as const },
      ],
    },
  ],
};

/* ═══════════════════════════════════════
   DataTable Config
   Data-driven: NO children. Pass columns + data.
   Tables are NOT wrapped in Cards (DocuSign convention).
   ═══════════════════════════════════════ */

interface Agreement {
  id: string;
  name: string;
  status: string;
  statusKind: 'success' | 'warning' | 'emphasis' | 'subtle';
  sender: string;
  lastUpdated: string;
}

const columns = [
  { key: 'name', header: 'Agreement Name', sortable: true },
  {
    key: 'status',
    header: 'Status',
    sortable: true,
    cell: (row: Agreement) => (
      <Badge kind={row.statusKind}>{row.status}</Badge>
    ),
  },
  { key: 'sender', header: 'Sender' },
  { key: 'lastUpdated', header: 'Last Updated', sortable: true },
];

const agreements: Agreement[] = [
  { id: '1', name: 'NDA - Acme Corporation', status: 'Completed', statusKind: 'success', sender: 'John Doe', lastUpdated: 'Mar 24, 2026' },
  { id: '2', name: 'MSA - TechStart Inc', status: 'Waiting for Review', statusKind: 'warning', sender: 'Jane Smith', lastUpdated: 'Mar 23, 2026' },
  { id: '3', name: 'SOW - Phase 2 Development', status: 'Draft', statusKind: 'subtle', sender: 'Jane Smith', lastUpdated: 'Mar 22, 2026' },
  { id: '4', name: 'Employment Agreement - Senior Engineer', status: 'Completed', statusKind: 'success', sender: 'HR Team', lastUpdated: 'Mar 21, 2026' },
  { id: '5', name: 'Vendor Agreement - CloudCo', status: 'Waiting for Signature', statusKind: 'emphasis', sender: 'John Doe', lastUpdated: 'Mar 20, 2026' },
  { id: '6', name: 'Lease Amendment - Office Space', status: 'Completed', statusKind: 'success', sender: 'Legal Team', lastUpdated: 'Mar 19, 2026' },
  { id: '7', name: 'Consulting Agreement - DesignLab', status: 'Action Required', statusKind: 'warning', sender: 'Jane Smith', lastUpdated: 'Mar 18, 2026' },
];

/* ═══════════════════════════════════════
   App — List Page (Navigator Style)
   DocuSignShell > AgreementTableView > DataTable
   ═══════════════════════════════════════ */

export default function App() {
  const [search, setSearch] = useState('');

  return (
    <DocuSignShell
      globalNav={globalNavConfig}
      localNav={localNavConfig}
    >
      <AgreementTableView
        pageHeader={
          <PageHeader
            title="Agreements"
            showAIBadge
            actions={<Button kind="primary">New Agreement</Button>}
          />
        }
        filterBar={
          <FilterBar
            search={{
              value: search,
              onChange: setSearch,
              placeholder: 'Try keywords, phrases, or a question',
            }}
            showSearchIndicator
            filters={
              <Button kind="secondary" size="small" startElement={<Icon name="filter" size={14} />}>
                Filters
              </Button>
            }
          />
        }
      >
        <DataTable
          columns={columns}
          data={agreements}
          getRowKey={(row) => row.id}
          selectable
          stickyHeader
          pagination={{
            page: 1,
            pageSize: 25,
            totalItems: 127,
            onPageChange: () => {},
            onPageSizeChange: () => {},
            showInfo: true,
          }}
        />
      </AgreementTableView>
    </DocuSignShell>
  );
}
`;
}

function generateZip() {
  ensureDir(DOWNLOADS_DIR);
  const zipPath = join(DOWNLOADS_DIR, 'ink-starter-kit.zip');

  // Remove old zip if exists
  if (existsSync(zipPath)) {
    execSync(`rm "${zipPath}"`);
  }

  // Create zip from template directory
  // -r recursive, -q quiet, zip from parent so paths inside are ink-starter/...
  try {
    execSync(`cd "${dirname(TEMPLATE_DIR)}" && zip -rq "${zipPath}" ink-starter`);
    const stats = readFileSync(zipPath);
    const sizeMB = (stats.length / 1024 / 1024).toFixed(1);
    console.log(`  Generated zip: public/downloads/ink-starter-kit.zip (${sizeMB}MB)`);
  } catch (e) {
    // zip might not be available (e.g. some CI environments)
    console.warn('  Warning: zip command not available, skipping zip generation');
    console.warn('  Install zip or run on a system with zip available');
  }
}

// ── Run ──────────────────────────────────────────────────────────────
generate();
