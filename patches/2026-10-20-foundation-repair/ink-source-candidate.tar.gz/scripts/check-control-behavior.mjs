/** Browser regression checks for shared overlay/search contracts. No app or account writes. */
import { createRequire } from 'node:module';
import { mkdtempSync, readFileSync, writeFileSync, realpathSync } from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createServer } from 'node:http';
import { strict as assert } from 'node:assert';
const project = fileURLToPath(new URL('../', import.meta.url));
const require = createRequire(path.join(project, 'template/ink-starter/package.json'));
const { build } = require('vite');
// Supply an existing Playwright installation; this check never installs packages.
const playwrightPath = process.env.PLAYWRIGHT_MODULE ?? 'playwright';

const output = realpathSync(mkdtempSync(path.join(os.tmpdir(), 'protolab-controls-')));
const source = path.resolve(process.env.PROTOLAB_ROOT ?? path.join(project, 'protolab-source'));
const entry = `
import React, {useState, useRef} from 'react';
import {createRoot} from 'react-dom/client';
import {Button, Dropdown, Popover, SearchInput, Stack, Text} from '${source}/src/design-system';
import '${source}/src/design-system/1-tokens/tokens.css';
const events = [];
const record = event => { events.push(event); document.querySelector('#events').textContent = JSON.stringify(events); };
function Harness() {
 const [search, setSearch] = useState('');
 const [showSearch, setShowSearch] = useState(true);
 const popoverTrigger = useRef(null);
 return <Stack>
  <div onClick={() => record('parent-click')}>
   <Dropdown variant="solid" items={[
    {section:'Group'}, {label:'Disabled parent',disabled:true,children:[{label:'Never'}]},
    {label:'First',onClick:()=>record('first')},{divider:true},
    {label:'Nested',children:[{section:'Nested group'}, {label:'Disabled child',disabled:true,onClick:()=>record('disabled')},
     {label:'Chosen',selected:true,shortcut:'⌘K',onClick:()=>record('chosen')}, {divider:true},
     {label:'Delete item',kind:'alert',endElement:<Text>End slot</Text>,onClick:()=>record('delete')}]},
    {label:'Last',onClick:()=>record('last')}
   ]}><Button onClick={()=>record('trigger')}>Actions</Button></Dropdown>
  </div>
  <Dropdown items={[]}><Button onClick={event=>event.preventDefault()}>Prevented</Button></Dropdown>
  <Dropdown closeOnItemClick={false} items={[{label:'Keep open',onClick:()=>record('kept')}]}><Button>Persistent</Button></Dropdown>
  <Popover label="Info" content={<Text>Popover details</Text>}><Button ref={popoverTrigger} onClick={()=>record('popover:'+Boolean(popoverTrigger.current))}>Information</Button></Popover>
  {showSearch && <SearchInput aria-label="Search agreements" value={search} debounceMs={200}
    onChange={value=>{setSearch(value);record('search:'+value)}} onFocus={()=>record('focus')} onKeyDown={event=>record('key:'+event.key)}
    suggestions={[{id:'alpha',label:'Alpha'},{id:'beta',label:'Beta'}]} />}
  <Button onClick={()=>setShowSearch(false)}>Unmount search</Button>
  <Button>Outside</Button>
  <output id="events">[]</output>
 </Stack>;
}
createRoot(document.getElementById('root')).render(<Harness />);
`;
writeFileSync(path.join(output, 'main.tsx'), entry);
writeFileSync(path.join(output, 'index.html'), '<!doctype html><html><head></head><body><div id="root"></div><script type="module" src="/main.tsx"></script></body></html>');
await build({ root: output, configFile: false, logLevel: 'silent',
  resolve: { alias: {
    '@': path.join(source, 'src'),
    'react': path.dirname(require.resolve('react/package.json')),
    'react-dom': path.dirname(require.resolve('react-dom/package.json')),
  } }, build: { outDir: 'dist', emptyOutDir: true } });
if (process.argv.includes('--build-only')) {
  console.log(`Browser fixture build passes at ${path.join(output, 'dist')}`);
  process.exit(0);
}
const { chromium } = require(playwrightPath);
const server = createServer((request, response) => {
  const requested = (request.url ?? '/').split('?')[0];
  const file = requested === '/' ? '/index.html' : requested;
  const destination = path.resolve(output, 'dist', '.' + file);
  if (!destination.startsWith(path.join(output, 'dist') + path.sep)) { response.statusCode = 404; response.end(); return; }
  response.setHeader('Content-Type', file.endsWith('.js') ? 'text/javascript' : file.endsWith('.css') ? 'text/css' : file.endsWith('.svg') ? 'image/svg+xml' : 'text/html');
  response.end(readFileSync(destination));
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
let browser;
const checks = [];
try {
  console.error('Browser harness listening on', server.address().port);
  browser = await chromium.launch({ channel: 'chrome', headless: true, timeout: 15000 });
  const page = await browser.newPage({ viewport: { width: 1000, height: 800 } });
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await page.goto(`http://127.0.0.1:${server.address().port}`);
  const events = async () => JSON.parse(await page.locator('#events').textContent());
  const activeName = () => page.evaluate(() => document.activeElement?.textContent);
  await page.getByRole('button', { name: 'Actions', exact: true }).click();
  await page.waitForFunction(() => document.activeElement?.textContent === 'First');
  assert.equal((await events()).filter(event => event === 'trigger').length, 1);
  assert.ok(!(await events()).includes('parent-click'));
  checks.push('Trigger handler fires once and does not activate parent');
  await page.keyboard.press('ArrowDown');
  assert.match(await activeName(), /Nested/);
  await page.keyboard.press('ArrowRight');
  await page.waitForFunction(() => document.activeElement?.textContent?.includes('Chosen'));
  assert.equal(await page.getByRole('menuitemcheckbox', { name: /Chosen/ }).getAttribute('aria-checked'), 'true');
  assert.ok(await page.getByRole('menuitem', { name: 'Disabled child' }).isDisabled());
  await page.keyboard.press('ArrowDown');
  assert.match(await activeName(), /Delete item/);
  await page.keyboard.press('ArrowLeft');
  assert.match(await activeName(), /Nested/);
  await page.keyboard.press('ArrowRight');
  await page.getByRole('menuitemcheckbox', { name: /Chosen/ }).click();
  assert.equal(await page.getByRole('menu').count(), 0);
  assert.equal(await activeName(), 'Actions');
  assert.equal((await events()).filter(event => event === 'chosen').length, 1);
  checks.push('Nested disabled, divider, selected, shortcut and keyboard states');
  await page.getByRole('button', { name: 'Prevented' }).click();
  assert.equal(await page.getByRole('menu').count(), 0);
  await page.getByRole('button', { name: 'Persistent' }).click();
  await page.getByRole('menuitem', { name: 'Keep open' }).click();
  assert.equal(await page.getByRole('menu').count(), 1);
  await page.getByRole('button', { name: 'Outside', exact: true }).click();
  assert.equal(await page.getByRole('menu').count(), 0);
  checks.push('Prevent-default, persistent selection and outside dismissal');
  await page.getByRole('button', { name: 'Information' }).click();
  assert.ok(await page.getByRole('dialog', { name: 'Info' }).isVisible());
  assert.ok((await events()).includes('popover:true'));
  await page.keyboard.press('Escape');
  assert.equal(await page.getByRole('dialog').count(), 0);
  assert.equal(await activeName(), 'Information');
  checks.push('Popover preserves trigger ref and dismisses with focus restoration');
  const search = page.getByRole('combobox', { name: 'Search agreements' });
  await search.fill('draft');
  assert.equal(await search.inputValue(), 'draft');
  await page.getByRole('button', { name: 'Clear search' }).click();
  await page.waitForTimeout(250);
  assert.ok(!(await events()).includes('search:draft'));
  assert.ok((await events()).includes('search:'));
  await search.fill('al');
  await search.press('ArrowDown');
  assert.equal(await page.getByRole('option', { name: 'Alpha' }).getAttribute('aria-selected'), 'true');
  await search.press('Enter');
  await page.waitForTimeout(250);
  assert.ok((await events()).includes('search:Alpha'));
  assert.ok(!(await events()).includes('search:al'));
  checks.push('Controlled debounced search displays immediately and cancels stale clear/select callbacks');
  await search.fill('unmounted');
  await search.press('Escape');
  await page.getByRole('button', { name: 'Unmount search' }).click();
  await page.waitForTimeout(250);
  assert.ok(!(await events()).includes('search:unmounted'));
  assert.deepEqual(errors, []);
  checks.push('Debounce is cleaned up on unmount; browser has no uncaught errors');
  console.log(JSON.stringify({ checks, status: 'pass' }, null, 2));
} finally {
  await browser?.close();
  await new Promise(resolve => server.close(resolve));
}
