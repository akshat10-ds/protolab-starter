> **Note:** ProtoLab is a prototyping tool for vision and ideation. The code generated uses a structural scaffold and is not 1:1 with the production ds/ui library. A standard engineering refactor is required for production implementation.

# ProtoLab MCP

ProtoLab — Docusign's Visual Language (Optimized for Prototyping). A remote MCP server exposing the complete ProtoLab component catalog via tools, prompts, and resources for AI-assisted prototyping.

## What This Is

ProtoLab accelerates vision & ideation by giving AI assistants access to Docusign's visual language as ideation-ready components. It generates high-fidelity scaffolding for rapid prototyping — components optimized for prototyping (not for production use).

## Quick Start

```bash
npm install
npm run dev          # Start dev server (localhost:3000)
npm run build        # Bundle data + Next.js build
```

## MCP Connection

Add to your `.mcp.json`:

```json
{
  "mcpServers": {
    "protolab": {
      "type": "http",
      "url": "https://protolab-mcp.vercel.app/api/mcp"
    }
  }
}
```

## Architecture

See [CLAUDE.md](./CLAUDE.md) for full architecture documentation.
