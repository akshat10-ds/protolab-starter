import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  // Ensure bundle.json is included in the serverless function
  outputFileTracingIncludes: {
    '/api/*': ['./data/bundle.json'],
  },

  // Serve starter kit static files with caching
  headers: async () => [
    {
      source: '/starter/:path*',
      headers: [
        { key: 'Cache-Control', value: 'public, max-age=3600' },
      ],
    },
    {
      source: '/source/:path*',
      headers: [
        { key: 'Cache-Control', value: 'public, max-age=31536000, immutable' },
        { key: 'Access-Control-Allow-Origin', value: '*' },
      ],
    },
    {
      source: '/fonts/:path*',
      headers: [
        { key: 'Cache-Control', value: 'public, max-age=31536000, immutable' },
        { key: 'Access-Control-Allow-Origin', value: '*' },
      ],
    },
    {
      source: '/downloads/:path*',
      headers: [
        { key: 'Cache-Control', value: 'public, max-age=3600' },
        { key: 'Content-Disposition', value: 'attachment' },
      ],
    },
  ],
};

export default nextConfig;
