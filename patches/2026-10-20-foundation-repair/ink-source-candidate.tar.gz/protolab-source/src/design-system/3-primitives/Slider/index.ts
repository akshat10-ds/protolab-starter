export { Slider } from './Slider';
