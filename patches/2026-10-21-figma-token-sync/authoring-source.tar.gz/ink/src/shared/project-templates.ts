/**
 * Shared project template utilities used by both:
 * - scaffold_project MCP tool (subset of components)
 * - generate-template script (all components)
 */

// ── Font files ───────────────────────────────────────────────────────
export const FONT_VARIANTS = [
  'Regular', 'Light', 'Medium', 'SemiBold', 'Bold', 'Black',
  'Italic', 'LightItalic', 'MediumItalic', 'SemiBoldItalic', 'BoldItalic', 'BlackItalic',
];
export const FONT_FILES = FONT_VARIANTS.map(v => `fonts/DSIndigo-${v}/DSIndigo-${v}.woff2`);

// ── Layer directory names ────────────────────────────────────────────
export const LAYER_DIR: Record<number, string> = {
  2: '2-utilities',
  3: '3-primitives',
  4: '4-composites',
  5: '5-patterns',
  6: '6-layouts',
};

// ── Boilerplate templates ────────────────────────────────────────────

export function packageJson(projectName: string): string {
  return JSON.stringify(
    {
      name: projectName,
      private: true,
      type: 'module',
      scripts: {
        dev: 'vite',
        build: 'node scripts/check-source-shadows.mjs && tsc --noEmit && vite build',
        typecheck: 'node scripts/check-source-shadows.mjs && tsc --noEmit',
        'test:source-shadows': 'node --test scripts/check-source-shadows.test.mjs',
        preview: 'vite preview',
      },
      dependencies: {
        agentation: '^3.0.2',
        'lucide-react': '^0.487.0',
        react: '^19.0.0',
        'react-dom': '^19.0.0',
      },
      devDependencies: {
        typescript: '~5.7.0',
        vite: '^6.3.0',
        '@vitejs/plugin-react-swc': '^3.10.0',
        '@types/react': '^19.0.0',
        '@types/react-dom': '^19.0.0',
      },
    },
    null,
    2
  );
}

export const VITE_CONFIG = `import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react-swc';
import path from 'node:path';

export default defineConfig({
  plugins: [react()],
  resolve: { alias: { '@': path.resolve(__dirname, './src') } },
  server: { port: 3000, open: true },
});
`;

export const TSCONFIG = JSON.stringify(
  {
    compilerOptions: {
      target: 'ES2020',
      module: 'ESNext',
      moduleResolution: 'bundler',
      jsx: 'react-jsx',
      strict: true,
      noEmit: true,
      esModuleInterop: true,
      skipLibCheck: true,
      types: ['vite/client'],
      paths: { '@/*': ['./src/*'] },
      baseUrl: '.',
    },
    include: ['src'],
  },
  null,
  2
);

export function indexHtml(projectName: string): string {
  return `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>${projectName}</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
`;
}

export const MAIN_TSX = `import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
`;

export const INDEX_CSS_WITH_FONTS = `@import './styles/fonts.css';

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html, body, #root { height: 100%; }

html {
  -webkit-text-size-adjust: 100%;
  line-height: 1.5;
}

body {
  font-family: var(--ink-font-family, 'DS Indigo', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif);
  color: var(--ink-font-default);
  background-color: var(--ink-bg-default);
  -webkit-font-smoothing: antialiased;
}

button, input, select, textarea { font: inherit; color: inherit; }
img, svg { display: block; max-width: 100%; }
`;

export const INDEX_CSS_NO_FONTS = `/* Ink tokens are loaded by the public design-system barrel. */

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html, body, #root { height: 100%; }

html {
  -webkit-text-size-adjust: 100%;
  line-height: 1.5;
}

body {
  font-family: var(--ink-font-family, 'DS Indigo', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif);
  color: var(--ink-font-default);
  background-color: var(--ink-bg-default);
  -webkit-font-smoothing: antialiased;
}

button, input, select, textarea { font: inherit; color: inherit; }
img, svg { display: block; max-width: 100%; }
`;

// ── Barrel export generation ─────────────────────────────────────────

/**
 * Generate a barrel file for a component directory.
 * For host components that have virtual children (e.g. Typography hosts Heading+Text),
 * export both the host and virtual names from the same directory.
 */
export function componentBarrel(componentName: string, _virtualExports?: string[]): string {
  return `export * from './${componentName}';\n`;
}

/** A subset layer keeps every public type and subcomponent of its selected hosts. */
export function layerBarrel(componentNames: string[], virtualToHost: Map<string, string>): string {
  return [...new Set(componentNames.map(name => virtualToHost.get(name) ?? name))]
    .map(dir => `export * from './${dir}';`).join('\n') + '\n';
}

export function mainBarrel(layerComponents: Map<number, string[]>): string {
  return "import './1-tokens/tokens.css';\n" + [2, 3, 4, 5, 6].filter(layer => layerComponents.get(layer)?.length)
    .map(layer => `export * from './${LAYER_DIR[layer]}';`).join('\n') + '\n';
}

/**
 * Generate font-face CSS declarations.
 * @param fontBaseUrl - base URL for font files (e.g. "/fonts" for local, "https://..." for CDN)
 */
export function generateFontsCss(fontBaseUrl: string): string {
  const faces = FONT_VARIANTS.map(v => {
    const weight = v.includes('Light') ? '300'
      : v.includes('SemiBold') ? '600'
      : v.includes('Bold') && !v.includes('Semi') ? '700'
      : v.includes('Black') ? '900'
      : v.includes('Medium') ? '500'
      : '400';
    const style = v.includes('Italic') ? 'italic' : 'normal';
    return `@font-face {
  font-family: 'DS Indigo';
  font-style: ${style};
  font-weight: ${weight};
  font-display: swap;
  src: url('${fontBaseUrl}/DSIndigo-${v}/DSIndigo-${v}.woff2') format('woff2');
}`;
  });
  return faces.join('\n\n') + '\n';
}

export const SOURCE_SHADOW_GUARD = "import { existsSync, readdirSync } from 'node:fs';\nimport { resolve, join } from 'node:path';\nimport { fileURLToPath } from 'node:url';\n\nexport function findSourceShadows(root) {\n  if (!existsSync(root)) return [];\n  const results = [];\n  for (const entry of readdirSync(root, { withFileTypes: true })) {\n    const path = join(root, entry.name);\n    if (entry.isDirectory()) results.push(...findSourceShadows(path));\n    else if (/\\.(js|jsx)$/.test(path) && ['.ts', '.tsx'].some(extension => existsSync(path.replace(/\\.(js|jsx)$/, extension)))) results.push(path);\n  }\n  return results.sort();\n}\n\nif (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {\n  const shadows = findSourceShadows(resolve(process.argv[2] ?? 'src'));\n  if (shadows.length) {\n    console.error('JavaScript files shadow TypeScript source. Preserve and remove emitted outputs before continuing:\\n' + shadows.join('\\n'));\n    process.exitCode = 1;\n  } else console.log('Source shadow check passed.');\n}\n";

export const SOURCE_SHADOW_TEST = "import { test } from 'node:test';\nimport assert from 'node:assert/strict';\nimport { mkdtempSync, mkdirSync, writeFileSync, rmSync } from 'node:fs';\nimport { tmpdir } from 'node:os';\nimport { join } from 'node:path';\nimport { findSourceShadows } from './check-source-shadows.mjs';\n\ntest('detects nested emitted siblings without flagging standalone JavaScript', () => {\n  const root = mkdtempSync(join(tmpdir(), 'protolab-shadow-check-'));\n  try {\n    mkdirSync(join(root, 'nested'));\n    for (const file of ['App.tsx', 'App.js', 'nested/utils.ts', 'nested/utils.js', 'standalone.js']) writeFileSync(join(root, file), '');\n    assert.deepEqual(findSourceShadows(root), [join(root, 'App.js'), join(root, 'nested/utils.js')]);\n    assert.deepEqual(findSourceShadows(join(root, 'absent')), []);\n  } finally { rmSync(root, { recursive: true, force: true }); }\n});\n";
