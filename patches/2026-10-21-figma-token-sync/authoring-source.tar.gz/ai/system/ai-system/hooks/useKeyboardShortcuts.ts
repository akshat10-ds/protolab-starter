/**
 * useKeyboardShortcuts — Keyboard shortcut registry hook
 *
 * Registers global keyboard shortcuts with support for modifier keys
 * and conditional activation. Shortcuts are cleaned up on unmount.
 */

import { useEffect, useRef } from 'react';

// =============================================================================
// Types
// =============================================================================

export interface KeyboardShortcut {
  /** Key name (e.g., 'a', 'Escape', '/', 's') */
  key: string;
  /** Requires Cmd (Mac) or Ctrl (Windows) */
  meta?: boolean;
  /** Requires Shift */
  shift?: boolean;
  /** Requires Alt/Option */
  alt?: boolean;
  /** Handler function */
  handler: () => void;
  /** Human-readable description for help display */
  description?: string;
  /** Conditional — only fire when this returns true */
  when?: () => boolean;
}

// =============================================================================
// Hook
// =============================================================================

export function useKeyboardShortcuts(shortcuts: KeyboardShortcut[]): void {
  const shortcutsRef = useRef(shortcuts);
  shortcutsRef.current = shortcuts;

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Skip if user is typing in an input/textarea/contenteditable
      const target = e.target as HTMLElement;
      if (
        target instanceof HTMLInputElement ||
        target instanceof HTMLTextAreaElement ||
        target.isContentEditable
      ) {
        // Still allow Escape in inputs
        if (e.key !== 'Escape') return;
      }

      for (const shortcut of shortcutsRef.current) {
        const keyMatch = e.key.toLowerCase() === shortcut.key.toLowerCase();
        const metaMatch = shortcut.meta
          ? e.metaKey || e.ctrlKey
          : !e.metaKey && !e.ctrlKey;
        const shiftMatch = shortcut.shift ? e.shiftKey : !e.shiftKey;
        const altMatch = shortcut.alt ? e.altKey : !e.altKey;

        if (keyMatch && metaMatch && shiftMatch && altMatch) {
          // Check conditional
          if (shortcut.when && !shortcut.when()) continue;

          e.preventDefault();
          shortcut.handler();
          return;
        }
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);
}
