/**
 * A minimal conversation for demos, the Playground, and prototypes.
 *
 * This replaces the frozen prototype's 1,938-line `data/scenarios.ts` for
 * demo purposes. It is a fixture, not a scenario engine: there is no matcher,
 * no fallback, no affirmative-continuation. Feed it to `IrisAgent` as
 * `messages` and handle `onSendMessage` however the demo needs.
 */

import type { ChatMessage } from '../types';

export const SAMPLE_CITATIONS = {
  '1': {
    id: 'src-1',
    title: 'Acme Corp MSA v2',
    excerpt:
      'Section 4.2 — Indemnification covers direct damages only, capped at fees paid in the preceding 12 months.',
    documentTitle: 'Acme Corp MSA v2',
  },
};

export const SAMPLE_CONVERSATION: ChatMessage[] = [
  {
    id: 'm1',
    role: 'user',
    content: 'What are the biggest risks in the Acme MSA?',
    timestamp: new Date('2026-07-09T10:00:00'),
  },
  {
    id: 'm2',
    role: 'assistant',
    content: '',
    timestamp: new Date('2026-07-09T10:00:04'),
    thinkingSteps: [
      {
        kind: 'thinking',
        title: 'Understanding the request',
        text: 'The user wants risk exposure, not a full summary. Focus on liability, term, and termination.',
      },
      { kind: 'searching', title: 'Searching agreements', result: '3 matches' },
      { kind: 'reading', title: 'Reading Acme Corp MSA v2', toolIcon: 'document' },
      { kind: 'done', title: 'Drafting the analysis' },
    ],
    markdownContent:
      'Three provisions carry most of the exposure.\n\n' +
      '**Liability cap is low.** Section 4.2 caps damages at 12 months of fees [1], below ' +
      'our 24-month standard for engagements of this scope.\n\n' +
      '**Auto-renewal has a 90-day notice window.** Miss it and the term extends a full year.\n\n' +
      '**The non-compete runs 24 months**, likely unenforceable under California law.',
    citations: SAMPLE_CITATIONS,
    taskCompletion: {
      summary: 'Reviewed 3 agreements, found 3 material risks',
      status: 'completed',
      followUps: [
        { id: 'draft-amendment', label: 'Draft an amendment for Section 4.2' },
        { id: 'compare-caps', label: 'Compare liability caps across vendors' },
      ],
    },
  },
  {
    id: 'm3',
    role: 'user',
    content: 'draft-amendment',
    elicitationQuestion: 'Draft an amendment for Section 4.2',
    timestamp: new Date('2026-07-09T10:01:00'),
  },
  {
    id: 'm4',
    role: 'assistant',
    content: "Here's a redline raising the cap to 24 months of aggregate fees.",
    timestamp: new Date('2026-07-09T10:01:03'),
  },
];

/** The cold-state suggestions that pair with the conversation above. */
export const SAMPLE_SUGGESTIONS = [
  { label: 'Find risks in my portfolio' },
  { label: 'Compare agreement terms across vendors' },
  { label: 'Summarize the Acme MSA' },
];
