/**
 * ArtifactPanel — Resizable right-side panel for agent outputs
 *
 * Multi-tab, type-aware artifact rendering with open/close animation,
 * drag-to-resize on the left edge, and fullscreen toggle.
 * Inspired by Claude's artifact panel pattern.
 */

import React, { useState, useEffect, useCallback } from 'react';
import { Icon, IconButton } from '@ink';
import { usePanelResize } from '../../hooks/usePanelResize';
import { ArtifactViewer } from '../ArtifactViewer/ArtifactViewer';
import type { ArtifactViewerType } from '../ArtifactViewer/ArtifactViewer';
import styles from './ArtifactPanel.module.css';

// =============================================================================
// Types
// =============================================================================

export interface ArtifactTab {
  id: string;
  title: string;
  type: ArtifactViewerType;
  content: React.ReactNode;
  language?: string;
}

export interface ArtifactPanelProps {
  /** List of artifact tabs */
  tabs: ArtifactTab[];
  /** Currently active tab ID */
  activeTabId?: string;
  /** Called when a tab is selected */
  onTabChange?: (tabId: string) => void;
  /** Called when the panel is closed */
  onClose?: () => void;
  /** Whether the panel is open */
  isOpen?: boolean;
  /** Default panel width in px */
  defaultWidth?: number;
  /** Minimum panel width in px */
  minWidth?: number;
}

// =============================================================================
// Component
// =============================================================================

export const ArtifactPanel: React.FC<ArtifactPanelProps> = ({
  tabs,
  activeTabId,
  onTabChange,
  onClose,
  isOpen = true,
  defaultWidth = 420,
  minWidth = 280,
}) => {
  const [internalActiveTab, setInternalActiveTab] = useState(tabs[0]?.id);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const currentTabId = activeTabId || internalActiveTab;
  const activeTab = tabs.find((t) => t.id === currentTabId) || tabs[0];

  const resize = usePanelResize({
    initialWidth: defaultWidth,
    minWidth,
    defaultWidth,
    direction: 'left',
    snapToCloseThreshold: 0,
  });

  const handleTabChange = (tabId: string) => {
    setInternalActiveTab(tabId);
    onTabChange?.(tabId);
  };

  const toggleFullscreen = useCallback(() => {
    setIsFullscreen((prev) => !prev);
  }, []);

  // Escape key exits fullscreen
  useEffect(() => {
    if (!isFullscreen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsFullscreen(false);
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isFullscreen]);

  if (!isOpen || tabs.length === 0) return null;

  return (
    <div
      className={styles.panel}
      style={isFullscreen ? undefined : { width: resize.width }}
      data-fullscreen={isFullscreen || undefined}
      data-resizing={resize.isResizing || undefined}
    >
      {/* Drag handle (hidden in fullscreen) */}
      {!isFullscreen && (
        <div
          className={styles.dragHandle}
          onPointerDown={resize.handlePointerDown}
          role="separator"
          aria-orientation="vertical"
          aria-label="Resize artifact panel"
        />
      )}

      {/* Tab bar */}
      <div className={styles.tabBar}>
        <div className={styles.tabs}>
          {tabs.length > 1 &&
            tabs.map((tab) => (
              <button
                key={tab.id}
                type="button"
                className={styles.tab}
                data-active={tab.id === currentTabId}
                onClick={() => handleTabChange(tab.id)}
              >
                <Icon name={getTypeIcon(tab.type) as any} size={14} />
                <span className={styles.tabLabel}>{tab.title}</span>
              </button>
            ))}
          {tabs.length <= 1 && activeTab && (
            <span className={styles.singleTabTitle}>{activeTab.title}</span>
          )}
        </div>
        <div className={styles.headerActions}>
          <IconButton
            icon={isFullscreen ? 'arrows-in' : 'arrows-out'}
            size="small"
            variant="tertiary"
            onClick={toggleFullscreen}
            aria-label={isFullscreen ? 'Exit fullscreen' : 'Enter fullscreen'}
          />
          {onClose && (
            <IconButton
              icon="close"
              size="small"
              variant="tertiary"
              onClick={onClose}
              aria-label="Close panel"
            />
          )}
        </div>
      </div>

      {/* Viewer */}
      {activeTab && (
        <div className={styles.viewerContainer}>
          <ArtifactViewer
            title={activeTab.title}
            type={activeTab.type}
            content={activeTab.content}
            language={activeTab.language}
            onClose={tabs.length <= 1 ? onClose : undefined}
          />
        </div>
      )}
    </div>
  );
};

function getTypeIcon(type: ArtifactViewerType): string {
  const icons: Record<ArtifactViewerType, string> = {
    document: 'document',
    code: 'code',
    table: 'table',
    custom: 'layout-grid',
  };
  return icons[type];
}
