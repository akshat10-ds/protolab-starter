/**
 * SourceDiscoveryView — Agreement search + selection for artifact panel
 *
 * Three states:
 * 1. Discovery (no selections): heading + search + bottom accordions
 * 2. Search results (query submitted): FilterBar + full DataTable
 * 3. Sources loaded (committed): "Sources (N)" + selected list + suggested accordion
 *
 * Inspired by NotebookLM's sources panel pattern.
 *
 * `variant="picker"` is a FOURTH state and the one shipping Iris draws: the
 * table is there the moment the surface opens, search filters it live, the
 * selection count stands above it with a "Show Selected Agreements" toggle, and
 * the footer's commit is drawn-but-disabled at zero rather than hidden. Wrap it
 * in `SourcePickerModal` for the centered "Add Sources" dialog.
 */

import React, { useState, useMemo, useCallback } from 'react';
import {
  Icon,
  Checkbox,
  Button,
  Chip,
  Input,
  IconButton,
  FilterBar,
  DataTable,
  AIIcon,
  Link,
  Modal,
  dataTableStyles,
} from '@ink';
import type { DataTableColumn } from '@ink';
/* Direct path, not `@ai`: the barrel exports this file, and a barrel round-trip
   is a module cycle that only shows up as an undefined component at runtime. */
import { SuggestionChip } from '../../primitives/SuggestionChip/SuggestionChip';
import styles from './SourceDiscoveryView.module.css';

// =============================================================================
// Types
// =============================================================================

export interface DiscoveryAgreement {
  id: string;
  fileName: string;
  agreementType: string;
  parties?: string[];
  status?: string;
  /** Overrides the Active/Inactive label the status derives ("Effective Soon"). */
  statusLabel?: string;
  /** The quiet second line under the status — "Renews 7/30/2027", "Expired 1/31/2025". */
  statusDate?: string;
  effectiveDate?: string;
  expirationDate?: string;
  contractValue?: string;
  isAIAssisted?: boolean;
  fileStatus?: string;
  fileStatusDetail?: string;
}

export interface DiscoveryAction {
  label: string;
  icon?: string;
  /** IDs of agreements to auto-select when this action is clicked */
  agreementIds?: string[];
}

export interface SourceDiscoveryViewProps {
  /** All available agreements to search/browse */
  agreements: DiscoveryAgreement[];
  /** Action chips shown in Smart Suggestions accordion */
  actions?: DiscoveryAction[];
  /** Called when user confirms selection (via button or action chip) */
  onSelect?: (selectedIds: Set<string>, query?: string) => void;
  /** Called when the panel should expand/contract */
  onRequestResize?: (width: 'narrow' | 'wide') => void;
  /**
   * `discovery` (default) is the NotebookLM-shaped panel view. `picker` is the
   * shipping Add Sources surface: table first, live search, selection bar,
   * footer count. Additive — an existing consumer keeps `discovery`.
   */
  variant?: 'discovery' | 'picker';
  /** What is already attached, so re-opening the picker arrives pre-checked. */
  initialSelectedIds?: string[];
  /** Overrides the picker's commit label. */
  commitLabel?: string;
}

// =============================================================================
// Helpers
// =============================================================================

function capitalize(s: string) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

// =============================================================================
// Component
// =============================================================================

export const SourceDiscoveryView: React.FC<SourceDiscoveryViewProps> = ({
  agreements,
  actions = [],
  onSelect,
  onRequestResize,
  variant = 'discovery',
  initialSelectedIds,
  commitLabel = 'Add to Sources',
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [submittedSearch, setSubmittedSearch] = useState('');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(
    () => new Set(initialSelectedIds ?? [])
  );
  /** The picker's "Show Selected Agreements" filter. Only what you picked. */
  const [showSelectedOnly, setShowSelectedOnly] = useState(false);
  const [committed, setCommitted] = useState(false);
  const [suggestionsOpen, setSuggestionsOpen] = useState(false);
  const [smartSuggestionsOpen, setSmartSuggestionsOpen] = useState(false);
  const [isAddingMore, setIsAddingMore] = useState(false);
  const [tableSelectedRows, setTableSelectedRows] = useState<Set<string | number>>(new Set());

  const isSearchMode = submittedSearch.length > 0 && (!committed || isAddingMore);

  // Filter agreements by submitted search
  const searchResults = useMemo(() => {
    if (!submittedSearch.trim()) return [];
    const q = submittedSearch.toLowerCase();
    return agreements.filter(
      (a) =>
        a.fileName.toLowerCase().includes(q) ||
        a.agreementType.toLowerCase().includes(q) ||
        (a.parties ?? []).some((p) => p.toLowerCase().includes(q))
    );
  }, [agreements, submittedSearch]);

  // Filter for accordion (uses live search query)
  const filtered = useMemo(() => {
    if (!searchQuery.trim()) return agreements;
    const q = searchQuery.toLowerCase();
    return agreements.filter(
      (a) =>
        a.fileName.toLowerCase().includes(q) ||
        a.agreementType.toLowerCase().includes(q) ||
        (a.parties ?? []).some((p) => p.toLowerCase().includes(q))
    );
  }, [agreements, searchQuery]);

  const allSelected = filtered.length > 0 && filtered.every((a) => selectedIds.has(a.id));

  const selectedAgreements = useMemo(
    () => agreements.filter((a) => selectedIds.has(a.id)),
    [agreements, selectedIds]
  );

  const unselectedAgreements = useMemo(
    () => agreements.filter((a) => !selectedIds.has(a.id)),
    [agreements, selectedIds]
  );

  const toggleItem = useCallback((id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const removeItem = useCallback((id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      next.delete(id);
      // If all sources removed, snap back to discovery
      if (next.size === 0) {
        setCommitted(false);
        setIsAddingMore(false);
        onSelect?.(next);
      } else {
        onSelect?.(next);
      }
      return next;
    });
  }, [onSelect]);

  const handleSelectAll = useCallback(() => {
    if (allSelected) {
      setSelectedIds((prev) => {
        const next = new Set(prev);
        filtered.forEach((a) => next.delete(a.id));
        return next;
      });
    } else {
      setSelectedIds((prev) => {
        const next = new Set(prev);
        filtered.forEach((a) => next.add(a.id));
        return next;
      });
    }
  }, [allSelected, filtered]);

  const handleConfirm = useCallback(() => {
    setCommitted(true);
    setIsAddingMore(false);
    setSubmittedSearch('');
    setSearchQuery('');
    onRequestResize?.('narrow');
    onSelect?.(selectedIds);
  }, [onSelect, onRequestResize, selectedIds]);

  const handleTableConfirm = useCallback(() => {
    // Merge table selection with existing selections
    const merged = new Set(selectedIds);
    tableSelectedRows.forEach((id) => merged.add(String(id)));
    setSelectedIds(merged);
    setCommitted(true);
    setIsAddingMore(false);
    setSubmittedSearch('');
    setSearchQuery('');
    setTableSelectedRows(new Set());
    onRequestResize?.('narrow');
    onSelect?.(merged, submittedSearch);
  }, [onSelect, onRequestResize, selectedIds, tableSelectedRows, submittedSearch]);

  const handleActionClick = useCallback(
    (action: DiscoveryAction) => {
      const ids = action.agreementIds
        ? new Set(action.agreementIds)
        : new Set(agreements.map((a) => a.id));
      setSelectedIds(ids);
      setCommitted(true);
      setIsAddingMore(false);
      setSubmittedSearch('');
      onRequestResize?.('narrow');
      onSelect?.(ids, action.label);
    },
    [onSelect, onRequestResize, agreements]
  );

  const handleSearchSubmit = useCallback(() => {
    const q = searchQuery.trim();
    if (q) {
      setSubmittedSearch(q);
      // Pre-select already-selected rows in the DataTable
      setTableSelectedRows(new Set(selectedIds));
      onRequestResize?.('wide');
    }
  }, [searchQuery, selectedIds, onRequestResize]);

  const handleClearSearch = useCallback(() => {
    setSearchQuery('');
    setSubmittedSearch('');
    setTableSelectedRows(new Set());
    onRequestResize?.('narrow');
  }, [onRequestResize]);

  const addSource = useCallback((id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      next.add(id);
      return next;
    });
  }, []);

  const count = selectedIds.size;
  const tableCount = tableSelectedRows.size;
  /** DataTable's key set is `string | number`; ours is `string`. One widening. */
  const tableSelection = useMemo<Set<string | number>>(() => new Set(selectedIds), [selectedIds]);
  const noun = count === 1 ? 'agreement' : 'agreements';

  // ── DataTable columns for search results ──
  const isPicker = variant === 'picker';
  const tableColumns: DataTableColumn<DiscoveryAgreement>[] = useMemo(
    () => [
      {
        key: 'aiAssisted',
        header: '',
        width: '32px',
        sticky: true,
        cell: (row) =>
          row.isAIAssisted ? (
            <span className={dataTableStyles.aiSparkle}>
              <AIIcon name="ai-spark-filled" size={14} />
            </span>
          ) : null,
      },
      {
        key: 'fileName',
        header: isPicker ? 'Original File Name' : 'File Name',
        sortable: true,
        width: isPicker ? '230px' : '280px',
        sticky: true,
        className: dataTableStyles.columnBorderRight,
        cell: (row) => (
          <div className={dataTableStyles.cellContent}>
            {/* Plain text, not a link: the row's checkbox is the interaction here,
                and a name styled as a link that navigates nowhere is a lie. The
                cell's own `.td` supplies the default body colour and weight. */}
            <span>{row.fileName}</span>
            {row.fileStatusDetail && (
              <span className={dataTableStyles.cellSecondary}>
                {row.fileStatus === 'uploaded' ? '↑' : '✓'} {row.fileStatusDetail}
              </span>
            )}
          </div>
        ),
      },
      {
        key: 'parties',
        header: 'Parties',
        width: isPicker ? '160px' : '180px',
        cell: (row) => (
          <div className={dataTableStyles.cellContent}>
            {(row.parties ?? []).length > 0 ? (
              (row.parties ?? []).map((party, i) => (
                <span key={i} className={dataTableStyles.partyChip}>
                  <a href="#" className={dataTableStyles.partyLink}>
                    {party}
                  </a>
                </span>
              ))
            ) : (
              <span className={dataTableStyles.cellSecondary}>—</span>
            )}
          </div>
        ),
      },
      {
        /*
         * TWO LINES, NOT ONE. Shipping draws the dot and Active/Inactive, then a
         * quiet second line saying what happens next — "Renews 7/30/2027",
         * "Expired 1/31/2025". `statusDate` carries that line verbatim because
         * only the record knows whether a date is a renewal or an expiry;
         * `expirationDate` is the fallback when it does not say.
         */
        key: 'status',
        header: 'Status',
        sortable: true,
        width: '110px',
        cell: (row) => {
          const sub = row.statusDate ?? (row.expirationDate ? `Expires ${row.expirationDate}` : null);
          return (
            <div className={dataTableStyles.statusCell}>
              <span className={dataTableStyles.statusDot} data-status={row.status} />
              <div className={dataTableStyles.statusText}>
                <span className={dataTableStyles.statusLabel}>
                  {row.statusLabel ?? capitalize(row.status ?? 'active')}
                </span>
                {sub && <span className={dataTableStyles.statusDate}>{sub}</span>}
              </div>
            </div>
          );
        },
      },
      {
        key: 'agreementType',
        header: 'Agreement Type',
        sortable: true,
        width: isPicker ? '170px' : '180px',
        sortValue: (row) => row.agreementType,
        cell: (row) =>
          row.agreementType ? <Chip>{row.agreementType}</Chip> : <span>&mdash;</span>,
      },
      /*
       * SHIPPING'S PICKER STOPS AT FIVE COLUMNS — checkbox, file name, parties,
       * status, type. The money and date columns below belong to the search
       * ARTIFACT, where column room is the reason the pane is open; in a modal
       * they only push status and type off the right edge. Same column set,
       * two budgets.
       */
      ...(isPicker
        ? []
        : [
            {
              key: 'contractValue',
              header: 'Contract Value',
              sortable: true,
              width: '150px',
              alignment: 'right' as const,
              cell: (row: DiscoveryAgreement) => row.contractValue || '—',
            },
            {
              key: 'effectiveDate',
              header: 'Effective Date',
              sortable: true,
              width: '120px',
              cell: (row: DiscoveryAgreement) => row.effectiveDate || '—',
            },
            {
              key: 'expirationDate',
              header: 'Expiration Date',
              sortable: true,
              width: '130px',
              cell: (row: DiscoveryAgreement) => row.expirationDate || '—',
            },
          ]),
    ],
    [isPicker]
  );

  // =========================================================================
  // State 4: Picker — the shipping Add Sources surface
  //
  // The table is there on open; search filters it live rather than waiting on a
  // submit; the count stands above it and can filter down to itself; and the
  // commit is DRAWN and disabled at zero, never hidden. That last one is the
  // difference from the search-results footer below, which swaps in a Back
  // button instead — a control that appears on first selection reads as a
  // surprise, and this surface's whole job is to be selected from.
  // =========================================================================
  if (variant === 'picker') {
    const rows = showSelectedOnly ? filtered.filter((a) => selectedIds.has(a.id)) : filtered;
    return (
      <div className={styles.searchResultsContainer}>
        <div className={styles.searchFilterBar}>
          <FilterBar
            search={{
              value: searchQuery,
              onChange: setSearchQuery,
              placeholder: 'Try keywords or phrases',
            }}
            filters={
              <Button
                kind="secondary"
                size="small"
                startElement={<Icon name="filter" size="small" />}
              >
                Filters
              </Button>
            }
          />
        </div>

        {count > 0 && (
          <div className={styles.selectionBar}>
            <span className={styles.selectionCount}>{count} Selected</span>
            <Link
              discrete
              size="small"
              href="#"
              onClick={(e: React.MouseEvent) => {
                e.preventDefault();
                setShowSelectedOnly((v) => !v);
              }}
            >
              {showSelectedOnly ? 'Show All Agreements' : 'Show Selected Agreements'}
            </Link>
          </div>
        )}

        <div className={styles.searchTableWrap}>
          <DataTable
            columns={tableColumns}
            data={rows}
            getRowKey={(row) => row.id}
            selectable
            selectedRows={tableSelection}
            onSelectionChange={(next) =>
              setSelectedIds(new Set(Array.from(next, (id) => String(id))))
            }
            rowHeight="tall"
            stickyHeader
          />
        </div>

        <div className={styles.pickerFooter}>
          <span className={styles.footerCount}>{count} selected</span>
          <Button
            kind="primary"
            size="medium"
            disabled={count === 0}
            onClick={() => onSelect?.(selectedIds)}
          >
            {commitLabel}
          </Button>
        </div>
      </div>
    );
  }

  // =========================================================================
  // State 3: Search results — FilterBar + DataTable
  // =========================================================================
  if (isSearchMode) {
    return (
      <div className={styles.searchResultsContainer}>
        {/* Filter bar */}
        <div className={styles.searchFilterBar}>
          <FilterBar
            search={{
              value: searchQuery,
              onChange: setSearchQuery,
              onSubmit: handleSearchSubmit,
              placeholder: 'Search agreements...',
            }}
            filters={
              <Button
                kind="secondary"
                size="small"
                startElement={<Icon name="filter" size="small" />}
              >
                Filters
              </Button>
            }
          />
        </div>

        {/* DataTable */}
        <div className={styles.searchTableWrap}>
          <DataTable
            columns={tableColumns}
            data={searchResults}
            getRowKey={(row) => row.id}
            selectable
            selectedRows={tableSelectedRows}
            onSelectionChange={setTableSelectedRows}
            rowHeight="tall"
            stickyHeader
          />
        </div>

        {/* Footer */}
        {tableCount > 0 && (
          <div className={styles.footer}>
            <Button kind="primary" size="medium" onClick={handleTableConfirm} fullWidth>
              Analyze {tableCount} {tableCount === 1 ? 'agreement' : 'agreements'}
            </Button>
          </div>
        )}

        {tableCount === 0 && (
          <div className={styles.footer}>
            <Button kind="secondary" size="medium" onClick={handleClearSearch} fullWidth>
              Back
            </Button>
          </div>
        )}
      </div>
    );
  }

  // =========================================================================
  // State 2: Sources loaded — show selected sources + suggested accordion
  // =========================================================================
  if (committed && !isAddingMore) {
    return (
      <div className={styles.container}>
        {/* Header */}
        <div className={styles.sourcesHeader}>
          <h2 className={styles.sourcesTitle}>Sources ({count})</h2>
          <Button
            kind="secondary"
            size="small"
            startElement={<Icon name="plus" size="small" />}
            onClick={() => setIsAddingMore(true)}
          >
            Add
          </Button>
        </div>

        {/* Selected sources list */}
        <div className={styles.selectedList}>
          {selectedAgreements.map((agreement) => (
            <div key={agreement.id} className={styles.selectedRow}>
              <div className={styles.checkboxWrap}>
                <Checkbox
                  checked
                  onChange={() => removeItem(agreement.id)}
                  label=""
                  showLabel={false}
                />
              </div>
              <span className={styles.selectedName}>{agreement.fileName}</span>
              <IconButton
                icon="close"
                variant="tertiary"
                size="small"
                aria-label={`Remove ${agreement.fileName}`}
                onClick={() => removeItem(agreement.id)}
              />
            </div>
          ))}
        </div>

        {/* Spacer */}
        <div className={styles.spacer} />

        {/* Bottom accordions */}
        <div className={styles.accordionStack}>
          {unselectedAgreements.length > 0 && (
            <div className={styles.accordion} data-open={suggestionsOpen || undefined}>
              <button
                type="button"
                className={styles.accordionTrigger}
                onClick={() => setSuggestionsOpen((v) => !v)}
              >
                <Icon
                  name={suggestionsOpen ? 'chevron-down' : 'chevron-right'}
                  size={16}
                  className={styles.accordionChevron}
                />
                <span className={styles.accordionLabel}>Suggested</span>
              </button>

              {suggestionsOpen && (
                <div className={styles.accordionBody}>
                  <p className={styles.suggestedHint}>
                    Add a source to include in future responses.
                  </p>
                  {unselectedAgreements.map((agreement) => (
                    <div key={agreement.id} className={styles.suggestedRow}>
                      <Icon name="document" size={16} />
                      <span className={styles.suggestedName}>{agreement.fileName}</span>
                      <IconButton
                        icon="plus"
                        variant="tertiary"
                        size="small"
                        aria-label={`Add ${agreement.fileName}`}
                        onClick={() => {
                          addSource(agreement.id);
                          onSelect?.(new Set([...selectedIds, agreement.id]));
                        }}
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {actions.length > 0 && (
            <div className={styles.accordion} data-open={smartSuggestionsOpen || undefined}>
              <button
                type="button"
                className={styles.accordionTrigger}
                onClick={() => setSmartSuggestionsOpen((v) => !v)}
              >
                <Icon
                  name={smartSuggestionsOpen ? 'chevron-down' : 'chevron-right'}
                  size={16}
                  className={styles.accordionChevron}
                />
                <span className={styles.accordionLabel}>Smart Suggestions</span>
              </button>

              {smartSuggestionsOpen && (
                <div className={styles.accordionBody}>
                  <div className={styles.actionChips}>
                    {actions.map((action, i) => (
                      <SuggestionChip
                        key={i}
                        label={action.label}
                        icon={action.icon}
                        onClick={() => handleActionClick(action)}
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    );
  }

  // =========================================================================
  // State 1: Discovery — search + select + bottom accordions
  // =========================================================================
  return (
    <div className={styles.container}>
      {/* Header */}
      <div className={styles.header}>
        <h2 className={styles.heading}>
          {isAddingMore ? 'Add sources' : 'What would you like to analyze?'}
        </h2>
        <p className={styles.subtitle}>
          Select agreements to chat with, or search by name, type, or party.
        </p>
      </div>

      {/* Search */}
      <div className={styles.searchWrap}>
        <Input
          label="Search agreements"
          hideLabel
          startElement={<Icon name="search" size="small" />}
          placeholder="Search agreements..."
          value={searchQuery}
          onChange={(e) => setSearchQuery((e.target as HTMLInputElement).value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') handleSearchSubmit();
          }}
          size="medium"
        />
      </div>

      {/* Suggested sets — quick-select below search */}
      {actions.length > 0 && (
        <div className={styles.suggestedSets}>
          <span className={styles.suggestedSetsLabel}>Suggested sets</span>
          <div className={styles.suggestedSetList}>
            {actions.map((action, i) => (
              <button
                key={i}
                type="button"
                className={styles.suggestedSetRow}
                onClick={() => handleActionClick(action)}
              >
                {action.icon && (
                  <span className={styles.suggestedSetIcon}>
                    <Icon name={action.icon as any} size={16} />
                  </span>
                )}
                <span className={styles.suggestedSetLabel}>{action.label}</span>
                <Icon name="chevron-right" size={14} className={styles.suggestedSetArrow} />
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Spacer */}
      <div className={styles.spacer} />

      {/* Bottom-pinned accordions */}
      <div className={styles.accordionStack}>
        <div className={styles.accordion} data-open={suggestionsOpen || undefined}>
          <button
            type="button"
            className={styles.accordionTrigger}
            onClick={() => setSuggestionsOpen((v) => !v)}
          >
            <Icon
              name={suggestionsOpen ? 'chevron-down' : 'chevron-right'}
              size={16}
              className={styles.accordionChevron}
            />
            <span className={styles.accordionLabel}>Suggested</span>
            {count > 0 && (
              <span className={styles.accordionBadge}>{count} selected</span>
            )}
          </button>

          {suggestionsOpen && (
            <div className={styles.accordionBody}>
              <button type="button" className={styles.selectAll} onClick={handleSelectAll}>
                <div className={styles.checkboxWrap} onClick={(e) => e.stopPropagation()}>
                  <Checkbox
                    checked={allSelected}
                    onChange={handleSelectAll}
                    label=""
                    showLabel={false}
                  />
                </div>
                <span className={styles.selectAllText}>Select all</span>
              </button>

              <div className={styles.divider} />

              <div className={styles.listBody}>
                {filtered.length === 0 ? (
                  <div className={styles.emptyState}>
                    <Icon name="search" size={20} />
                    <span>No agreements match &ldquo;{searchQuery}&rdquo;</span>
                  </div>
                ) : (
                  filtered.map((agreement) => {
                    const isSelected = selectedIds.has(agreement.id);
                    return (
                      <button
                        key={agreement.id}
                        type="button"
                        className={styles.listRow}
                        data-selected={isSelected || undefined}
                        onClick={() => toggleItem(agreement.id)}
                      >
                        <div className={styles.checkboxWrap} onClick={(e) => e.stopPropagation()}>
                          <Checkbox
                            checked={isSelected}
                            onChange={() => toggleItem(agreement.id)}
                            label=""
                            showLabel={false}
                          />
                        </div>
                        <span className={styles.rowName}>{agreement.fileName}</span>
                      </button>
                    );
                  })
                )}
              </div>
            </div>
          )}
        </div>

        {actions.length > 0 && (
          <div className={styles.accordion} data-open={smartSuggestionsOpen || undefined}>
            <button
              type="button"
              className={styles.accordionTrigger}
              onClick={() => setSmartSuggestionsOpen((v) => !v)}
            >
              <Icon
                name={smartSuggestionsOpen ? 'chevron-down' : 'chevron-right'}
                size={16}
                className={styles.accordionChevron}
              />
              <span className={styles.accordionLabel}>Smart Suggestions</span>
            </button>

            {smartSuggestionsOpen && (
              <div className={styles.accordionBody}>
                <div className={styles.actionChips}>
                  {actions.map((action, i) => (
                    <SuggestionChip
                      key={i}
                      label={action.label}
                      icon={action.icon}
                      onClick={() => handleActionClick(action)}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Footer — confirm selection */}
      {count > 0 && (
        <div className={styles.footer}>
          <Button kind="primary" size="medium" onClick={handleConfirm} fullWidth>
            {isAddingMore ? `Update sources (${count})` : `Analyze ${count} ${noun}`}
          </Button>
        </div>
      )}
    </div>
  );
};

// =============================================================================
// SourcePickerModal — the picker, centered, the way shipping presents it
// =============================================================================

export interface SourcePickerModalProps extends SourceDiscoveryViewProps {
  open: boolean;
  onClose: () => void;
  /** Dialog title. Shipping keeps "Add Sources" even when sources are attached. */
  title?: string;
}

/**
 * SHIPPING PRESENTS THE PICKER AS A DIALOG, NOT A PANEL. `SourceDiscoveryView`
 * was drawn for the artifact column, so the modal is a wrapper rather than a
 * mode: the view keeps working in a dock, and a host that wants the shipping
 * shape mounts this instead.
 *
 * The dialog is remounted on every open — `key={String(open)}` — so a cancelled
 * pick does not survive as pre-checked rows the next time it is opened. What
 * IS attached comes back in through `initialSelectedIds`.
 *
 * The host owns `open`, which is what lets two entry points (the composer's
 * `+` menu and the get-started checklist) reach the same surface.
 */
export const SourcePickerModal: React.FC<SourcePickerModalProps> = ({
  open,
  onClose,
  title = 'Add Sources',
  ...viewProps
}) => (
  <Modal open={open} onClose={onClose} title={title} size="xlarge" className={styles.pickerDialog}>
    <div className={styles.pickerModal}>
      <SourceDiscoveryView key={String(open)} variant="picker" {...viewProps} />
    </div>
  </Modal>
);
