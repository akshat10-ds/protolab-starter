/**
 * ChatPanel — Complete chat experience layout
 *
 * Composes a header, scrollable message area with auto-scroll,
 * scroll-to-bottom FAB, suggestions, and input into a full chat panel.
 */

import React, { useRef, useState, useCallback, useEffect } from 'react';
import { Icon, IconButton } from '@ink';
import styles from './ChatPanel.module.css';

// =============================================================================
// Types
// =============================================================================

export interface ChatPanelProps {
  /** Panel title (e.g., agent name) */
  title?: string;
  /** Panel subtitle / status line */
  subtitle?: string;
  /** Custom header content (replaces default title/subtitle) */
  header?: React.ReactNode;
  /** Message list content */
  children: React.ReactNode;
  /** Input area at the bottom */
  input?: React.ReactNode;
  /** Suggestion chips shown above input */
  suggestions?: React.ReactNode;
  /** Called when close button is clicked */
  onClose?: () => void;
  /** Optional header actions (right side) */
  headerActions?: React.ReactNode;

  /** Empty/welcome state — shown when no messages */
  emptyState?: React.ReactNode;
  /** Whether there are messages to display */
  hasMessages?: boolean;
  /** Loading/streaming indicator in header */
  isLoading?: boolean;
  /** Loading label (default: "Thinking...") */
  loadingLabel?: string;

  /** Enable auto-scroll behavior (default: true) */
  autoScroll?: boolean;
  /** Number of unread messages when scrolled up (drives FAB badge) */
  unreadCount?: number;
}

// =============================================================================
// Auto-scroll hook
// =============================================================================

function useAutoScroll(
  containerRef: React.RefObject<HTMLDivElement | null>,
  enabled: boolean
) {
  const isNearBottomRef = useRef(true);
  const [showScrollButton, setShowScrollButton] = useState(false);

  // Check if user is near bottom (within 120px)
  const checkNearBottom = useCallback(() => {
    const el = containerRef.current;
    if (!el) return;
    const threshold = 120;
    const nearBottom =
      el.scrollHeight - el.scrollTop - el.clientHeight < threshold;
    isNearBottomRef.current = nearBottom;
    setShowScrollButton(!nearBottom);
  }, [containerRef]);

  // Scroll to bottom
  const scrollToBottom = useCallback(
    (smooth = true) => {
      const el = containerRef.current;
      if (!el) return;
      el.scrollTo({
        top: el.scrollHeight,
        behavior: smooth ? 'smooth' : 'auto',
      });
      isNearBottomRef.current = true;
      setShowScrollButton(false);
    },
    [containerRef]
  );

  // Listen to scroll events
  useEffect(() => {
    const el = containerRef.current;
    if (!el || !enabled) return;

    const handleScroll = () => checkNearBottom();
    el.addEventListener('scroll', handleScroll, { passive: true });
    return () => el.removeEventListener('scroll', handleScroll);
  }, [containerRef, enabled, checkNearBottom]);

  // Auto-scroll on content changes via MutationObserver
  useEffect(() => {
    const el = containerRef.current;
    if (!el || !enabled) return;

    const observer = new MutationObserver(() => {
      if (isNearBottomRef.current) {
        // Use rAF for smooth scroll after DOM paint
        requestAnimationFrame(() => {
          el.scrollTop = el.scrollHeight;
        });
      }
    });

    observer.observe(el, {
      childList: true,
      subtree: true,
      characterData: true,
    });

    return () => observer.disconnect();
  }, [containerRef, enabled]);

  return { showScrollButton, scrollToBottom };
}

// =============================================================================
// Component
// =============================================================================

export const ChatPanel: React.FC<ChatPanelProps> = ({
  title,
  subtitle,
  header,
  children,
  input,
  suggestions,
  onClose,
  headerActions,
  emptyState,
  hasMessages = true,
  isLoading = false,
  loadingLabel = 'Thinking...',
  autoScroll = true,
  unreadCount = 0,
}) => {
  const messagesRef = useRef<HTMLDivElement>(null);
  const { showScrollButton, scrollToBottom } = useAutoScroll(
    messagesRef,
    autoScroll
  );

  return (
    <div className={styles.panel}>
      {/* Header */}
      <div className={styles.header}>
        {header || (
          <div className={styles.headerDefault}>
            <div className={styles.headerInfo}>
              {title && <span className={styles.title}>{title}</span>}
              {subtitle && !isLoading && (
                <span className={styles.subtitle}>{subtitle}</span>
              )}
              {isLoading && (
                <span className={styles.loadingIndicator}>
                  <span className={styles.loadingDot} />
                  <span className={styles.loadingDot} />
                  <span className={styles.loadingDot} />
                  <span className={styles.loadingText}>{loadingLabel}</span>
                </span>
              )}
            </div>
            <div className={styles.headerActions}>
              {headerActions}
              {onClose && (
                <IconButton
                  icon="close"
                  size="small"
                  variant="tertiary"
                  onClick={onClose}
                  aria-label="Close"
                />
              )}
            </div>
          </div>
        )}
      </div>

      {/* Message area */}
      <div className={styles.messagesContainer}>
        <div className={styles.messages} ref={messagesRef}>
          {hasMessages ? children : emptyState || children}
        </div>

        {/* Gradient fade above input */}
        <div className={styles.gradientFade} />

        {/* Scroll to bottom FAB */}
        {showScrollButton && (
          <button
            className={styles.scrollFab}
            onClick={() => scrollToBottom(true)}
            aria-label="Scroll to bottom"
          >
            <Icon name="chevron-down" size={16} />
            {unreadCount > 0 && (
              <span className={styles.unreadBadge}>{unreadCount}</span>
            )}
          </button>
        )}
      </div>

      {/* Suggestions */}
      {suggestions && (
        <div className={styles.suggestions}>
          {suggestions}
        </div>
      )}

      {/* Input */}
      {input && (
        <div className={styles.input}>
          {input}
        </div>
      )}
    </div>
  );
};
