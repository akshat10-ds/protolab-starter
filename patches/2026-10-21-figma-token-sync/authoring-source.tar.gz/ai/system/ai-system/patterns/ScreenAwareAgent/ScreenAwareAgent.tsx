/**
 * ScreenAwareAgent — Agent that adapts to content screens
 *
 * Provides screen-aware agent orchestration: auto-triggers, context transfer,
 * and navigation from chat. This is a headless pattern (hook + layout) extracted
 * from the e2e-agents and unified-chat-agent prototypes.
 *
 * Usage:
 *   const agent = useScreenAwareAgent({ screens, autoTriggers, contextMap });
 *   <ScreenAwareAgent agent={agent}> ... </ScreenAwareAgent>
 */

import React, { useState, useRef, useCallback, useEffect, useMemo } from 'react';
import { Icon } from '@ink';
import styles from './ScreenAwareAgent.module.css';

// =============================================================================
// Types
// =============================================================================

export interface ScreenContextItem {
  id: string;
  type: string;
  label: string;
  detail?: string;
  icon?: string;
}

export interface AutoTriggerConfig {
  /** Unique key for deduplication (defaults to screenId) */
  key?: string;
  /** Delay before firing (ms, default: 300) */
  delayMs?: number;
  /** Data payload passed to the onAutoTrigger callback */
  payload?: unknown;
}

export interface ScreenAwareConfig<TScreen extends string = string> {
  /** Initial screen */
  initialScreen: TScreen;
  /** Auto-trigger map: screen → trigger config. Fires once per screen unless reset. */
  autoTriggers?: Partial<Record<TScreen, AutoTriggerConfig | string>>;
  /** Context map: screen → context items shown in chat */
  contextMap?: Partial<Record<TScreen, ScreenContextItem[]>>;
  /** Called when an auto-trigger fires */
  onAutoTrigger?: (screen: TScreen, config: AutoTriggerConfig) => void;
  /** Called when screen changes */
  onScreenChange?: (screen: TScreen, prevScreen: TScreen) => void;
  /** Called on navigation requests from chat */
  onNavigate?: (destination: TScreen) => void;
}

export interface ScreenAwareAgentState<TScreen extends string = string> {
  /** Current active screen */
  screen: TScreen;
  /** Navigate to a screen */
  setScreen: (screen: TScreen) => void;
  /** Navigate with loading indicator */
  navigateTo: (screen: TScreen, delayMs?: number) => void;
  /** Currently navigating to (for loading UI) */
  navigatingTo: TScreen | null;
  /** Context items for current screen */
  contextItems: ScreenContextItem[];
  /** Reset auto-triggers (e.g., on act switch) */
  resetTriggers: () => void;
  /** Check if a trigger has fired */
  hasFired: (key: string) => boolean;
}

export interface ScreenAwareAgentProps<TScreen extends string = string> {
  /** Agent state from useScreenAwareAgent */
  agent: ScreenAwareAgentState<TScreen>;
  /** Screen render map: screen id → ReactNode */
  screens: Partial<Record<TScreen, React.ReactNode>>;
  /** Chat panel (rendered as persistent sibling) */
  chatPanel?: React.ReactNode;
  /** Whether chat panel is open */
  isChatOpen?: boolean;
  /** Navigation overlay (shown during navigateTo transitions) */
  navigationOverlay?: React.ReactNode;
  className?: string;
}

// =============================================================================
// Hook
// =============================================================================

export function useScreenAwareAgent<TScreen extends string = string>(
  config: ScreenAwareConfig<TScreen>
): ScreenAwareAgentState<TScreen> {
  const {
    initialScreen,
    autoTriggers,
    contextMap,
    onAutoTrigger,
    onScreenChange,
  } = config;

  const [screen, setScreenRaw] = useState<TScreen>(initialScreen);
  const [navigatingTo, setNavigatingTo] = useState<TScreen | null>(null);
  const firedTriggersRef = useRef<Set<string>>(new Set());
  const prevScreenRef = useRef<TScreen>(initialScreen);

  // Context items for current screen
  const contextItems = useMemo(
    () => contextMap?.[screen] || [],
    [contextMap, screen]
  );

  // Screen change with callback
  const setScreen = useCallback(
    (newScreen: TScreen) => {
      const prev = prevScreenRef.current;
      prevScreenRef.current = newScreen;
      setScreenRaw(newScreen);
      onScreenChange?.(newScreen, prev);
    },
    [onScreenChange]
  );

  // Navigate with loading delay
  const navigateTo = useCallback(
    (destination: TScreen, delayMs = 1200) => {
      setNavigatingTo(destination);
      setTimeout(() => {
        setNavigatingTo(null);
        setScreen(destination);
      }, delayMs);
    },
    [setScreen]
  );

  // Auto-trigger on screen change
  useEffect(() => {
    const triggerConfig = autoTriggers?.[screen];
    if (!triggerConfig) return;

    const config: AutoTriggerConfig =
      typeof triggerConfig === 'string'
        ? { key: triggerConfig, payload: triggerConfig }
        : triggerConfig;

    const triggerKey = config.key || screen;
    if (firedTriggersRef.current.has(triggerKey)) return;

    firedTriggersRef.current.add(triggerKey);

    const timer = setTimeout(() => {
      onAutoTrigger?.(screen, config);
    }, config.delayMs ?? 300);

    return () => clearTimeout(timer);
  }, [screen, autoTriggers, onAutoTrigger]);

  // Reset triggers
  const resetTriggers = useCallback(() => {
    firedTriggersRef.current = new Set();
  }, []);

  const hasFired = useCallback(
    (key: string) => firedTriggersRef.current.has(key),
    []
  );

  return {
    screen,
    setScreen,
    navigateTo,
    navigatingTo,
    contextItems,
    resetTriggers,
    hasFired,
  };
}

// =============================================================================
// Layout Component
// =============================================================================

export function ScreenAwareAgent<TScreen extends string = string>({
  agent,
  screens,
  chatPanel,
  isChatOpen = false,
  navigationOverlay,
  className,
}: ScreenAwareAgentProps<TScreen>) {
  return (
    <div className={`${styles.layout} ${className || ''}`}>
      {/* Screen area */}
      <div className={styles.screenArea}>
        {Object.entries(screens).map(([screenId, node]) => (
          <div
            key={screenId}
            className={styles.screen}
            data-active={agent.screen === screenId}
          >
            {node as React.ReactNode}
          </div>
        ))}

        {/* Navigation overlay */}
        {agent.navigatingTo && (
          <div className={styles.navOverlay}>
            {navigationOverlay || (
              <div className={styles.navSpinner}>
                <Icon name="bolt" size={20} />
                <span>Navigating...</span>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Chat panel (persistent sibling) */}
      {chatPanel && (
        <div className={styles.chatPanel} data-open={isChatOpen}>
          {chatPanel}
        </div>
      )}
    </div>
  );
}

