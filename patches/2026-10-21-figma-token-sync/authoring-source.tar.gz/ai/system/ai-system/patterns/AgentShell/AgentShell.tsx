/**
 * AgentShell — Top-level agent layout
 *
 * The root layout for agent interfaces: optional history rail on the left,
 * chat panel in the center, optional artifact panel on the right.
 * Handles responsive panel sizing, drag-to-resize, and state.
 */

import React from 'react';
import { usePanelResize } from '../../hooks/usePanelResize';
import styles from './AgentShell.module.css';

// =============================================================================
// Types
// =============================================================================

export interface AgentShellProps {
  /** Left sidebar (e.g., ConversationList) */
  historyRail?: React.ReactNode;
  /** Center content (e.g., ChatPanel) */
  children: React.ReactNode;
  /** Right panel (e.g., ArtifactPanel) */
  artifactPanel?: React.ReactNode;
  /** Whether the history rail is open */
  isHistoryOpen?: boolean;
  /** Whether the artifact panel is open */
  isArtifactOpen?: boolean;
  /** Default width of the history rail in px */
  defaultHistoryWidth?: number;
  /** Default width of the artifact panel in px */
  defaultArtifactWidth?: number;
  /** Minimum width panels can be resized to in px */
  minPanelWidth?: number;
}

// =============================================================================
// Component
// =============================================================================

export const AgentShell: React.FC<AgentShellProps> = ({
  historyRail,
  children,
  artifactPanel,
  isHistoryOpen = true,
  isArtifactOpen = false,
  defaultHistoryWidth = 280,
  defaultArtifactWidth = 420,
  minPanelWidth = 200,
}) => {
  const historyResize = usePanelResize({
    initialWidth: defaultHistoryWidth,
    minWidth: minPanelWidth,
    maxWidth: 480,
    defaultWidth: defaultHistoryWidth,
    direction: 'right',
    snapToCloseThreshold: 0,
  });

  const artifactResize = usePanelResize({
    initialWidth: defaultArtifactWidth,
    minWidth: minPanelWidth,
    maxWidth: 900,
    defaultWidth: defaultArtifactWidth,
    direction: 'left',
    snapToCloseThreshold: 0,
  });

  const showHistory = historyRail && isHistoryOpen;
  const showArtifact = artifactPanel && isArtifactOpen;
  const isDragging = historyResize.isResizing || artifactResize.isResizing;

  return (
    <div
      className={styles.shell}
      data-resizing={isDragging || undefined}
    >
      {/* History rail */}
      {showHistory && (
        <aside
          className={styles.historyRail}
          style={{ width: historyResize.width }}
        >
          {historyRail}
          <div
            className={styles.dragHandle}
            data-edge="right"
            onPointerDown={historyResize.handlePointerDown}
            role="separator"
            aria-orientation="vertical"
            aria-label="Resize history panel"
          />
        </aside>
      )}

      {/* Main chat area */}
      <main className={styles.main}>
        {children}
      </main>

      {/* Artifact panel */}
      {showArtifact && (
        <aside
          className={styles.artifactPanel}
          style={{ width: artifactResize.width }}
        >
          <div
            className={styles.dragHandle}
            data-edge="left"
            onPointerDown={artifactResize.handlePointerDown}
            role="separator"
            aria-orientation="vertical"
            aria-label="Resize artifact panel"
          />
          {artifactPanel}
        </aside>
      )}
    </div>
  );
};
