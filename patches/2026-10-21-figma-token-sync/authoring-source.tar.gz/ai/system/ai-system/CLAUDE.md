# ai-system — Agent Experience Design System

The design system for agent and AI experiences. It sits alongside the Ink design
system and builds on top of it. See [`README.md`](./README.md) for the full
import contract, live-link decision, and port notes.

## Status

**Canonical.** This directory (`akshat-lab/system/ai-system/`) is the single
source of truth for the AI system. It is:

- **Live-linked** into every active Lab HQ prototype via the `@ai` Vite/TS alias
  (edit here → every active prototype updates on save).
- **Exercised** by the prototypes under `projects/iris-system/prototypes/` — the
  regression surface. Drive them before a release.
- **Released** to `protolab-starter` via `/release-chat-to-protolab`, which copies
  this system into the team trunk, writes a `system/CHANGELOG.md` chapter, and
  git-tags the starter.

Ported from `protoLab/src/ai-system` on 2026-07-08 (now a frozen archive). The
old "setting up / migrating from prototypes" status is retired — migration is
done.

## Architecture

**Layers:** Ink (foundation) → ai-system (agent layer) → prototypes (consume both).

## Import patterns

```tsx
import { Button, Stack, Icon } from '@ink';          // Ink base UI (consumer provides)
import { IrisAgent, PanelShell } from '@ai';         // this system's public API
```

CSS modules import Ink tokens with `@import '@ink/1-tokens/tokens.css';`.

## Rules

1. **Build on Ink** — use `@ink` for all base UI; never re-implement it.
2. **Public API only** — prototypes import from `@ai` (the barrel), not internals.
3. **No hardcoded colors** — Ink tokens (`var(--ink-*)`) only.
4. **Add to the system, don't fork** — new agent pieces live here so the live
   link propagates them. A prototype only ever gets its own frozen copy by
   deliberately vendoring one; the default is the live link.
5. **Document every export** — clear props, usage, and pattern guidance.
