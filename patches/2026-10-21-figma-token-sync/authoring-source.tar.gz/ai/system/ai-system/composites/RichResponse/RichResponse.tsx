/**
 * RichResponse — Structured tool-call response card
 *
 * Renders categorized AI responses with a tool-call card pattern:
 * header (title + subtitle + citation count), sections (table/list/text),
 * and an optional footer action.
 *
 * Generalized from agreement-studio's RichMessage.
 */

import React, { useMemo } from 'react';
import { Icon, IconButton } from '@ink';
import type { Citation } from '../../primitives/CitationBadge/CitationBadge';
import styles from './RichResponse.module.css';

// =============================================================================
// Types
// =============================================================================

export interface RichTableRow {
  cells: (string | { text: string; citation?: Citation })[];
}

export interface RichTableData {
  headers: string[];
  rows: RichTableRow[];
}

export interface RichListItem {
  text: string;
  citation?: Citation;
}

export interface RichResponseSection {
  id: string;
  title: string;
  icon: string;
  type: 'table' | 'list' | 'text';
  content: RichTableData | RichListItem[] | string;
}

export interface RichResponseData {
  id: string;
  title: string;
  subtitle: string;
  sections: RichResponseSection[];
}

export interface RichResponseProps {
  /** Structured response data */
  data: RichResponseData;
  /** Called when a citation is clicked */
  onCitationClick?: (citation: Citation) => void;
  /** Optional footer content (e.g., action buttons) */
  footer?: React.ReactNode;
  /** Optional header actions (replaces default overflow menu) */
  headerActions?: React.ReactNode;
}

// =============================================================================
// Component
// =============================================================================

export const RichResponse: React.FC<RichResponseProps> = ({
  data,
  onCitationClick,
  footer,
  headerActions,
}) => {
  const handleCitationClick = onCitationClick || (() => {});

  // Count total citations
  const citationCount = useMemo(() => {
    let count = 0;
    data.sections.forEach((section) => {
      if (section.type === 'table') {
        const tableData = section.content as RichTableData;
        tableData.rows.forEach((row) => {
          row.cells.forEach((cell) => {
            if (typeof cell !== 'string' && cell.citation) count++;
          });
        });
      } else if (section.type === 'list') {
        const listData = section.content as RichListItem[];
        listData.forEach((item) => {
          if (item.citation) count++;
        });
      }
    });
    return count;
  }, [data]);

  const renderCitation = (citation: Citation, displayText: string) => (
    <span className={styles.citationWrapper}>
      <button type="button" className={styles.citation} onClick={() => handleCitationClick(citation)}>
        [{displayText}]
      </button>
      <span className={styles.citationTooltip}>
        <span className={styles.citationTooltipLabel}>Source</span>
        <span className={styles.citationTooltipTitle}>{citation.title}</span>
        <span className={styles.citationTooltipExcerpt}>
          &ldquo;
          {citation.excerpt.length > 100
            ? `${citation.excerpt.substring(0, 100)}...`
            : citation.excerpt}
          &rdquo;
        </span>
      </span>
    </span>
  );

  const renderCellContent = (cell: string | { text: string; citation?: Citation }) => {
    if (typeof cell === 'string') return cell;
    if (cell.citation) return renderCitation(cell.citation, cell.text);
    return cell.text;
  };

  const renderTableSection = (content: RichTableData) => (
    <table className={styles.richTable}>
      <thead>
        <tr>
          {content.headers.map((header, i) => (
            <th key={i}>{header}</th>
          ))}
        </tr>
      </thead>
      <tbody>
        {content.rows.map((row, rowIdx) => (
          <tr key={rowIdx}>
            {row.cells.map((cell, cellIdx) => (
              <td key={cellIdx}>{renderCellContent(cell)}</td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );

  const renderListSection = (content: RichListItem[]) => (
    <ul className={styles.richList}>
      {content.map((item, index) => (
        <li key={index} className={styles.richListItem}>
          {item.text}
          {item.citation && (
            <>
              {' '}
              {renderCitation(item.citation, item.citation.title)}
            </>
          )}
        </li>
      ))}
    </ul>
  );

  return (
    <div className={styles.richResponse}>
      {/* Header */}
      <div className={styles.header}>
        <h3 className={styles.title}>{data.title}</h3>
        <span className={styles.subtitle}>{data.subtitle}</span>
        {citationCount > 0 && (
          <span className={styles.citationBadge}>
            <Icon name="link" size={12} />
            {citationCount} {citationCount === 1 ? 'citation' : 'citations'}
          </span>
        )}
        <div className={styles.headerActions}>
          {headerActions || (
            <IconButton
              icon="overflow-horizontal"
              size="small"
              variant="tertiary"
              aria-label="More options"
            />
          )}
        </div>
      </div>

      {/* Sections */}
      <div className={styles.content}>
        {data.sections.map((section) => (
          <div key={section.id} className={styles.section}>
            <div className={styles.sectionHeader}>
              <span className={styles.sectionIcon}>
                <Icon name={section.icon as any} size={16} />
              </span>
              <h4 className={styles.sectionTitle}>{section.title}</h4>
            </div>
            {section.type === 'table' && renderTableSection(section.content as RichTableData)}
            {section.type === 'list' && renderListSection(section.content as RichListItem[])}
            {section.type === 'text' && <p className={styles.sectionText}>{section.content as string}</p>}
          </div>
        ))}
      </div>

      {/* Footer */}
      {footer && (
        <div className={styles.footer}>
          {footer}
        </div>
      )}
    </div>
  );
};
