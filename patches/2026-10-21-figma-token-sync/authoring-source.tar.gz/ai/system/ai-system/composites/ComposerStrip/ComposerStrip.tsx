/**
 * ComposerStrip — the tucked strip above the composer, as a component.
 *
 * Named for the SLOT, not for its first caller: there is exactly one strip
 * position above the composer, and naming the component after it is what makes
 * the arbitration rule stateable. (Proposed as `StickyDoor`; renamed here.)
 *
 * **ONE SLOT, and Suggested Context has priority.** `IrisAgent` draws the
 * suggested-context strip in this position already. Both cannot sit there: two
 * stacked strips make the composer the third band of a sandwich, and the tuck —
 * one strip peeking out from behind one composer — stops reading. So:
 *
 *   suggested context present  →  it takes the slot; `composerStrip` is not drawn
 *   suggested context absent   →  `composerStrip` takes it back
 *
 * Suggested Context wins because it expires: it is about the message being typed
 * right now, and it leaves as soon as the user adds or dismisses it. This strip
 * is a standing door to something that is not going anywhere — it can wait, and
 * it yields back on its own the moment the borrowed slot is free. The gate lives
 * at `IrisAgent`'s `composerStrip` prop; this component never arbitrates.
 *
 * **The grammar is the suggested-context strip's, value for value.** Akshat,
 * 2026-08-19: show it *"same as how we show suggested sources"*. So: `neutral-10`
 * fill, no border, top two corners rounded, and a negative bottom margin of one
 * radius so the composer sits over the bottom edge — 34px of a 46px strip peeks
 * out. Its first use is the loan's progress + recommendations link (Akshat, same
 * day: once a chat is going, progress and recommendations persist as a
 * lightweight stickied link above the composer, and clicking it opens the
 * artifact).
 *
 * The whole strip is the target. There is one destination, so there is one
 * click — a chevron rather than a labelled button, because the strip is a door,
 * not a decision.
 */

import type React from 'react';
import { Icon } from '@ink';

import styles from './ComposerStrip.module.css';

// =============================================================================
// Types
// =============================================================================

export interface ComposerStripProps {
  /** The status line — "2 of 4 steps · 3 recommendations". Kept to one line. */
  label: React.ReactNode;
  /** Opens what the strip is a door to. */
  onOpen: () => void;
  /** Announced label when `label` is a node rather than a string. */
  ariaLabel?: string;
}

// =============================================================================
// Component
// =============================================================================

export const ComposerStrip = ({ label, onOpen, ariaLabel }: ComposerStripProps) => (
  <button
    type="button"
    className={styles.strip}
    onClick={onOpen}
    aria-label={ariaLabel ?? (typeof label === 'string' ? label : undefined)}
  >
    <span className={styles.label}>{label}</span>
    <Icon name="chevron-right" size={14} />
  </button>
);

ComposerStrip.displayName = 'ComposerStrip';
