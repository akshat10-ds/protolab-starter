/**
 * ConversationList — Searchable conversation history sidebar
 *
 * Displays a list of conversations grouped by date, with search, pinned items,
 * relative timestamps, context menu (rename/delete/pin), and inline rename.
 *
 * Generalized from unified-chat-agent ChatHistoryRail.
 */

import { useState, useMemo, useRef, useEffect, useCallback } from 'react';
import { Icon, IconButton, Input, Dropdown } from '@ink';
import type { DropdownItemProps } from '@ink';
import styles from './ConversationList.module.css';

// =============================================================================
// Types
// =============================================================================

export interface Conversation {
  id: string;
  title: string;
  lastMessage: string;
  lastMessageAt: Date;
  isPinned?: boolean;
}

export interface ConversationListProps {
  conversations: Conversation[];
  activeConversationId?: string;
  onSelectConversation: (id: string) => void;
  onNewChat: () => void;
  onClose?: () => void;
  onDelete?: (id: string) => void;
  onRename?: (id: string, newTitle: string) => void;
  onTogglePin?: (id: string) => void;
  title?: string;
  searchPlaceholder?: string;
}

// =============================================================================
// Date grouping
// =============================================================================

type DateGroup = 'Today' | 'Yesterday' | 'Previous 7 days' | 'Previous 30 days' | 'Older';

const DATE_GROUP_ORDER: DateGroup[] = [
  'Today',
  'Yesterday',
  'Previous 7 days',
  'Previous 30 days',
  'Older',
];

function getDateGroup(date: Date): DateGroup {
  const now = new Date();
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const startOfYesterday = new Date(startOfToday.getTime() - 86400000);
  const sevenDaysAgo = new Date(startOfToday.getTime() - 7 * 86400000);
  const thirtyDaysAgo = new Date(startOfToday.getTime() - 30 * 86400000);

  if (date >= startOfToday) return 'Today';
  if (date >= startOfYesterday) return 'Yesterday';
  if (date >= sevenDaysAgo) return 'Previous 7 days';
  if (date >= thirtyDaysAgo) return 'Previous 30 days';
  return 'Older';
}

function groupByDate(conversations: Conversation[]): Map<DateGroup, Conversation[]> {
  const groups = new Map<DateGroup, Conversation[]>();

  for (const conv of conversations) {
    const group = getDateGroup(conv.lastMessageAt);
    const existing = groups.get(group) || [];
    existing.push(conv);
    groups.set(group, existing);
  }

  return groups;
}

// =============================================================================
// Helpers
// =============================================================================

function formatRelativeTime(date: Date): string {
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  const diffHr = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMin < 1) return 'Just now';
  if (diffMin < 60) return `${diffMin}m ago`;
  if (diffHr < 24) return `${diffHr}h ago`;
  if (diffDays === 1) return 'Yesterday';
  if (diffDays < 7) return `${diffDays}d ago`;
  return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}

// =============================================================================
// Component
// =============================================================================

export function ConversationList({
  conversations,
  activeConversationId,
  onSelectConversation,
  onNewChat,
  onClose,
  onDelete,
  onRename,
  onTogglePin,
  title = 'History',
  searchPlaceholder = 'Search conversations...',
}: ConversationListProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const renameInputRef = useRef<HTMLInputElement>(null);

  const filtered = useMemo(() => {
    if (!searchQuery.trim()) return conversations;
    const q = searchQuery.toLowerCase();
    return conversations.filter(
      (c) => c.title.toLowerCase().includes(q) || c.lastMessage.toLowerCase().includes(q)
    );
  }, [conversations, searchQuery]);

  const pinned = useMemo(() => filtered.filter((c) => c.isPinned), [filtered]);
  const unpinned = useMemo(() => filtered.filter((c) => !c.isPinned), [filtered]);
  const dateGroups = useMemo(() => groupByDate(unpinned), [unpinned]);

  // Focus and select all text when entering rename mode
  useEffect(() => {
    if (renamingId && renameInputRef.current) {
      renameInputRef.current.focus();
      renameInputRef.current.select();
    }
  }, [renamingId]);

  const startRename = useCallback((conversation: Conversation) => {
    setRenamingId(conversation.id);
    setRenameValue(conversation.title);
  }, []);

  const confirmRename = useCallback(() => {
    if (renamingId && renameValue.trim() && onRename) {
      onRename(renamingId, renameValue.trim());
    }
    setRenamingId(null);
    setRenameValue('');
  }, [renamingId, renameValue, onRename]);

  const cancelRename = useCallback(() => {
    setRenamingId(null);
    setRenameValue('');
  }, []);

  const getContextMenuItems = useCallback(
    (conversation: Conversation): DropdownItemProps[] => {
      const items: DropdownItemProps[] = [];

      if (onRename) {
        items.push({
          label: 'Rename',
          icon: <Icon name="pencil" size="small" />,
          onClick: () => startRename(conversation),
        });
      }

      if (onTogglePin) {
        items.push({
          label: conversation.isPinned ? 'Unpin' : 'Pin',
          icon: <Icon name="push-pin" size="small" />,
          onClick: () => onTogglePin(conversation.id),
        });
      }

      if (onDelete) {
        if (items.length > 0) {
          items.push({ label: '', divider: true });
        }
        items.push({
          label: 'Delete',
          icon: <Icon name="trash" size="small" />,
          onClick: () => onDelete(conversation.id),
        });
      }

      return items;
    },
    [onRename, onTogglePin, onDelete, startRename]
  );

  const hasContextMenu = Boolean(onDelete || onRename || onTogglePin);

  const renderConversationItem = (conversation: Conversation) => {
    const isActive = conversation.id === activeConversationId;
    const isRenaming = renamingId === conversation.id;

    return (
      <div
        key={conversation.id}
        className={`${styles.conversationItem} ${isActive ? styles.conversationItemActive : ''}`}
        onClick={() => {
          if (!isRenaming) onSelectConversation(conversation.id);
        }}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === 'Enter' && !isRenaming) onSelectConversation(conversation.id);
        }}
      >
        <div className={styles.conversationTopRow}>
          {isRenaming ? (
            <input
              ref={renameInputRef}
              className={styles.renameInput}
              value={renameValue}
              onChange={(e) => setRenameValue(e.target.value)}
              onKeyDown={(e) => {
                e.stopPropagation();
                if (e.key === 'Enter') confirmRename();
                if (e.key === 'Escape') cancelRename();
              }}
              onBlur={confirmRename}
              onClick={(e) => e.stopPropagation()}
            />
          ) : (
            <span className={styles.conversationTitle}>{conversation.title}</span>
          )}
          <span className={styles.conversationTime}>
            {formatRelativeTime(conversation.lastMessageAt)}
          </span>
        </div>
        {!isRenaming && (
          <span className={styles.conversationPreview}>{conversation.lastMessage}</span>
        )}

        {hasContextMenu && !isRenaming && (
          <div
            className={styles.contextMenuBtn}
            onClick={(e) => e.stopPropagation()}
          >
            <Dropdown
              items={getContextMenuItems(conversation)}
              position="bottom"
              align="end"
            >
              <IconButton
                icon="overflow-horizontal"
                size="small"
                variant="tertiary"
                aria-label="Conversation options"
              />
            </Dropdown>
          </div>
        )}
      </div>
    );
  };

  const renderDateGroup = (group: DateGroup) => {
    const items = dateGroups.get(group);
    if (!items || items.length === 0) return null;

    return (
      <div key={group}>
        <div className={styles.dateGroupHeader}>
          <span className={styles.dateGroupLabel}>{group}</span>
          <div className={styles.dateGroupLine} />
        </div>
        {items.map(renderConversationItem)}
      </div>
    );
  };

  return (
    <div className={styles.rail}>
      <div className={styles.header}>
        <span className={styles.headerTitle}>{title}</span>
        <div className={styles.headerActions}>
          {/* The New Chat glyph, one species everywhere — Akshat, 2026-08-20,
              frame 407:53402: Ink's `pencilBoxSmall`, tertiary/small.

              `pencil-box-small` IS THE RIGHT NAME — it is a different glyph
              from `pencil-box`, and six of the eight vendored icon maps carry
              it. navigator-e2e's copy does not, which drew an empty button
              there and nowhere else. Renaming this to `pencil-box` "fixed" that
              one prototype by breaking every other, since most maps have no
              `pencil-box` at all. The gap belongs in the stale map, not here. */}
          <IconButton
            icon="pencil-box-small"
            size="small"
            variant="tertiary"
            onClick={onNewChat}
            aria-label="New chat"
          />
          {onClose && (
            <IconButton
              icon="close"
              size="small"
              variant="tertiary"
              onClick={onClose}
              aria-label="Close history"
            />
          )}
        </div>
      </div>

      <div className={styles.searchWrapper}>
        <Input
          label="Search conversations"
          hideLabel
          placeholder={searchPlaceholder}
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          size="small"
        />
      </div>

      <div className={styles.listArea}>
        {/* Pinned section */}
        {pinned.length > 0 && (
          <>
            <div className={styles.sectionLabel}>
              <span className={styles.sectionLabelIcon}>
                <Icon name="star" size="small" />
              </span>
              Pinned
            </div>
            {pinned.map(renderConversationItem)}
            <div className={styles.sectionDivider} />
          </>
        )}

        {/* Date-grouped unpinned conversations */}
        {unpinned.length > 0 && DATE_GROUP_ORDER.map(renderDateGroup)}

        {/* Empty state */}
        {filtered.length === 0 && (
          <div className={styles.emptyState}>
            <span className={styles.emptyStateIcon}>
              <Icon name="messages" size="medium" />
            </span>
            <span className={styles.emptyStateText}>
              {searchQuery.trim() ? 'No conversations match your search' : 'No conversations yet'}
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
