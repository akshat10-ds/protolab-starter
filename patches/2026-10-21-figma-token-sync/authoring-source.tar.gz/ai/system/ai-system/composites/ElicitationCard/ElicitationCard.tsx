// SUPERSEDED by `ComposerAsk` — Akshat's HITL spec, 2026-08-19. The ask docks
// into the composer; it is not a thread card. Kept for existing consumers.

import React, { useState, useCallback, useEffect, useRef } from 'react';
import { Icon } from '@ink';
import styles from './ElicitationCard.module.css';

// =============================================================================
// Types
// =============================================================================

export type ElicitationQuestionType = 'single' | 'multi' | 'rank';

export interface ElicitationQuestion {
  id: string;
  prompt: string;
  type: ElicitationQuestionType;
  options: string[];
}

export interface ElicitationAnswer {
  questionId: string;
  prompt: string;
  type: ElicitationQuestionType | 'freetext' | 'skipped';
  value: string | string[] | null;
}

export interface ElicitationCardProps {
  questions: ElicitationQuestion[];
  onComplete: (answers: ElicitationAnswer[]) => void;
  onDismiss: () => void;
  /** Render a custom action element to the right of each single-select option (e.g. preview eye) */
  renderOptionSuffix?: (option: string, index: number) => React.ReactNode;
  /** Custom placeholder for the free-text "Something else" input */
  freeTextPlaceholder?: string;
}

// =============================================================================
// Helper — formats answers into the Q&A bubble string
// =============================================================================

export function formatElicitationAnswers(answers: ElicitationAnswer[]): string {
  return answers
    .map(a => {
      let answerText: string;
      if (a.type === 'skipped' || a.value === null) {
        answerText = '[No preference]';
      } else if (Array.isArray(a.value)) {
        answerText = a.value.join(', ');
      } else {
        answerText = a.value;
      }
      return `Q: ${a.prompt}\nA: ${answerText}`;
    })
    .join('\n\n');
}

// =============================================================================
// ElicitationCard
// =============================================================================

export function ElicitationCard({ questions, onComplete, onDismiss, renderOptionSuffix, freeTextPlaceholder }: ElicitationCardProps) {
  const [currentIdx, setCurrentIdx] = useState(0);

  // Confirmed answers per question (set when user advances/skips)
  const [savedAnswers, setSavedAnswers] = useState<Record<string, ElicitationAnswer>>({});

  // Per-question mutable state — preserved across navigation
  const [multiStates, setMultiStates] = useState<Record<string, Set<string>>>(() =>
    Object.fromEntries(questions.map(q => [q.id, new Set<string>()]))
  );
  const [rankStates, setRankStates] = useState<Record<string, string[]>>(() =>
    Object.fromEntries(questions.map(q => [q.id, [...q.options]]))
  );
  const [freetextStates, setFreetextStates] = useState<Record<string, string>>(() =>
    Object.fromEntries(questions.map(q => [q.id, '']))
  );

  // Drag state for rank questions
  const [dragIdx, setDragIdx] = useState<number | null>(null);
  const [dragOverIdx, setDragOverIdx] = useState<number | null>(null);

  const freetextRef = useRef<HTMLInputElement>(null);
  const current = questions[currentIdx];
  const total = questions.length;
  const isFirst = currentIdx === 0;
  const isLast = currentIdx === total - 1;
  const hasNextSaved = !!savedAnswers[questions[currentIdx + 1]?.id];
  const canGoNext = !isLast && hasNextSaved;

  const currentMulti = multiStates[current.id] ?? new Set<string>();
  const currentRank = rankStates[current.id] ?? current.options;
  const currentFreetext = freetextStates[current.id] ?? '';

  // Reset drag state on question change
  useEffect(() => {
    setDragIdx(null);
    setDragOverIdx(null);
  }, [currentIdx]);

  // State updaters
  const updateMulti = (newSet: Set<string>) =>
    setMultiStates(prev => ({ ...prev, [current.id]: newSet }));

  const updateRank = (newOrder: string[]) =>
    setRankStates(prev => ({ ...prev, [current.id]: newOrder }));

  const updateFreetext = (value: string) =>
    setFreetextStates(prev => ({ ...prev, [current.id]: value }));

  // Advance: saves answer, moves to next question or completes
  const advance = useCallback(
    (answer: ElicitationAnswer) => {
      const newSaved = { ...savedAnswers, [answer.questionId]: answer };
      setSavedAnswers(newSaved);

      if (!isLast) {
        setCurrentIdx(i => i + 1);
      } else {
        const allAnswers = questions.map(
          q =>
            newSaved[q.id] ?? {
              questionId: q.id,
              prompt: q.prompt,
              type: 'skipped' as const,
              value: null,
            }
        );
        onComplete(allAnswers);
      }
    },
    [savedAnswers, isLast, questions, onComplete]
  );

  const skipCurrent = useCallback(() => {
    advance({ questionId: current.id, prompt: current.prompt, type: 'skipped', value: null });
  }, [advance, current]);

  // Single-select: click immediately advances
  const handleSingleSelect = useCallback(
    (option: string) => {
      advance({ questionId: current.id, prompt: current.prompt, type: 'single', value: option });
    },
    [advance, current]
  );

  // Freetext submit (used in single-select footer)
  const handleFreetextSubmit = useCallback(() => {
    const trimmed = currentFreetext.trim();
    if (!trimmed) return;
    advance({ questionId: current.id, prompt: current.prompt, type: 'freetext', value: trimmed });
  }, [advance, current, currentFreetext]);

  // Multi-select: → advances with current selection
  const handleMultiAdvance = useCallback(() => {
    const selected = [...currentMulti].filter(s => s !== '__something_else__');
    advance({
      questionId: current.id,
      prompt: current.prompt,
      type: selected.length > 0 ? 'multi' : 'skipped',
      value: selected.length > 0 ? selected : null,
    });
  }, [advance, current, currentMulti]);

  const toggleMulti = useCallback(
    (option: string) => {
      const next = new Set(currentMulti);
      if (next.has(option)) next.delete(option);
      else next.add(option);
      updateMulti(next);
    },
    [currentMulti]
  );

  // Rank: ↑ submits with current order
  const handleRankSubmit = useCallback(() => {
    advance({ questionId: current.id, prompt: current.prompt, type: 'rank', value: currentRank });
  }, [advance, current, currentRank]);

  // Drag handlers
  const handleDragStart = (idx: number) => setDragIdx(idx);
  const handleDragOver = (e: React.DragEvent, idx: number) => {
    e.preventDefault();
    setDragOverIdx(idx);
  };
  const handleDrop = useCallback(
    (dropIdx: number) => {
      if (dragIdx === null || dragIdx === dropIdx) return;
      const next = [...currentRank];
      const [moved] = next.splice(dragIdx, 1);
      next.splice(dropIdx, 0, moved);
      updateRank(next);
      setDragIdx(null);
      setDragOverIdx(null);
    },
    [dragIdx, currentRank]
  );
  const handleDragEnd = () => {
    setDragIdx(null);
    setDragOverIdx(null);
  };

  // Global keyboard handling
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') skipCurrent();
      if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
        if (current.type === 'multi') handleMultiAdvance();
        if (current.type === 'rank') handleRankSubmit();
      }
    };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [current.type, skipCurrent, handleMultiAdvance, handleRankSubmit]);

  // Keyboard hints
  const hints: Record<ElicitationQuestionType, string[]> = {
    single: ['↑↓ to navigate', 'Enter to select', 'Esc to skip'],
    multi: ['↑↓ to navigate', 'Enter to toggle', '⌘↵ to submit', 'Esc to skip'],
    rank: ['Drag to reorder', '⌘↵ to submit', 'Esc to skip'],
  };

  const multiVisibleCount = [...currentMulti].filter(s => s !== '__something_else__').length;

  return (
    <div className={styles.wrapper}>
      <div className={styles.card}>
        {/* ── Header ── */}
        <div className={styles.header}>
          <span className={styles.prompt}>{current.prompt}</span>
          <div className={styles.headerNav}>
            <button
              className={styles.navBtn}
              disabled={isFirst}
              onClick={() => setCurrentIdx(i => i - 1)}
              aria-label="Previous question"
            >
              <Icon name="chevron-left" size={14} />
            </button>
            <span className={styles.pageCount}>
              {currentIdx + 1} of {total}
            </span>
            <button
              className={styles.navBtn}
              disabled={!canGoNext}
              onClick={() => setCurrentIdx(i => i + 1)}
              aria-label="Next question"
            >
              <Icon name="chevron-right" size={14} />
            </button>
            <button className={styles.closeBtn} onClick={onDismiss} aria-label="Dismiss">
              <Icon name="close" size={16} />
            </button>
          </div>
        </div>

        {/* ── Single-select body ── */}
        {current.type === 'single' && (
          <>
            <div className={styles.optionList}>
              {current.options.map((option, i) => (
                <React.Fragment key={option}>
                  {i > 0 && <div className={styles.divider} />}
                  <div className={styles.optionRow}>
                    <button
                      className={styles.option}
                      onClick={() => handleSingleSelect(option)}
                    >
                      <span className={styles.numberBadge}>{i + 1}</span>
                      <span className={styles.optionText}>{option}</span>
                      <span className={styles.optionArrow}>
                        <Icon name="arrow-right" size={15} />
                      </span>
                    </button>
                    {renderOptionSuffix && (
                      <span className={styles.optionSuffix}>
                        {renderOptionSuffix(option, i)}
                      </span>
                    )}
                  </div>
                </React.Fragment>
              ))}
            </div>

            {/* Freetext footer */}
            <div className={styles.freetextFooter}>
              <span className={styles.freetextIconWrap}>
                <Icon name="pencil" size={14} />
              </span>
              <input
                ref={freetextRef}
                className={styles.freetextInput}
                placeholder={freeTextPlaceholder ?? "Something else"}
                value={currentFreetext}
                onChange={e => updateFreetext(e.target.value)}
                onKeyDown={e => {
                  if (e.key === 'Enter' && currentFreetext.trim()) handleFreetextSubmit();
                }}
              />
              {currentFreetext.trim() ? (
                <button
                  className={styles.freetextSubmitBtn}
                  onClick={handleFreetextSubmit}
                  aria-label="Submit"
                >
                  <Icon name="arrow-right" size={16} />
                </button>
              ) : (
                <button className={styles.skipBtn} onClick={skipCurrent}>
                  Skip
                </button>
              )}
            </div>
          </>
        )}

        {/* ── Multi-select body ── */}
        {current.type === 'multi' && (
          <>
            <div className={styles.optionList}>
              {current.options.map((option, i) => (
                <React.Fragment key={option}>
                  {i > 0 && <div className={styles.divider} />}
                  <div className={styles.optionRow}>
                    <button
                      className={styles.option}
                      onClick={() => toggleMulti(option)}
                    >
                      <span
                        className={styles.checkbox}
                        data-checked={currentMulti.has(option)}
                        aria-hidden
                      />
                      <span className={styles.optionText}>{option}</span>
                    </button>
                  </div>
                </React.Fragment>
              ))}
              {/* "Something else" option */}
              <div className={styles.divider} />
              <div className={`${styles.optionRow} ${styles.somethingElseRow}`}>
                <button
                  className={styles.option}
                  onClick={() => toggleMulti('__something_else__')}
                >
                  <span
                    className={styles.checkbox}
                    data-checked={currentMulti.has('__something_else__')}
                    aria-hidden
                  />
                  <span className={`${styles.optionText} ${styles.somethingElseText}`}>
                    Something else
                  </span>
                </button>
              </div>
            </div>

            <div className={styles.multiFooter}>
              <span className={styles.selectionCount}>{multiVisibleCount} selected</span>
              <div className={styles.footerActions}>
                <button className={styles.skipBtn} onClick={skipCurrent}>
                  Skip
                </button>
                <button className={styles.submitBtn} onClick={handleMultiAdvance} aria-label="Next">
                  <Icon name="arrow-right" size={16} />
                </button>
              </div>
            </div>
          </>
        )}

        {/* ── Rank/drag body ── */}
        {current.type === 'rank' && (
          <>
            <div className={styles.optionList}>
              {currentRank.map((option, i) => (
                <React.Fragment key={option}>
                  {i > 0 && <div className={styles.divider} />}
                  <div
                    className={styles.rankRow}
                    draggable
                    onDragStart={() => handleDragStart(i)}
                    onDragOver={e => handleDragOver(e, i)}
                    onDrop={() => handleDrop(i)}
                    onDragEnd={handleDragEnd}
                    data-drag-over={dragOverIdx === i && dragIdx !== i}
                    data-dragging={dragIdx === i}
                  >
                    <span className={styles.numberBadge}>{i + 1}</span>
                    <span className={styles.optionText}>{option}</span>
                    <span className={styles.dragHandle} aria-hidden>
                      ⠿
                    </span>
                  </div>
                </React.Fragment>
              ))}
            </div>

            <div className={styles.rankFooter}>
              <span className={styles.rankHint}>Drag to re-order your priorities</span>
              <div className={styles.footerActions}>
                <button className={styles.skipBtn} onClick={skipCurrent}>
                  Skip
                </button>
                <button className={styles.submitBtn} onClick={handleRankSubmit} aria-label="Submit">
                  <Icon name="arrow-up" size={16} />
                </button>
              </div>
            </div>
          </>
        )}
      </div>

      {/* ── Keyboard hints ── */}
      <div className={styles.hintsRow}>
        {hints[current.type].map((hint, i, arr) => (
          <React.Fragment key={hint}>
            <span className={styles.hintItem}>{hint}</span>
            {i < arr.length - 1 && <span className={styles.hintDot}>·</span>}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
}
