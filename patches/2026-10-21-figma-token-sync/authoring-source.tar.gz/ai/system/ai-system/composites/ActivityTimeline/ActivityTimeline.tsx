/**
 * ActivityTimeline — Chronological feed with smart batching
 *
 * Displays a vertical timeline of activities. Consecutive agent activities
 * are batched into collapsible groups. Human activities show avatars.
 *
 * Generalized from e2e-agents ActivityFeed.
 */

import { useState } from 'react';
import { Avatar, Icon } from '@ink';
import styles from './ActivityTimeline.module.css';

// =============================================================================
// Types
// =============================================================================

export interface ActivityActor {
  name: string;
  isAgent?: boolean;
  initials?: string;
  colorIndex?: number;
}

export interface Activity {
  id: string;
  type: string;
  actor: ActivityActor;
  title: string;
  description?: string;
  timestamp: string;
}

export interface ActivityIconMap {
  [activityType: string]: string;
}

export interface ActivityTimelineProps {
  activities: Activity[];
  iconMap?: ActivityIconMap;
  agentIcon?: React.ReactNode;
}

// =============================================================================
// Default icon map
// =============================================================================

const DEFAULT_ICON_MAP: ActivityIconMap = {
  'agent-action': 'bolt',
  assignment: 'person',
  comment: 'comment',
  'document-created': 'document',
  'edit-made': 'pencil',
  'status-change': 'refresh',
};

// =============================================================================
// Grouping logic — batch consecutive agent activities
// =============================================================================

type FeedEntry =
  | { kind: 'single'; activity: Activity }
  | { kind: 'batch'; activities: Activity[] };

function groupActivities(activities: Activity[]): FeedEntry[] {
  const entries: FeedEntry[] = [];
  let i = 0;

  while (i < activities.length) {
    const current = activities[i];

    if (current.actor.isAgent) {
      const batch: Activity[] = [current];
      let j = i + 1;
      while (j < activities.length && activities[j].actor.isAgent) {
        batch.push(activities[j]);
        j++;
      }

      if (batch.length >= 2) {
        entries.push({ kind: 'batch', activities: batch });
      } else {
        entries.push({ kind: 'single', activity: current });
      }
      i = j;
    } else {
      entries.push({ kind: 'single', activity: current });
      i++;
    }
  }

  return entries.reverse();
}

// =============================================================================
// Sub-components
// =============================================================================

/** External actors may use an arbitrary palette index; Ink has ten recipients. */
function avatarColorIndex(index?: number): React.ComponentProps<typeof Avatar>['colorIndex'] {
  const palette = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9] as const;
  return index === undefined || !Number.isFinite(index)
    ? undefined
    : palette[((Math.trunc(index) % palette.length) + palette.length) % palette.length];
}

function SingleActivity({
  activity,
  iconMap,
  agentIcon,
}: {
  activity: Activity;
  iconMap: ActivityIconMap;
  agentIcon?: React.ReactNode;
}) {
  // No fallback glyph: Ink has no dot/circle icon, and Icon renders null (plus a
  // console warning) for an unknown name. Render nothing when the type is unmapped.
  const iconName = iconMap[activity.type];
  const showAvatar = !activity.actor.isAgent && activity.actor.initials;

  return (
    <div className={styles.activityItem}>
      <div className={styles.leftColumn}>
        {activity.actor.isAgent ? (
          <div className={styles.agentIconContainer}>
            {agentIcon || <Icon name="bolt" size="small" />}
          </div>
        ) : showAvatar ? (
          <Avatar
            initials={activity.actor.initials!}
            size="xsmall"
            colorIndex={avatarColorIndex(activity.actor.colorIndex)}
          />
        ) : (
          <div className={styles.iconContainer}>
            {iconName && <Icon name={iconName as any} size="small" />}
          </div>
        )}
      </div>

      <div className={styles.rightColumn}>
        <div className={styles.titleRow}>
          <span className={styles.actorName}>{activity.actor.name}</span>
          <span className={styles.activityTitle}>{activity.title}</span>
          <span className={styles.timestamp}>{activity.timestamp}</span>
        </div>
        {activity.description && (
          <span className={styles.activityDescription}>{activity.description}</span>
        )}
      </div>
    </div>
  );
}

function BatchedActivities({
  activities,
  agentIcon,
}: {
  activities: Activity[];
  agentIcon?: React.ReactNode;
}) {
  const [expanded, setExpanded] = useState(false);
  const firstTimestamp = activities[0].timestamp;
  const lastTimestamp = activities[activities.length - 1].timestamp;
  const timeRange =
    firstTimestamp === lastTimestamp ? firstTimestamp : `${firstTimestamp} – ${lastTimestamp}`;

  return (
    <div className={styles.activityItem}>
      <div className={styles.leftColumn}>
        <div className={styles.agentIconContainer}>
          {agentIcon || <Icon name="bolt" size="small" />}
        </div>
      </div>

      <div className={styles.rightColumn}>
        <div className={styles.titleRow}>
          <span className={styles.actorName}>{activities[0].actor.name}</span>
          <span className={styles.activityTitle}>
            Completed {activities.length} actions
          </span>
          <span className={styles.timestamp}>{timeRange}</span>
        </div>

        <ol className={styles.batchList}>
          {activities.map((a) => (
            <li key={a.id} className={styles.batchItem}>
              {a.title}
            </li>
          ))}
        </ol>

        {activities.some((a) => a.description) && (
          <>
            <button
              type="button"
              className={styles.batchToggle}
              onClick={() => setExpanded(!expanded)}
            >
              <Icon name={expanded ? 'chevron-up' : 'chevron-down'} size="small" />
              <span>{expanded ? 'Hide details' : 'Show details'}</span>
            </button>

            {expanded && (
              <div className={styles.batchDetails}>
                {activities
                  .filter((a) => a.description)
                  .map((a) => (
                    <div key={a.id} className={styles.batchDetailItem}>
                      <span className={styles.batchDetailTitle}>{a.title}</span>
                      <span className={styles.batchDetailDesc}>{a.description}</span>
                    </div>
                  ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

// =============================================================================
// Component
// =============================================================================

export function ActivityTimeline({
  activities,
  iconMap = DEFAULT_ICON_MAP,
  agentIcon,
}: ActivityTimelineProps) {
  const entries = groupActivities(activities);

  return (
    <div className={styles.feed}>
      {entries.map((entry, idx) => {
        if (entry.kind === 'single') {
          return (
            <SingleActivity
              key={entry.activity.id}
              activity={entry.activity}
              iconMap={iconMap}
              agentIcon={agentIcon}
            />
          );
        }
        return (
          <BatchedActivities
            key={`batch-${idx}`}
            activities={entry.activities}
            agentIcon={agentIcon}
          />
        );
      })}
    </div>
  );
}
