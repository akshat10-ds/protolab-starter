/**
 * SkillsGrid — Agent capabilities display with expand/collapse
 *
 * A 2-column grid of skill cards with icon + title + description.
 * Shows a configurable number of skills initially with expand to show all.
 *
 * Generalized from e2e-agents SkillsList.
 */

import { useState } from 'react';
import { Icon } from '@ink';
import styles from './SkillsGrid.module.css';

// =============================================================================
// Types
// =============================================================================

export interface Skill {
  id: string;
  icon: string;
  label: string;
  description: string;
}

export interface SkillsGridProps {
  skills: Skill[];
  onSkillClick: (skill: Skill) => void;
  initialCount?: number;
}

// =============================================================================
// Component
// =============================================================================

export function SkillsGrid({
  skills,
  onSkillClick,
  initialCount = 4,
}: SkillsGridProps) {
  const [expanded, setExpanded] = useState(false);
  const visibleSkills = expanded ? skills : skills.slice(0, initialCount);
  const remaining = skills.length - initialCount;

  return (
    <div className={styles.wrapper}>
      <div className={styles.grid}>
        {visibleSkills.map((skill) => (
          <button
            key={skill.id}
            type="button"
            className={styles.card}
            onClick={() => onSkillClick(skill)}
          >
            <div className={styles.cardIcon}>
              <Icon name={skill.icon as any} size="medium" />
            </div>
            <div className={styles.cardText}>
              <span className={styles.cardTitle}>{skill.label}</span>
              <span className={styles.cardDescription}>{skill.description}</span>
            </div>
          </button>
        ))}
      </div>
      {remaining > 0 && (
        <button
          type="button"
          className={styles.expandButton}
          onClick={() => setExpanded(!expanded)}
        >
          <Icon name={expanded ? 'chevron-up' : 'chevron-down'} size="small" />
          <span>{expanded ? 'Show less' : `${remaining} more skills`}</span>
        </button>
      )}
    </div>
  );
}
