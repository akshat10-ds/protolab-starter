/**
 * WelcomeScreen — Zero-query state for agent interfaces
 *
 * Shows greeting, optional catch-up summary, suggested prompts,
 * rich suggestion cards, capability showcase, and agent skills.
 * The first thing users see when opening an agent chat.
 *
 * @deprecated Orphaned scaffolding. Superseded by {@link IrisAgent}'s built-in
 * cold state (`greeting` · `greetingSubtitle` · `categories` ·
 * `customSuggestions` · `coldStateSlot`), which is the zero-query state that
 * actually shipped.
 *
 * No prototype ever consumed this component — `iris-agent`, `iris-panel`, and
 * `iris-canvas` all render `IrisAgent`'s cold state instead, and `IrisAgent`
 * does not import it. Its only call sites are the Playground's own demos of
 * itself and `ChatPanelDemo` (whose subject is likewise deprecated). Its
 * exploration entry (`welcome-screen`) is `status: 'upcoming'` — it has no
 * decided spec. Same signature as `ChatPanel` / `AgentShell`: exported,
 * demoed, never used. See `projects/iris-system/notes/2026-07-09-zero-state.md`.
 *
 * It also cannot *become* IrisAgent's cold state without a redesign: it has no
 * composer, and the composer is the centerpiece of every cold state the
 * prototype shipped (a hero `ChatInput` at full width, a docked one at 360px).
 *
 * What is worth salvaging lives in its props, not its markup: `catchUp` (a
 * proactive briefing) and `suggestionCards` (icon + title + description — the
 * shape of the prototype's dropped panel "Sample questions" cards) are the two
 * cold-state ideas IrisAgent has no expression for. Both are open design
 * questions in the note above; neither is answered here.
 *
 * Retained, not deleted, for the same reason as Tier 3: it shipped to the
 * team's starter in `ai-system-v0.1.0`, and deleting it from Lab HQ would
 * silently remove it from the starter's next release.
 */

import React, { useMemo } from 'react';
import { Icon } from '@ink';
import { SuggestionChip } from '../../primitives/SuggestionChip/SuggestionChip';
import styles from './WelcomeScreen.module.css';

// =============================================================================
// Types
// =============================================================================

export interface SuggestedPrompt {
  id: string;
  label: string;
  icon?: string;
}

export interface SuggestionCard {
  id: string;
  title: string;
  description: string;
  icon?: string;
}

export interface Capability {
  icon: string;
  label: string;
}

/** @deprecated See {@link WelcomeScreen}. Use `IrisAgent`'s cold-state props. */
export interface WelcomeScreenProps {
  /** Greeting text (e.g., "Good morning, Akshat") */
  greeting?: string;
  /** Optional subtitle (e.g., "How can I help you today?") */
  subtitle?: string;
  /** Optional catch-up summary — single string or array of items */
  catchUp?: string | string[];
  /** Suggested prompt chips */
  suggestions?: SuggestedPrompt[];
  /** Called when a suggestion chip is clicked */
  onSuggestionClick?: (suggestion: SuggestedPrompt) => void;
  /** Rich suggestion cards — displayed in a 2-column grid above chips */
  suggestionCards?: SuggestionCard[];
  /** Called when a suggestion card is clicked */
  onCardClick?: (card: SuggestionCard) => void;
  /** Capability showcase — horizontal row of icon + label pairs */
  capabilities?: Capability[];
  /** Agent name for branding */
  agentName?: string;
  /** Custom agent icon */
  agentIcon?: React.ReactNode;
  /** When true, auto-generates time-of-day greeting */
  autoGreeting?: boolean;
  /** User name for auto-greeting (e.g., "Akshat") */
  userName?: string;
}

// =============================================================================
// Helpers
// =============================================================================

function getTimeOfDayGreeting(userName?: string): string {
  const hour = new Date().getHours();
  let period: string;

  if (hour < 12) {
    period = 'morning';
  } else if (hour < 17) {
    period = 'afternoon';
  } else {
    period = 'evening';
  }

  if (userName) {
    return `Good ${period}, ${userName}`;
  }
  return `Good ${period}`;
}

// =============================================================================
// Component
// =============================================================================

/**
 * @deprecated Orphaned scaffolding — superseded by `IrisAgent`'s cold state.
 * See the file header and `projects/iris-system/notes/2026-07-09-zero-state.md`.
 */
export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({
  greeting,
  subtitle,
  catchUp,
  suggestions = [],
  onSuggestionClick,
  suggestionCards = [],
  onCardClick,
  capabilities = [],
  agentName,
  agentIcon,
  autoGreeting = false,
  userName,
}) => {
  const resolvedGreeting = useMemo(() => {
    if (autoGreeting) {
      return getTimeOfDayGreeting(userName);
    }
    return greeting ?? '';
  }, [autoGreeting, userName, greeting]);

  // Normalize catchUp to array
  const catchUpItems = useMemo(() => {
    if (!catchUp) return [];
    if (typeof catchUp === 'string') return [catchUp];
    return catchUp;
  }, [catchUp]);

  return (
    <div className={styles.welcome}>
      {/* Agent branding */}
      {(agentIcon || agentName) && (
        <div className={styles.agent}>
          {agentIcon && <div className={styles.agentIcon}>{agentIcon}</div>}
          {agentName && <span className={styles.agentName}>{agentName}</span>}
        </div>
      )}

      {/* Greeting */}
      {resolvedGreeting && (
        <h1 className={styles.greeting}>{resolvedGreeting}</h1>
      )}
      {subtitle && <p className={styles.subtitle}>{subtitle}</p>}

      {/* Capabilities showcase */}
      {capabilities.length > 0 && (
        <div className={styles.capabilities}>
          {capabilities.map((cap, i) => (
            <React.Fragment key={i}>
              <span className={styles.capability}>
                <Icon name={cap.icon as any} size={14} className={styles.capabilityIcon} />
                <span className={styles.capabilityLabel}>{cap.label}</span>
              </span>
              {i < capabilities.length - 1 && (
                <span className={styles.capabilitySeparator} aria-hidden="true" />
              )}
            </React.Fragment>
          ))}
        </div>
      )}

      {/* Catch-up */}
      {catchUpItems.length > 0 && (
        <div className={styles.catchUp}>
          {catchUpItems.length === 1 ? (
            <>
              <Icon name="info" size={16} className={styles.catchUpIcon} />
              <span className={styles.catchUpText}>{catchUpItems[0]}</span>
            </>
          ) : (
            <div className={styles.catchUpList}>
              {catchUpItems.map((item, i) => (
                <div key={i} className={styles.catchUpItem}>
                  <Icon name="chevron-right" size={12} className={styles.catchUpBullet} />
                  <span className={styles.catchUpText}>{item}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Rich suggestion cards */}
      {suggestionCards.length > 0 && (
        <div className={styles.cardGrid}>
          {suggestionCards.map((card, index) => (
            <button
              key={card.id}
              type="button"
              className={styles.card}
              style={{ animationDelay: `${index * 50}ms` }}
              onClick={() => onCardClick?.(card)}
            >
              {card.icon && (
                <div className={styles.cardIconWrap}>
                  <Icon name={card.icon as any} size={18} className={styles.cardIcon} />
                </div>
              )}
              <div className={styles.cardContent}>
                <span className={styles.cardTitle}>{card.title}</span>
                <span className={styles.cardDescription}>{card.description}</span>
              </div>
              <div className={styles.cardArrow}>
                <Icon name="arrow-right" size={14} />
              </div>
            </button>
          ))}
        </div>
      )}

      {/* Suggestion chips */}
      {suggestions.length > 0 && (
        <div className={styles.suggestions}>
          {suggestions.map((s) => (
            <SuggestionChip
              key={s.id}
              label={s.label}
              icon={s.icon}
              onClick={() => onSuggestionClick?.(s)}
            />
          ))}
        </div>
      )}
    </div>
  );
};
