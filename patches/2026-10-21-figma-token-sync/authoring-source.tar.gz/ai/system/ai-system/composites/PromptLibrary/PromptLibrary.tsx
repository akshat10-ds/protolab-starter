/**
 * PromptLibrary — Browsable prompt collection
 *
 * Google Gems-inspired design with:
 * - Collapsible card grid for system/premade prompts
 * - List view for user-created prompts with hover actions
 * - Empty state when no user prompts exist
 *
 * Generalized from agreement-studio's PromptLibrary.
 * No dependency on prototype-specific data — all prompts are passed in via props.
 */

import React, { useState } from 'react';
import { Icon, IconButton, Button, Tooltip, Dropdown, Text } from '@ink';
import styles from './PromptLibrary.module.css';

// =============================================================================
// Types
// =============================================================================

export interface Prompt {
  id: string;
  title: string;
  description: string;
  instructions?: string;
  icon?: string;
  isCustom?: boolean;
  createdBy?: string;
  isSystem?: boolean;
}

export interface PromptLibraryProps {
  /** System/premade prompts shown as cards */
  systemPrompts: Prompt[];
  /** User-created prompts shown as a list */
  userPrompts?: Prompt[];
  /** Called when a prompt is selected to run */
  onSelectPrompt: (prompt: Prompt) => void;
  /** Called when user wants to edit a prompt */
  onEditPrompt?: (promptId: string) => void;
  /** Called when user wants to create a new prompt */
  onCreatePrompt?: () => void;
  /** Label for the system prompts section */
  systemSectionTitle?: string;
  /** Label for the user prompts section */
  userSectionTitle?: string;
  /** Number of cards to show when collapsed */
  collapsedCount?: number;
}

// =============================================================================
// Component
// =============================================================================

export const PromptLibrary: React.FC<PromptLibraryProps> = ({
  systemPrompts,
  userPrompts = [],
  onSelectPrompt,
  onEditPrompt,
  onCreatePrompt,
  systemSectionTitle = 'System Prompts',
  userSectionTitle = 'My Prompts',
  collapsedCount = 4,
}) => {
  const [systemExpanded, setSystemExpanded] = useState(true);

  const visibleSystemPrompts = systemExpanded
    ? systemPrompts
    : systemPrompts.slice(0, collapsedCount);

  // Premade card
  const renderPremadeCard = (prompt: Prompt) => (
    <div key={prompt.id} className={styles.premadeCard} onClick={() => onSelectPrompt(prompt)}>
      <div className={styles.premadeCardHeader}>
        <div className={styles.premadeCardIcon}>
          <Icon name={(prompt.icon || 'bolt') as any} size={18} />
        </div>
        <div className={styles.premadeCardOverflow}>
          <Dropdown
            items={[
              {
                label: 'Run prompt',
                icon: <Icon name="control-play" size="small" />,
                onClick: () => onSelectPrompt(prompt),
              },
            ]}
            position="bottom"
            align="end"
          >
            <IconButton
              icon="overflow-vertical"
              size="small"
              variant="tertiary"
              onClick={(e) => e.stopPropagation()}
              aria-label="More options"
            />
          </Dropdown>
        </div>
      </div>
      <Text as="div" size="sm" weight="medium" className={styles.premadeCardTitle}>
        {prompt.title}
      </Text>
      <Text as="div" size="xs" color="secondary" className={styles.premadeCardDescription}>
        {prompt.description}
      </Text>
    </div>
  );

  // User prompt list item
  const renderUserPromptItem = (prompt: Prompt) => (
    <button
      key={prompt.id}
      type="button"
      className={styles.promptItem}
      onClick={() => onSelectPrompt(prompt)}
    >
      <div className={styles.promptIcon}>
        <Icon name={(prompt.icon || 'bolt') as any} size={18} />
      </div>
      <div className={styles.promptContent}>
        <Text as="div" size="sm" weight="medium" className={styles.promptTitle}>
          {prompt.title}
        </Text>
        <Text as="div" size="xs" color="secondary" className={styles.promptDescription}>
          {prompt.description}
        </Text>
      </div>
      <div className={styles.promptActions}>
        {onEditPrompt && (
          <Tooltip content="Edit">
            <IconButton
              icon="edit"
              size="small"
              variant="tertiary"
              onClick={(e) => {
                e.stopPropagation();
                onEditPrompt(prompt.id);
              }}
              aria-label="Edit prompt"
            />
          </Tooltip>
        )}
        <Tooltip content="Run">
          <IconButton
            icon="control-play"
            size="small"
            variant="tertiary"
            onClick={(e) => {
              e.stopPropagation();
              onSelectPrompt(prompt);
            }}
            aria-label="Run prompt"
          />
        </Tooltip>
      </div>
    </button>
  );

  return (
    <div className={styles.promptLibrary}>
      {/* System Prompts Section */}
      {systemPrompts.length > 0 && (
        <div className={styles.section}>
          <div className={styles.sectionHeader}>
            <Text as="span" size="md" weight="medium" className={styles.sectionTitle}>
              {systemSectionTitle}
            </Text>
            {systemPrompts.length > collapsedCount && (
              <IconButton
                icon={systemExpanded ? 'chevron-up' : 'chevron-down'}
                size="small"
                variant="tertiary"
                onClick={() => setSystemExpanded(!systemExpanded)}
                aria-label={systemExpanded ? 'Collapse' : 'Expand'}
              />
            )}
          </div>
          <div className={styles.premadeGrid}>
            {visibleSystemPrompts.map((prompt) => renderPremadeCard(prompt))}
          </div>
        </div>
      )}

      {/* User Prompts Section */}
      <div className={styles.section}>
        <div className={styles.sectionHeader}>
          <Text as="span" size="md" weight="medium" className={styles.sectionTitle}>
            {userSectionTitle}
          </Text>
          {onCreatePrompt && (
            <Button size="small" kind="secondary" onClick={onCreatePrompt}>
              <Icon name="plus" size={14} />
              New Prompt
            </Button>
          )}
        </div>
        <div className={styles.promptList}>
          {userPrompts.length > 0 ? (
            userPrompts.map((prompt) => renderUserPromptItem(prompt))
          ) : (
            <div className={styles.emptyState}>
              <Icon name="document-stack" size={24} className={styles.emptyIcon} />
              <Text size="sm" color="secondary">
                No custom prompts yet
              </Text>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
