/**
 * ExecutionTrace — Task-level step progress tracker
 *
 * Shows as a sticky bar at the bottom of the chat, collapsible.
 * Displays "Step 3/5: Analyzing clauses..." with horizontal progress dots.
 * Expand to see all steps with status icons.
 */

import React, { useState, useMemo } from 'react';
import { Icon } from '@ink';
import styles from './ExecutionTrace.module.css';

// =============================================================================
// Types
// =============================================================================

export type ExecutionStepStatus = 'pending' | 'active' | 'complete' | 'error';

export interface ExecutionStep {
  id: string;
  label: string;
  status: ExecutionStepStatus;
  detail?: string;
}

export interface ExecutionTraceProps {
  /** Array of execution steps */
  steps: ExecutionStep[];
  /** Whether the detail view is collapsed */
  isCollapsed?: boolean;
  /** Toggle collapse callback */
  onToggle?: () => void;
}

// =============================================================================
// Component
// =============================================================================

export const ExecutionTrace: React.FC<ExecutionTraceProps> = ({
  steps,
  isCollapsed: controlledCollapsed,
  onToggle,
}) => {
  const [internalCollapsed, setInternalCollapsed] = useState(true);
  const isControlled = controlledCollapsed !== undefined;
  const isCollapsed = isControlled ? controlledCollapsed : internalCollapsed;

  const handleToggle = () => {
    if (onToggle) {
      onToggle();
    }
    if (!isControlled) {
      setInternalCollapsed((prev) => !prev);
    }
  };

  // Derive current step info
  const { activeStep, activeIndex, completedCount } = useMemo(() => {
    const active = steps.find((s) => s.status === 'active');
    const idx = active ? steps.indexOf(active) : -1;
    const completed = steps.filter((s) => s.status === 'complete').length;
    return { activeStep: active, activeIndex: idx, completedCount: completed };
  }, [steps]);

  const currentStepNumber = activeIndex >= 0 ? activeIndex + 1 : completedCount;
  const label = activeStep
    ? activeStep.label
    : completedCount === steps.length
      ? 'All steps complete'
      : 'Waiting...';

  return (
    <div className={styles.trace}>
      {/* Collapsed bar */}
      <div className={styles.bar} onClick={handleToggle} role="button" tabIndex={0}>
        <div className={styles.barLeft}>
          {/* Progress dots */}
          <div className={styles.progressDots}>
            {steps.map((step) => (
              <div
                key={step.id}
                className={styles.progressDot}
                data-status={step.status}
                title={step.label}
              />
            ))}
          </div>

          <span className={styles.stepLabel}>{label}</span>
        </div>

        <div className={styles.barRight}>
          <span className={styles.stepCounter}>
            {currentStepNumber}/{steps.length}
          </span>
          <Icon
            name="chevron-down"
            size={14}
            className={styles.chevron}
            data-expanded={!isCollapsed}
          />
        </div>
      </div>

      {/* Expanded step list */}
      {!isCollapsed && (
        <div className={styles.stepsList}>
          {steps.map((step) => (
            <div key={step.id} className={styles.step}>
              <div className={styles.stepIcon} data-status={step.status}>
                {step.status === 'complete' && <Icon name="check" size={14} />}
                {step.status === 'error' && <Icon name="close" size={14} />}
                {step.status === 'active' && <div className={styles.spinner} />}
                {step.status === 'pending' && <Icon name="minus" size={14} />}
              </div>
              <div className={styles.stepInfo}>
                <span className={styles.stepName} data-status={step.status}>
                  {step.label}
                </span>
                {step.detail && (
                  <span className={styles.stepDetail}>{step.detail}</span>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
