/**
 * ProgressReceipt — one line saying a run happened, and the way to the rest.
 *
 * Frame 237:42439: a ring, "N of M steps completed" and a Review on the right.
 * (The ring is gone — see `StepMark`. Progress here is named, not measured.)
 * (The frame reads "2 out 3"; the copy is "2 of 3".)
 *
 * **A HEADER AND THE CURRENT STEP** — v4, 2026-08-19.
 *
 *   header   step mark · "Step N of M · {currentStep}" · `badge` · chevron
 *   contents open by default, under the header — what is inside THAT step.
 *
 * The trailing action is OPTIONAL, and in FINS it is absent: Akshat,
 * 2026-08-20, moved "Details ›" out of this box and onto the section label row
 * above it, as a hover-revealed text link (`LabeledSection`). No flag was
 * needed — `onOpen` is the only thing that draws the button, so a host that
 * renders the door itself simply does not pass it.
 *
 * **THE RECEIPT IS ONE STEP; THE ARTIFACT IS ALL OF THEM.** One concept at two
 * doses, and it is the whole rule. `contents` is literally the same list the
 * artifact renders under the step the header names — the host derives both from
 * one place, so the panel and the pane can never disagree.
 *
 * That rule replaced a two-group ledger (Waiting on others / Needs you / N
 * done) the same day. Akshat, on the built thing: *"this doesn't feel clear."*
 * Three faults, all structural: it narrated the recommendation that was already
 * sitting in a card directly below it, it stacked a second counting system
 * (Needs you / N done) beside "Step 1 of 4", and "1 done" named nothing the
 * officer could point at. **Recommendations never appear here** — they have
 * their own section and their own place in the artifact.
 *
 * A task ledger still emerges, without being one: at a step whose contents ARE
 * tasks — "Documents" — the lines are the documents and their states. Same code
 * path, no branch. `state` is the clause after the label.
 *
 * **STEP NAMES ARE THE OFFICER'S PHASES**, not the agent's diary — "Disclosures",
 * not "Classified". A past-tense machine action tells you what happened; a phase
 * tells you where you are, which is what a step in a stepper is for. The host
 * writes them.
 *
 * **NO TIMESTAMPS.** When a thing happened is the audit log's job. This says
 * what is true now.
 *
 * `badge` is a slot and not a string: the caller passes its own design system's
 * badge (Ink's, in FINS), so this component does not acquire an opinion about
 * how a badge looks. Akshat: *"maybe we just use a badge component there."*
 *
 * **It appears only once the agent has run at least once** (Akshat, same day).
 * That is the host's gate: a receipt for nothing is a promise, not a receipt.
 * This component draws whatever counts it is handed.
 *
 * **The line says what is happening, not only how far along.** Akshat,
 * 2026-08-19: "Show a little more info than just saying on step 2 of 3 but not
 * everything." So `currentStep` names the step, and the ledger says what is
 * open. The dose is what is NOT here: no timestamps, no findings, no history,
 * and finished work reduced to a number. On the header, width is taken from the
 * step name first — the count and the badge both hold. A receipt that has lost
 * its count has stopped being a receipt.
 *
 * **It also carries the working state.** Akshat, same day: "right after you
 * upload we're showing a random thinking process — that looks weird, maybe we
 * just use the progress bar box to show we're processing." So a run with no
 * thread to put it in does not stream a thinking block above this row; it starts
 * here.
 *
 * **The working state is the research card's, 2026-08-19.** Akshat: *"when there
 * is work we can show a shimmer over the loan progress — literally the same
 * thing."* So `working` sweeps a `Shimmer` across the whole box, keeps the 20px
 * ring turning inside it (there is no step numeral for "part way through step
 * one"), and hands the line to the live activity with `statusMeta` holding the
 * count and the elapsed. **The accordion stays open for business** —
 * what they show is the run as it happens. On completion the host drops
 * `working`, the sweep stops and the same box resolves in place to the resting
 * header. A run *inside* a thread is unchanged: the thread is the event
 * surface, and its turns still tick.
 *
 * **THE EXPAND/COLLAPSE IS INK'S ACCORDION** — Akshat, 2026-08-20. The header
 * line is the item's `header` slot, Ink's chevron is the chevron, and the
 * window is the item's content. Two consequences worth knowing: the window now
 * opens directly under the header (the peek follows it, where it used to sit
 * between them), and a receipt with no `history` keeps the plain header rather
 * than an accordion — an item with empty content would still draw a chevron and
 * promise a window that is not there.
 *
 * Generic on purpose. `label` is the context — "in loan", "in this review" —
 * and no scenario copy lives inside. That holds for `currentStep` and `status`
 * too: they are strings the host writes.
 */

import React, { useState } from 'react';

import { Accordion, Icon, Timeline } from '@ink';

import { Shimmer } from '../../primitives/Shimmer/Shimmer';
import { CollapsedHandoff } from '../CollapsedHandoff/CollapsedHandoff';
import styles from './ProgressReceipt.module.css';

// =============================================================================
// Types
// =============================================================================

/**
 * One line of the current step.
 *
 * A fact the step established ("Classified as Conforming"), or a task it is
 * waiting on. `state` is the clause after the label — "viewed yesterday", "not
 * opened yet" — and is what turns a list of facts into a ledger without the
 * component knowing it did.
 */
export interface ReceiptTask {
  id: string;
  label: string;
  state?: string;
  /** Where this line goes. Omit and the line is text, not a target. */
  onOpen?: () => void;
}

/**
 * One row of the accordion's window — a realized event or a planned one.
 * `status` is Ink's Timeline vocabulary, so the receipt, the artifact and the
 * plan all speak it.
 */
export interface ReceiptEvent {
  id: string;
  label: string;
  time?: string;
  status: 'complete' | 'current' | 'incomplete';
}

export interface ProgressReceiptProps {
  /** Steps done. Clamped into 0…total — it is the step number and the check. */
  completed: number;
  /** Steps in the run. */
  total: number;
  /**
   * What the steps are in — "in loan". Follows the count on the same line.
   * Superseded by `currentStep` when that is given: the step name is the better
   * use of the same room.
   */
  label?: string;
  /**
   * The step the run is on, named — "Collecting documents". Give it and line 1
   * becomes "2 of 4 · Collecting documents"; omit it and the original
   * "2 of 4 steps completed in loan" is drawn unchanged, on its own.
   */
  currentStep?: string;
  /**
   * Every step's name, in order — what "Step 2 of 4" is 2 of.
   *
   * The receipt is one step at a time by design, but a position in a sequence
   * is meaningless without the sequence. This rides as a tooltip on the count
   * rather than as a row, because the whole point of the receipt is that it is
   * one line until you ask it for more.
   */
  stepNames?: string[];
  /**
   * The short clause about that step — "3 requested, 1 returned". Drawn under
   * the header, in the quiet register, for a host with no ledger to show.
   *
   * When `working`, this is the whole line instead: the live activity, e.g.
   * "Reading the application…".
   */
  status?: string;
  /**
   * The clause that HOLDS at the end of the status line — a count where the run
   * has one, and how long it has been going: "2 of 3 · 4s".
   *
   * Separate from `status` because the activity name is what gives way when the
   * line is short of room, and where-you-are-in-the-run is what must not. Same
   * rule as the header's count.
   */
  statusMeta?: string;
  /**
   * WHO IS BLOCKING, AND WHAT IS NEXT — one plain sentence at the top of the
   * peek, above everything the step contains.
   *
   * Akshat, 2026-08-20: *"Make the summary/status of current loan clear."* The
   * header names the step and the peek lists what is inside it; neither says
   * whether the ball is with the reader or with someone else, which is the
   * first thing anyone opens a file to learn.
   *
   * The host writes it — this component holds no scenario copy — and the host
   * derives it from the SAME selector its own "needs you" count reads, or the
   * line and the number drift.
   *
   * Not drawn while `working`: the live activity owns the line, and a run that
   * has not landed is not blocked on anybody.
   */
  summary?: string;
  /**
   * What is inside the step the header names — the same list the artifact
   * renders under that step, at this dose. Facts, tasks, or both; the host does
   * not sort them, because at any one step they are all the same kind of thing:
   * the contents of where you are.
   *
   * NEVER RECOMMENDATIONS. Those have their own section and their own card.
   */
  contents?: ReceiptTask[];
  /**
   * THE ACCORDION — a window onto the run, opened in place.
   *
   * The receipt's own line names one step and its peek shows what is inside
   * that step; neither says how the loan got here or where it goes next. The
   * first click on the header opens this: the last two things that happened,
   * where the loan is now, and the one thing planned after it.
   *
   * IT IS A SLICE OF THE HOST'S EVENT LOG, never a second list — the same rows
   * the full view draws, cut to four. Hand it none and the header does not
   * become a toggle: there is nothing to open.
   *
   * One box, two depths; the third is a different surface, reached from
   * whatever door the host draws — in FINS, the label row above this box.
   */
  history?: ReceiptEvent[];
  /**
   * WHAT THIS STEP STILL HAS TO DO — the plan rows for the step the header
   * names, drawn under the peek in the window's own row grammar: grey dot,
   * future-form label, no timestamp.
   *
   * Akshat, 2026-08-20: one visual language whether a step has history or only
   * a plan. A not-yet line written as prose ("Initial disclosures not yet
   * sent") is a second way of saying what a planned row already says, so the
   * host hands the plan rows themselves and this draws them as rows.
   *
   * Status is not a field: a planned row is planned. A host that has a row it
   * wants drawn as done has an event, not a plan.
   */
  planned?: { id: string; label: string }[];
  /**
   * One line about the thing that just landed, above the contents. The host
   * drops it when the next beat starts.
   */
  confirmation?: React.ReactNode;
  /**
   * Drawn at the end of line 1 — a classification, a state, one word about what
   * this run decided. A node, so it is the caller's own badge component and this
   * receipt keeps no opinion about badges.
   *
   * Not drawn while `working`: a run that has not landed has classified nothing.
   */
  badge?: React.ReactNode;
  /**
   * The run is going. Turning mark, `status` as the line, no action.
   * Resolves in place — same row, same box — when the host drops it.
   */
  working?: boolean;
  /**
   * Trailing action, drawn only when `onOpen` is given. Default: "Details".
   */
  actionLabel?: string;
  /**
   * Draws the trailing action, and opens the artifact in the dock. OMIT IT AND
   * THE BOX DRAWS NO ACTION — that is the whole switch, and it is what FINS
   * does now that its door lives on the section label row.
   */
  onOpen?: () => void;
  /**
   * THE ARTIFACT THIS RECEIPT OPENS IS OPEN BESIDE IT.
   *
   * The peek and the pane would then be showing the same step twice, so the
   * receipt collapses to its header line and takes the handoff paint — the same
   * grammar the search results card uses, and literally the same component
   * (`CollapsedHandoff`). Pressing the row closes the pane and the peek returns.
   *
   * Derived by the host from `artifact.openId`, never stored: the receipt keeps
   * no memory of a pane it does not own.
   *
   * The LINE does not change. A results card swaps "Showing 5 results" for
   * "Seeing results in right panel" because its rest label counts what the pane
   * now holds; the receipt's line names where the run is, which is true in both
   * states and is the reason to keep the row at all.
   */
  active?: boolean;
  /**
   * Closes the pane this receipt handed its contents to. Drawn only while
   * `active` — at rest there is nothing to close, and `onOpen` is the door.
   *
   * Omit it and an active receipt is state only: the collapsed row says where
   * the contents went and is not pressable. Same rule as `CollapsedHandoff`.
   */
  onClose?: () => void;
}

// =============================================================================
// Component
// =============================================================================

/*
 * PROGRESS IS NAMED, NEVER MEASURED. Akshat, 2026-08-19, on the ring: *"even
 * the progress bar looks wrong"* — and his pointer was the ds-ui Progress
 * Stepper, which has no bar and no arc. It has named steps, a numbered circle
 * for where you are, and a check for what is behind you.
 *
 * A receipt header is not a stepper row, so this is the stepper's vocabulary at
 * its smallest honest dose: ONE 20px circle, the stepper's own 32px geometry
 * scaled to a line. The numeral is the step you are on — the same number the
 * line names, which is the point, because a mark that says something the words
 * do not is a second system. When every step is behind you it is the stepper's
 * completed treatment: a check on lilac.
 *
 * WORKING KEEPS A SPINNER, because an indeterminate thing is what is honest
 * while a run is going — there is no step number for "part way through step
 * one". Same circle, same indigo, turning.
 */
const MARK = 20;
const WORKING_ARC = 0.25;
const STROKE = 2;
const R = (MARK - STROKE) / 2;
const C = 2 * Math.PI * R;

const StepMark = ({
  step,
  complete,
  working,
}: {
  step: number;
  complete: boolean;
  working?: boolean;
}) => {
  if (working)
    return (
      <svg
        className={styles.mark}
        width={MARK}
        height={MARK}
        viewBox={`0 0 ${MARK} ${MARK}`}
        aria-hidden="true"
      >
        <circle
          className={styles.markTrack}
          cx={MARK / 2}
          cy={MARK / 2}
          r={R}
          strokeWidth={STROKE}
          fill="none"
        />
        <circle
          className={`${styles.markArc} ${styles.markSpin}`}
          cx={MARK / 2}
          cy={MARK / 2}
          r={R}
          strokeWidth={STROKE}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={`${C * WORKING_ARC} ${C}`}
        />
      </svg>
    );

  return (
    <span
      className={`${styles.mark} ${complete ? styles.markComplete : styles.markCurrent}`}
      aria-hidden="true"
    >
      {complete ? <Icon name="check" size={14} /> : step}
    </span>
  );
};

export const ProgressReceipt = ({
  completed,
  total,
  label,
  currentStep,
  stepNames,
  status,
  statusMeta,
  summary,
  contents = [],
  history = [],
  planned = [],
  confirmation,
  badge,
  working = false,
  actionLabel = 'Details',
  onOpen,
  active = false,
  onClose,
}: ProgressReceiptProps) => {
  /* The accordion's own memory. Closed: the receipt is a line first. */
  const [expanded, setExpanded] = useState(false);
  const done = Math.max(0, Math.min(completed, total));
  const allDone = total > 0 && done >= total;
  /*
    The step you are ON, not the number behind you. With one step complete of
    four you are on the second — and when the last one completes you are on it,
    not on a fifth. The mark carries that number; the words carry it too.
  */
  const stepNumber = Math.min(done + 1, total);

  /*
    Drawn while there is anything in it, and there is no toggle. A peek that has
    to be opened is a peek nobody opens, and the door to the full view is
    already the way to more than this.
  */
  const hasContents =
    !working && (!!summary || contents.length > 0 || planned.length > 0 || !!confirmation);

  const line = working ? (
    /* The activity IS the line, and it is the only line — a run that has
       not landed has no step contents and has classified nothing.
       `role="status"` because this row is the only place the run appears.
       `statusMeta` — the count and the elapsed — holds; the activity name is
       what gives way, exactly as the step name does in the resting form. */
    <p className={`${styles.line} ${styles.lineParts}`} role="status">
      <span className={styles.step}>{status}</span>
      {statusMeta && <span className={styles.statusMeta}>{statusMeta}</span>}
    </p>
  ) : currentStep ? (
    <p className={`${styles.line} ${styles.lineParts}`}>
      {/*
        THE FOUR STEP NAMES, ON THE COUNT. The loan-officer review: *"step names
        invisible until Details."* "Step 2 of 4" says where you are in a
        sequence nobody has shown you, so the count carries the sequence.
      */}
      <span className={styles.count} title={stepNames?.length ? stepNames.map((n, i) => `${i + 1}. ${n}`).join('  ·  ') : undefined}>
        {`Step ${stepNumber} of ${total}`}
      </span>
      {/*
        A NON-BREAKING SPACE, DELIBERATELY. The separator lives inside this
        span's string, and a flex item's leading whitespace is at the start of
        its own line box, where the browser drops it — which rendered
        "Step 2 of 4· Disclosures". `\u00A0` survives.
      */}
      <span className={styles.step}>{`\u00A0· ${currentStep}`}</span>
      {/* The badge holds its width; the step name is what gives way. */}
      {badge && <span className={styles.badge}>{badge}</span>}
    </p>
  ) : (
    <p className={styles.line}>
      {done} of {total} steps completed{label ? ` ${label}` : ''}
    </p>
  );

  /*
    The pane is showing this step already. The receipt keeps its line — that is
    the one thing the pane does not say twice — and drops everything the pane
    now holds: the peek, the confirmation, the status clause, and the trailing
    action, which is the door to the place you are already in.
  */
  if (active) {
    return (
      <CollapsedHandoff onClose={onClose} ariaLabel="Close the progress panel">
        <StepMark step={stepNumber} complete={allDone} working={working} />
        {line}
      </CollapsedHandoff>
    );
  }

  /*
    THE HEADER IS THE ACCORDION. Pressing the line opens the window in place.
    Where a host also passes `onOpen`, the trailing action beside it leaves for
    the full view — two gestures, two depths, and they do not compete.
  */
  /*
    THE ACCORDION SURVIVES THE RUN. Akshat, 2026-08-19: the chevron and the
    full view stay available while the agent works, and what they open is the LIVE
    timeline — a surface that goes unreadable exactly when something is
    happening on it is the wrong way round.
  */
  const canExpand = history.length > 0;
  const mark = <StepMark step={stepNumber} complete={allDone} working={working} />;

  /*
    THE ACCORDION IS INK'S. Akshat, 2026-08-20: the receipt does not hand-roll
    an expand/collapse. The header line becomes the item's `header` slot, Ink's
    chevron is the chevron, and the window is the item's content. The open state
    stays here — one item, controlled — because the receipt is the thing that
    knows whether there is anything to open.
  */
  const RUN = 'run';

  /* The trailing action, where a host draws one. */
  const action = onOpen ? (
    <button type="button" className={styles.action} onClick={onOpen}>
      {actionLabel}
      <Icon name="chevron-right" size={14} />
    </button>
  ) : null;

  return (
    /*
      THE SHIMMER IS THE LIVE SIGNAL. Akshat, 2026-08-19: *"when there is work
      we can show a shimmer over the loan progress — literally the same thing"*
      as Claude's research card. The box you are already reading takes a slow
      sweep; nothing is replaced by a skeleton and no bar is drawn.

      The 20px ring stays under it. At that size the mark is the only thing
      that can say WHERE the work is, and while a run is going there is no step
      numeral to put in the circle — without the arc the mark would be an empty
      disc. Sweep for the box, arc for the mark: two scales, one state.
    */
    <Shimmer
      active={working}
      className={`${styles.card} ${working ? styles.cardWorking : ''} ${canExpand ? styles.cardExpandable : ''}`}
    >
      <div className={styles.header}>
        {canExpand ? (
          /*
            ponytail: with `onOpen` ALSO given, the action sits beside the whole
            accordion, so an open window is narrower than the card by the
            action's width. Unreachable in FINS — its door lives on the section
            label row — and the fix if a consumer ever passes both is to lift
            the action out of this row entirely.
          */
          <Accordion
            className={styles.accordion}
            openItems={expanded ? [RUN] : []}
            onOpenItemsChange={(ids) => setExpanded(ids.includes(RUN))}
            items={[
              {
                id: RUN,
                /* Never drawn — `header` takes the title row. It is the item's
                   name for anything that reads the data rather than the DOM. */
                title: currentStep ?? `Step ${stepNumber} of ${total}`,
                header: (
                  <>
                    {mark}
                    {line}
                  </>
                ),
                noPadding: true,
                /*
                  The window. One rail, no dark travelled segments — inside a
                  receipt the rail is a spine, not a progress bar, and the count
                  above it is already saying how far along the run is.
                */
                content: (
                  <div className={styles.window}>
                    <Timeline
                      railTone="subtle"
                      items={history.map((event) => ({
                        id: event.id,
                        label: event.label,
                        timestamp: event.time,
                        status: event.status,
                      }))}
                    />
                  </div>
                ),
              },
            ]}
          />
        ) : (
          <>
            {mark}
            {line}
          </>
        )}

        {action}
      </div>

      {/* The status clause, for a host with nothing to put in the peek. */}
      {!working && !hasContents && status && <p className={styles.statusLine}>{status}</p>}

      {hasContents && (
        <div className={styles.ledger}>
          {/* The frame for everything under it, so it goes first — before the
              thing that just landed and before the step's own lines. */}
          {summary && <p className={styles.summary}>{summary}</p>}
          {confirmation && <div className={styles.confirmation}>{confirmation}</div>}
          {contents.length > 0 && (
            <ul className={styles.groupList}>
              {contents.map((item) => {
                /* A line that goes somewhere is a button; one that does not is
                   text. Nothing is drawn to look clickable and then refuse. */
                const Row = item.onOpen ? 'button' : 'div';
                return (
                  <li key={item.id}>
                    <Row
                      {...(item.onOpen ? { type: 'button' as const, onClick: item.onOpen } : {})}
                      className={`${styles.task} ${item.onOpen ? styles.taskLink : ''}`}
                    >
                      <span className={styles.taskLabel}>{item.label}</span>
                      {item.state && <span className={styles.taskState}>{item.state}</span>}
                    </Row>
                  </li>
                );
              })}
            </ul>
          )}

          {/*
            What this step still has to do, in the window's own grammar — grey
            dot, future-form label, no timestamp. Same `Timeline`, same rail
            tone: a step with only a plan reads like a step with history.
          */}
          {planned.length > 0 && (
            <Timeline
              railTone="subtle"
              items={planned.map((row) => ({
                id: row.id,
                label: row.label,
                status: 'incomplete' as const,
              }))}
            />
          )}
        </div>
      )}
    </Shimmer>
  );
};

ProgressReceipt.displayName = 'ProgressReceipt';
