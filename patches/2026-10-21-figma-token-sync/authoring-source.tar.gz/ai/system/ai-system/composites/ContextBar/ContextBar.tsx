/**
 * ContextBar — Row of loaded context items
 *
 * Displays documents, files, and screen context that the agent
 * currently has loaded. Supports add/remove actions.
 */

import React from 'react';
import { Icon } from '@ink';
import { ContextPill } from '../../primitives/ContextPill/ContextPill';
import styles from './ContextBar.module.css';

// =============================================================================
// Types
// =============================================================================

export interface ContextItem {
  id: string;
  label: string;
  icon?: string;
}

export interface ContextBarProps {
  /** Currently loaded context items */
  items: ContextItem[];
  /** Called when an item is dismissed */
  onDismiss?: (id: string) => void;
  /** Called when an item is clicked */
  onItemClick?: (id: string) => void;
  /** Called when the add button is clicked */
  onAdd?: () => void;
  /** Max items to show before "+N more" */
  maxVisible?: number;
}

// =============================================================================
// Component
// =============================================================================

export const ContextBar: React.FC<ContextBarProps> = ({
  items,
  onDismiss,
  onItemClick,
  onAdd,
  maxVisible = 5,
}) => {
  if (items.length === 0 && !onAdd) return null;

  const visibleItems = items.slice(0, maxVisible);
  const overflowCount = items.length - maxVisible;

  return (
    <div className={styles.bar}>
      <div className={styles.items}>
        {visibleItems.map((item) => (
          <ContextPill
            key={item.id}
            label={item.label}
            icon={item.icon}
            onDismiss={onDismiss ? () => onDismiss(item.id) : undefined}
            onClick={onItemClick ? () => onItemClick(item.id) : undefined}
          />
        ))}
        {overflowCount > 0 && (
          <span className={styles.overflow}>+{overflowCount} more</span>
        )}
      </div>
      {onAdd && (
        <button type="button" className={styles.addButton} onClick={onAdd} aria-label="Add context">
          <Icon name="plus" size={14} />
        </button>
      )}
    </div>
  );
};
