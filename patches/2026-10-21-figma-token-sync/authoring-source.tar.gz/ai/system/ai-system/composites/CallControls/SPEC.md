# CallControls

Summary: Controlled voice-call actions beside a canonical IrisAgent conversation. The host owns audio and session state.

- Import `CallControls` and `CallControlsProps` from `@ai`.
- `status`: idle, connecting, live, ending or error. No automatic microphone request, timer or network access occurs in this component.
- `onStart`, `onEnd`, `onToggleMute` report deliberate actions. `muted` is host truth and is exposed through `aria-pressed` and visible text.
- `showEntry` defaults true. Set false on a persistent host strip so idle controls only appear inside Iris. An active call and an error remain visible.
- `onShowTranscript` optionally navigates to the host's existing conversation. This component never draws transcript messages.
- `presentation="call"` adds a compact horizontal Iris identity/status header with stock icon controls; the default `compact` preserves the persistent strip. The host pins this header outside the canonical transcript scroller and shows only one set of call controls at a time. Error text may expand the header naturally.
- Errors provide Retry and Dismiss. Dismiss reports `onEnd`; the host clears the failed session and keeps any returned transcript available.
- Stock Ink Buttons, Icons and StatusLight preserve focus and interaction treatments. Status is announced politely; a supplied connection error is announced as an alert.
- Controls wrap and use a 48px minimum height on coarse pointers. There is no decorative audio animation or fake activity signal.
- When a new call disables or removes its initiating control and focus is lost, the controls focus Cancel/End through their own button ref. A failed call similarly focuses Retry if focus is lost. Existing focus in another control or page is preserved; live updates never move it. Returning to a host composer after End remains host-owned.

Place the active strip outside route/detail takeovers so End and Mute remain reachable while a voice tool opens a record. The canonical IrisAgent continues to render controlled transcript messages. Do not place API credentials or transport logic in these controls.

Provenance: Wayfinder live Iris voice request, 2026-10-02. New capability; no Figma fidelity claim or broad accessibility certification.
