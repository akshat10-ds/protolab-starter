import { useEffect, useRef } from 'react';
import { Button, Heading, Icon, IconButton, IrisIcon, StatusLight, Text } from '@ink';
import styles from './CallControls.module.css';

export type CallStatus = 'idle' | 'connecting' | 'live' | 'ending' | 'error';

export interface CallControlsProps {
  status: CallStatus;
  muted?: boolean;
  error?: string | null;
  onStart: () => void;
  onEnd: () => void;
  onToggleMute: () => void;
  /** Show the idle Call Iris entry. Active call controls are always shown. */
  showEntry?: boolean;
  /** A host route to the existing conversation, never a second transcript. */
  onShowTranscript?: () => void;
  /** Full call identity and controls inside Iris; compact remains the default. */
  presentation?: 'compact' | 'call';
}

/** Controlled call chrome. Audio, permissions and session lifecycle belong to the host. */
export function CallControls({ status, muted = false, error, onStart, onEnd, onToggleMute, showEntry = true, onShowTranscript, presentation = 'compact' }: CallControlsProps) {
  const endRef = useRef<HTMLButtonElement>(null);
  const startRef = useRef<HTMLButtonElement>(null);
  const previousStatus = useRef<CallStatus | null>(null);
  useEffect(() => {
    const previous = previousStatus.current;
    previousStatus.current = status;
    const entering = (status === 'connecting' || status === 'live') && (previous === null || previous === 'idle' || previous === 'error');
    const failed = status === 'error' && previous !== 'error';
    if (!entering && !failed) return;
    const frame = requestAnimationFrame(() => {
      const focused = document.activeElement;
      if (focused === document.body || (focused instanceof HTMLButtonElement && focused.disabled)) {
        (failed ? startRef : endRef).current?.focus();
      }
    });
    return () => cancelAnimationFrame(frame);
  }, [status]);
  const active = status === 'connecting' || status === 'live' || status === 'ending';
  if (!active && !showEntry && status !== 'error') return null;
  const label = presentation === 'call' ? status === 'connecting' ? 'Connecting…'
    : status === 'ending' ? 'Ending…'
    : status === 'live' ? muted ? 'Microphone muted' : 'Call in progress'
    : status === 'error' ? 'Call unavailable' : 'Call Iris'
    : status === 'connecting' ? 'Connecting to Iris…'
    : status === 'ending' ? 'Ending call…'
    : status === 'live' ? muted ? 'Iris call · Microphone muted' : 'Iris call · Microphone on'
    : status === 'error' ? 'Iris call unavailable' : 'Call Iris';
  return <section className={`${styles.controls} ${presentation === 'call' ? styles.call : ''}`} aria-label="Iris voice call" data-call-status={status}>
    <div className={styles.row}>
      <div className={styles.identityStatus}>
      {presentation === 'call' && <div className={styles.identity}>
        <span className={styles.mark} aria-hidden="true"><IrisIcon /></span>
        <Heading as="h2" level={6} className={styles.title}>Iris</Heading>
      </div>}
      {active || status === 'error' ? <div className={styles.status} role="status" aria-live="polite" aria-atomic="true">
        <StatusLight noFill kind={status === 'live' ? 'success' : status === 'error' ? 'alert' : 'neutral'} text={label} />
      </div> : null}
      </div>
      <div className={styles.actions}>
        {!active ? <><Button ref={startRef} kind="secondary" size="small" className={styles.action} onClick={onStart}
          startElement={<Icon name="microphone" size="small" />}>{status === 'error' ? 'Try call again' : 'Call Iris'}</Button>
          {status === 'error' && <Button kind="tertiary" size="small" className={styles.action} onClick={onEnd}>Dismiss</Button>}
        </> : <>
          {onShowTranscript && <Button kind="tertiary" size="small" className={styles.action} onClick={onShowTranscript}>View conversation</Button>}
          {presentation === 'call' ? <>
            <IconButton variant="secondary" size="small" className={styles.action} icon={muted ? 'microphone-slash' : 'microphone'} onClick={onToggleMute} disabled={status !== 'live'} aria-pressed={muted} aria-label={muted ? 'Unmute microphone' : 'Mute microphone'} />
            <IconButton ref={endRef} variant="secondary" size="small" className={styles.action} icon="close" onClick={onEnd} disabled={status === 'ending'} aria-label={status === 'connecting' ? 'Cancel call' : 'End call'} />
          </> : <><Button kind="secondary" size="small" className={styles.action} onClick={onToggleMute} disabled={status !== 'live'}
            aria-pressed={muted} aria-label={muted ? 'Unmute microphone' : 'Mute microphone'}
            startElement={<Icon name={muted ? 'microphone-slash' : 'microphone'} size="small" />}>{muted ? 'Unmute' : 'Mute'}</Button>
          <Button ref={endRef} kind="secondary" size="small" className={styles.action} onClick={onEnd} disabled={status === 'ending'}
            startElement={<Icon name="close" size="small" />}>{status === 'connecting' ? 'Cancel call' : 'End call'}</Button></>}
        </>}
      </div>
    </div>
    {status === 'error' && error && <Text as="p" size="sm" className={styles.error} role="alert">{error}</Text>}
  </section>;
}
