/**
 * LabeledSection — a zero-query section label, and the way out of that section.
 *
 * Akshat, 2026-08-20: the receipt's "Details ›" comes OUT of the box and goes
 * into the section-label row, as a hover-revealed TEXT LINK — and the
 * Recommended section gets the same treatment. So the label row is now two
 * things: what this section is, left; where the rest of it lives, right.
 *
 * **THE LINK IS REVEALED BY THE WHOLE SECTION, NOT BY ITS OWN ROW.** The
 * children are inside the hover scope, so pointing at the receipt — the thing
 * you actually want more of — is what brings up the way to more of it. Pointing
 * at a label to find a link about the block below it is the wrong way round.
 *
 * The reveal is `CollapsedHandoff`'s "Close" treatment, verbatim: `opacity`
 * only, on `--ai-motion-duration-handle`, never `display`. The row must not
 * change width when the link arrives — a label that shifts on hover is a label
 * you stop trusting.
 *
 * `label` is a node, not a string: the host already owns its label typography
 * (Ink's `Text`, in FINS) and this component acquires no opinion about it.
 *
 * **No `onAction`, no link.** A section whose contents are already open in the
 * pane has nowhere to send you — the collapsed row inside it carries "Close"
 * instead — so the host drops the handler and the row goes back to being a
 * label. Same rule as `CollapsedHandoff`'s own `onClose`.
 */

import React from 'react';

import { Icon } from '@ink';

import styles from './LabeledSection.module.css';

export interface LabeledSectionProps {
  /** What this section is. The host's own label element, unchanged. */
  label: React.ReactNode;
  /** The revealed link's words — "View details", "See all (3)". */
  actionLabel?: string;
  /** Where the rest of this section lives. Omit and no link is drawn. */
  onAction?: () => void;
  /** The block(s) this labels. Inside the hover scope, deliberately. */
  children: React.ReactNode;
  /** Outer spacing belongs to the flow this sits in, not to the section. */
  className?: string;
}

export const LabeledSection = ({
  label,
  actionLabel,
  onAction,
  children,
  className,
}: LabeledSectionProps) => (
  <div className={`${styles.section} ${className ?? ''}`}>
    <div className={styles.labelRow}>
      {label}
      {onAction && actionLabel && (
        <button type="button" className={styles.link} onClick={onAction}>
          {actionLabel}
          <Icon name="chevron-right" size={14} />
        </button>
      )}
    </div>
    {children}
  </div>
);

LabeledSection.displayName = 'LabeledSection';
