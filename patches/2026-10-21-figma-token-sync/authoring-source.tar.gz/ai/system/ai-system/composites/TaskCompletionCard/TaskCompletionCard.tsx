/**
 * TaskCompletionCard — Task completion display with rating and follow-ups
 *
 * Inspired by Manus's task completion pattern. Shows when an agent task
 * is done with status, summary, star rating, and follow-up suggestions.
 */

import React, { useState, useCallback } from 'react';
import { Icon } from '@ink';
import styles from './TaskCompletionCard.module.css';

// =============================================================================
// Types
// =============================================================================

export interface TaskFollowUp {
  id: string;
  label: string;
  icon?: string;
  description?: string;
}

export interface TaskCompletionCardProps {
  /** Task title (e.g., "Agreement analysis complete") */
  title: string;
  /** Brief summary of what was accomplished */
  summary?: string;
  /** Task status */
  status: 'completed' | 'failed';
  /** Duration string (e.g., "2m 14s") */
  duration?: string;
  /** Star rating callback (1-5) */
  onRate?: (rating: number) => void;
  /** Follow-up suggestion cards */
  followUps?: TaskFollowUp[];
  /** Follow-up click callback */
  onFollowUp?: (id: string) => void;
}

// =============================================================================
// Component
// =============================================================================

export const TaskCompletionCard: React.FC<TaskCompletionCardProps> = ({
  title,
  summary,
  status,
  duration,
  onRate,
  followUps,
  onFollowUp,
}) => {
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);

  const handleRate = useCallback(
    (value: number) => {
      setRating(value);
      onRate?.(value);
    },
    [onRate]
  );

  return (
    <div className={styles.card}>
      {/* Status header */}
      <div className={styles.header}>
        <div className={styles.statusIcon} data-status={status}>
          <Icon
            name={status === 'completed' ? 'check' : 'close'}
            size={18}
          />
        </div>
        <div className={styles.headerText}>
          <span className={styles.title}>{title}</span>
          <div className={styles.meta}>
            {status === 'completed' ? 'Completed' : 'Failed'}
            {duration && (
              <>
                <span>·</span>
                <span>{duration}</span>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Summary */}
      {summary && <p className={styles.summary}>{summary}</p>}

      {/* Star rating */}
      {onRate && (
        <div className={styles.ratingSection}>
          <span className={styles.ratingLabel}>Rate this response</span>
          <div
            className={styles.stars}
            onMouseLeave={() => setHoverRating(0)}
          >
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                className={styles.star}
                data-active={star <= rating}
                data-hover={star <= hoverRating && star > rating}
                onClick={() => handleRate(star)}
                onMouseEnter={() => setHoverRating(star)}
                aria-label={`Rate ${star} star${star > 1 ? 's' : ''}`}
              >
                <Icon
                  name={star <= (hoverRating || rating) ? 'star-filled' : 'star'}
                  size={18}
                />
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Follow-up suggestions */}
      {followUps && followUps.length > 0 && (
        <div className={styles.followUps}>
          <span className={styles.followUpsLabel}>What's next?</span>
          <div className={styles.followUpCards}>
            {followUps.map((followUp) => (
              <button
                key={followUp.id}
                className={styles.followUpCard}
                onClick={() => onFollowUp?.(followUp.id)}
              >
                {followUp.icon && (
                  <span className={styles.followUpIcon}>
                    <Icon name={followUp.icon as any} size={16} />
                  </span>
                )}
                <div className={styles.followUpContent}>
                  <span className={styles.followUpLabel}>{followUp.label}</span>
                  {followUp.description && (
                    <span className={styles.followUpDescription}>
                      {followUp.description}
                    </span>
                  )}
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
