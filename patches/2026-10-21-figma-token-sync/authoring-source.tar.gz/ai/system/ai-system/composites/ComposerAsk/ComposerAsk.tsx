/**
 * ComposerAsk — the agent's human-in-the-loop ask, docked in the composer.
 *
 * Akshat's HITL spec, 2026-08-19 (Figma "HITL Spec", 203:24008). The surface
 * that asks the user to decide something mid-run is **not a thread bubble**. It
 * takes over the composer slot, because that is where the user already is when
 * they are about to answer, and because a bubble scrolls away while a pending
 * decision must not.
 *
 * Three states, all of them in the same slot:
 *
 * 1. **Default** — one question at a time. Header row = the question, a pager
 *    (`‹ 1 of 3 ›`) and a dismiss X. Then the answer rows: numbered quick-picks
 *    (`1`, `2`, … — the badge is the keyboard address, not decoration), then a
 *    pencil-badged redirect row, "No, and tell Iris what to do differently",
 *    with `Skip` on that same row. **Every** question offers pick / redirect /
 *    skip; none of the three is a per-question option.
 *
 *    **A REQUIRED BATCH DROPS THE EXITS (2026-08-27.)** Akshat, on the loan
 *    applicant confirm: *"they can't skip the confrimation of loan applicant
 *    details."* `required` hides the Skip row action, the dismiss X and the Esc
 *    exit for the WHOLE ask, so the only way out is to answer.
 *
 *    THIS DOES NOT BREAK THE RULE ABOVE, because the two work at different
 *    levels. The rule is per-question: no single question may quietly offer a
 *    different set of exits than its neighbours, which is what made the grammar
 *    learnable. `required` is per-batch: the ask as a whole either has exits or
 *    has none, and every question inside it reads the same either way. A host
 *    that wants one question of three to be unskippable is asking for the thing
 *    the rule forbids, and it is not built.
 *
 *    A required batch keeps pick and redirect. The user must still be able to
 *    say "no, do it differently" — the ask demands an answer, not a specific
 *    one.
 * 2. **Hover** — the pointed row takes a full-width fill and reveals a trailing
 *    chevron. The chevron is the commit affordance and it exists on exactly one
 *    row at a time. Keyboard focus is drawn identically (`data-active`), so the
 *    arrow keys and the pointer are the same state, not two.
 * 3. **Submitted** — the card collapses into a read-only transcript in the same
 *    slot: each question muted with its type tag in parens, the answer below in
 *    dark. Skipped survives as italic *Skipped*; a redirect survives as a quoted
 *    string; multi-select as bullets; a ranking as a numbered list. The host
 *    decides when to unmount it — `onComplete` fires once, the transcript stays.
 *
 * The AI disclaimer is not drawn here. It is pinned below the composer slot by
 * `IrisAgent`, in every state, and the ask does not displace it.
 *
 * ── Ink Menu.Item ──
 * The spec builds the rows from Ink's Menu.Item. The vendored Ink snapshot has
 * no Menu at all (`3-primitives` / `4-composites` / `5-patterns` — no Menu, no
 * MenuItem), so the rows here match its geometry rather than importing it:
 * 32px badge, 16px gap, 60px minimum row height, full-bleed fill on the active
 * row. If Ink ships Menu, swap `.row` for it and delete the geometry block.
 *
 * ── Superseding ──
 * `ElicitationCard` is the same idea drawn as a thread card. This replaces it.
 * The state machine below is lifted from it — saved answers per question, the
 * pager that only goes forward into answered ground, the drag reorder — because
 * that part was right; only the surface was.
 */

import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Icon } from '@ink';
import styles from './ComposerAsk.module.css';

// =============================================================================
// Types
// =============================================================================

export type AskQuestionType = 'single-select' | 'multi-select' | 'rank';

export interface AskQuestion {
  id: string;
  /** The question, as the agent would say it. One sentence; it wraps. */
  prompt: string;
  type: AskQuestionType;
  /** Quick-picks. Numbered `1..n` in order, and `1..9` are the keyboard addresses. */
  options: string[];
}

/**
 * How a question was answered, which is not the same as what it asked. A
 * skipped multi-select is `{ type: 'multi-select', kind: 'skipped' }` — the
 * transcript still needs the type to print `(multi select)` over the italic
 * *Skipped*. `ElicitationCard` collapsed the two and lost the tag.
 */
export type AskAnswerKind = AskQuestionType | 'redirect' | 'skipped';

export interface AskAnswer {
  questionId: string;
  prompt: string;
  type: AskQuestionType;
  kind: AskAnswerKind;
  /** The pick, the picks, the ranking, or the redirect text. `null` when skipped. */
  value: string | string[] | null;
}

export interface ComposerAskProps {
  questions: AskQuestion[];
  /**
   * Fires **once**, when the last question is answered. The card then draws the
   * transcript and keeps drawing it — the host owns the unmount, so a consumer
   * that wants the transcript to persist simply keeps passing `ask`.
   */
  onComplete: (answers: AskAnswer[]) => void;
  /** The X. The whole batch goes; nothing is reported. Never called when `required`. */
  onDismiss: () => void;
  /** Overrides the redirect row's label. The spec's wording is the default. */
  redirectLabel?: string;
  /**
   * THE BATCH MUST BE ANSWERED. Hides Skip, the dismiss X and the Esc exit for
   * every question in the ask — see the header for why this is batch-level and
   * not per-question. Defaults to false, so every existing consumer is
   * unchanged.
   */
  required?: boolean;
}

// =============================================================================
// The type tags the transcript prints. The spec's words, verbatim — `rank` says
// "drag to order" even where the interaction was simplified.
// =============================================================================

const TYPE_TAG: Record<AskQuestionType, string> = {
  'single-select': '(single select)',
  'multi-select': '(multi select)',
  rank: '(drag to order)',
};

const DEFAULT_REDIRECT_LABEL = 'No, and tell Iris what to do differently';

/** The Q&A text a host sends back up the thread, if it wants one. */
export function formatAskAnswers(answers: AskAnswer[]): string {
  return answers
    .map((a) => {
      const value =
        a.kind === 'skipped' || a.value === null
          ? 'Skipped'
          : Array.isArray(a.value)
            ? a.value.join(', ')
            : a.kind === 'redirect'
              ? `"${a.value}"`
              : a.value;
      return `Q: ${a.prompt} ${TYPE_TAG[a.type]}\nA: ${value}`;
    })
    .join('\n\n');
}

// =============================================================================
// ComposerAsk
// =============================================================================

export function ComposerAsk({
  questions,
  onComplete,
  onDismiss,
  redirectLabel = DEFAULT_REDIRECT_LABEL,
  required = false,
}: ComposerAskProps) {
  const [idx, setIdx] = useState(0);
  const [saved, setSaved] = useState<Record<string, AskAnswer>>({});
  const [submitted, setSubmitted] = useState<AskAnswer[] | null>(null);

  // Per-question working state, kept across pager navigation.
  const [picked, setPicked] = useState<Record<string, string[]>>({});
  const [order, setOrder] = useState<Record<string, string[]>>(() =>
    Object.fromEntries(questions.map((q) => [q.id, [...q.options]])),
  );
  const [redirect, setRedirect] = useState<Record<string, string>>({});

  /**
   * The pointed row. One index over options + the redirect row, set by the
   * pointer OR the arrow keys — the spec's hover state and the keyboard's
   * focus state are one thing, so they cannot disagree about which row the
   * chevron is on.
   */
  const [activeRow, setActiveRow] = useState<number | null>(null);

  const [dragIdx, setDragIdx] = useState<number | null>(null);
  const [dragOverIdx, setDragOverIdx] = useState<number | null>(null);

  const redirectRef = useRef<HTMLInputElement>(null);

  const q = questions[idx];
  const total = questions.length;
  const isLast = idx === total - 1;
  const rows = q.type === 'rank' ? (order[q.id] ?? q.options) : q.options;
  const redirectRowIdx = rows.length;
  const currentPicked = picked[q.id] ?? [];
  const currentRedirect = redirect[q.id] ?? '';

  // The pager only goes forward into ground already answered.
  const canGoNext = !isLast && !!saved[questions[idx + 1]?.id];

  useEffect(() => {
    setActiveRow(null);
    setDragIdx(null);
    setDragOverIdx(null);
  }, [idx]);

  const advance = useCallback(
    (answer: AskAnswer) => {
      const next = { ...saved, [answer.questionId]: answer };
      setSaved(next);
      if (!isLast) {
        setIdx((i) => i + 1);
        return;
      }
      // Unanswered questions the user paged past are skipped, not dropped.
      const all = questions.map(
        (question) =>
          next[question.id] ?? {
            questionId: question.id,
            prompt: question.prompt,
            type: question.type,
            kind: 'skipped' as const,
            value: null,
          },
      );
      setSubmitted(all);
      onComplete(all);
    },
    [saved, isLast, questions, onComplete],
  );

  const answer = useCallback(
    (kind: AskAnswerKind, value: string | string[] | null) =>
      advance({ questionId: q.id, prompt: q.prompt, type: q.type, kind, value }),
    [advance, q],
  );

  const skip = useCallback(() => answer('skipped', null), [answer]);

  const commitRedirect = useCallback(() => {
    const text = currentRedirect.trim();
    if (!text) return;
    answer('redirect', text);
  }, [answer, currentRedirect]);

  /** Commit the current multi-select / ranking. Empty multi-select reads as a skip. */
  const commitCurrent = useCallback(() => {
    if (q.type === 'multi-select') {
      if (currentPicked.length === 0) return skip();
      return answer('multi-select', currentPicked);
    }
    return answer('rank', order[q.id] ?? q.options);
  }, [q, currentPicked, order, answer, skip]);

  const toggle = useCallback(
    (option: string) =>
      setPicked((prev) => {
        const set = prev[q.id] ?? [];
        return {
          ...prev,
          [q.id]: set.includes(option) ? set.filter((o) => o !== option) : [...set, option],
        };
      }),
    [q.id],
  );

  /**
   * What CLICKING a row does. On a rank question: nothing. The row is a thing
   * you drag, and a stray click that submitted the whole ordering would be an
   * accidental commit on the one type where the user is meant to rearrange
   * first. Rank commits through `Done` (or Enter — see the key handler).
   */
  const commitRow = useCallback(
    (row: number) => {
      if (row === redirectRowIdx) return commitRedirect();
      const option = rows[row];
      if (q.type === 'single-select') return answer('single-select', option);
      if (q.type === 'multi-select') return toggle(option);
      return undefined;
    },
    [redirectRowIdx, rows, q.type, answer, toggle, commitRedirect],
  );

  // ---------------------------------------------------------------------------
  // Keyboard. `1..9` picks, ↑↓ walks the rows, ←→ pages, Enter commits the
  // pointed row, Esc dismisses the batch.
  //
  // The redirect input lives inside this card, so a bare digit typed into it
  // would otherwise fire a quick-pick. Every binding except Esc yields while a
  // field has the caret.
  // ---------------------------------------------------------------------------
  useEffect(() => {
    if (submitted) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        /* Esc is the X on the keyboard. A required batch has no X, so it has
           no Esc either — one exit hidden and the other left open is the
           affordance and the behaviour disagreeing. */
        if (!required) onDismiss();
        return;
      }
      const el = e.target as HTMLElement | null;
      if (el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.isContentEditable)) {
        return;
      }

      if (e.key >= '1' && e.key <= '9') {
        const n = Number(e.key) - 1;
        if (n >= rows.length) return;
        e.preventDefault();
        setActiveRow(n);
        if (q.type === 'single-select') answer('single-select', rows[n]);
        else if (q.type === 'multi-select') toggle(rows[n]);
        return;
      }
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        const last = redirectRowIdx;
        setActiveRow((r) => {
          if (r === null) return e.key === 'ArrowDown' ? 0 : last;
          return e.key === 'ArrowDown' ? Math.min(r + 1, last) : Math.max(r - 1, 0);
        });
        return;
      }
      if (e.key === 'ArrowLeft' && idx > 0) {
        e.preventDefault();
        setIdx((i) => i - 1);
        return;
      }
      if (e.key === 'ArrowRight' && canGoNext) {
        e.preventDefault();
        setIdx((i) => i + 1);
        return;
      }
      if (e.key === 'Enter' && activeRow !== null) {
        e.preventDefault();
        if (activeRow === redirectRowIdx) redirectRef.current?.focus();
        // Enter commits on every type. On rank there is nothing per-row to
        // commit, so it commits the ordering — the same thing `Done` does.
        else if (q.type === 'rank') commitCurrent();
        else commitRow(activeRow);
      }
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [
    submitted,
    onDismiss,
    rows,
    q.type,
    answer,
    toggle,
    redirectRowIdx,
    idx,
    canGoNext,
    activeRow,
    commitRow,
    commitCurrent,
    required,
  ]);

  // ---------------------------------------------------------------------------
  // Submitted — the read-only transcript, in the same slot.
  // ---------------------------------------------------------------------------
  const transcript = useMemo(() => {
    if (!submitted) return null;
    return (
      <div className={styles.transcript}>
        {submitted.map((a) => (
          <div key={a.questionId} className={styles.entry}>
            <p className={styles.entryPrompt}>
              {a.prompt} {TYPE_TAG[a.type]}
            </p>
            {a.kind === 'skipped' || a.value === null ? (
              <p className={styles.entrySkipped}>Skipped</p>
            ) : a.kind === 'redirect' ? (
              <p className={styles.entryAnswer}>&ldquo;{a.value as string}&rdquo;</p>
            ) : a.kind === 'multi-select' ? (
              <ul className={styles.entryBullets}>
                {(a.value as string[]).map((v) => (
                  <li key={v}>{v}</li>
                ))}
              </ul>
            ) : a.kind === 'rank' ? (
              <ol className={styles.entryNumbers}>
                {(a.value as string[]).map((v) => (
                  <li key={v}>{v}</li>
                ))}
              </ol>
            ) : (
              <p className={styles.entryAnswer}>{a.value as string}</p>
            )}
          </div>
        ))}
      </div>
    );
  }, [submitted]);

  if (transcript) return transcript;

  // ---------------------------------------------------------------------------
  // Default / Hover
  // ---------------------------------------------------------------------------
  return (
    <div className={styles.card}>
      <div className={styles.header}>
        <p className={styles.prompt}>{q.prompt}</p>
        <div className={styles.pager}>
          <button
            type="button"
            className={styles.pagerBtn}
            disabled={idx === 0}
            onClick={() => setIdx((i) => i - 1)}
            aria-label="Previous question"
          >
            <Icon name="chevron-left" size={16} />
          </button>
          <span className={styles.pagerCount}>
            {idx + 1} of {total}
          </span>
          <button
            type="button"
            className={styles.pagerBtn}
            disabled={!canGoNext}
            onClick={() => setIdx((i) => i + 1)}
            aria-label="Next question"
          >
            <Icon name="chevron-right" size={16} />
          </button>
          {/* No exit on a required batch — see the header. */}
          {!required && (
            <button
              type="button"
              className={styles.dismissBtn}
              onClick={onDismiss}
              aria-label="Dismiss"
            >
              <Icon name="close" size={18} />
            </button>
          )}
        </div>
      </div>

      <div className={styles.rows} onMouseLeave={() => setActiveRow(null)}>
        {rows.map((option, i) => (
          <div
            key={option}
            className={styles.row}
            data-active={activeRow === i || undefined}
            data-drag-over={(dragOverIdx === i && dragIdx !== i) || undefined}
            data-dragging={dragIdx === i || undefined}
            onMouseEnter={() => setActiveRow(i)}
            onClick={() => commitRow(i)}
            role="button"
            tabIndex={-1}
            /*
              Rank keeps `ElicitationCard`'s HTML5 drag — the spec says "drag to
              order" and the code was a file away. What it does NOT have is a
              keyboard reorder; ↑↓ walks the rows here, it does not move them.
              A rank question is therefore mouse-only to reorder, and Enter
              commits whatever order is showing.
            */
            draggable={q.type === 'rank'}
            onDragStart={q.type === 'rank' ? () => setDragIdx(i) : undefined}
            onDragOver={
              q.type === 'rank'
                ? (e) => {
                    e.preventDefault();
                    setDragOverIdx(i);
                  }
                : undefined
            }
            onDrop={
              q.type === 'rank'
                ? () => {
                    if (dragIdx === null || dragIdx === i) return;
                    const next = [...rows];
                    const [moved] = next.splice(dragIdx, 1);
                    next.splice(i, 0, moved);
                    setOrder((prev) => ({ ...prev, [q.id]: next }));
                    setDragIdx(null);
                    setDragOverIdx(null);
                  }
                : undefined
            }
            onDragEnd={
              q.type === 'rank'
                ? () => {
                    setDragIdx(null);
                    setDragOverIdx(null);
                  }
                : undefined
            }
          >
            <span
              className={styles.badge}
              data-checked={
                (q.type === 'multi-select' && currentPicked.includes(option)) || undefined
              }
            >
              {i + 1}
            </span>
            <span className={styles.rowLabel}>{option}</span>
            {/* No chevron on a rank row — it would advertise a commit the
                click does not perform. */}
            {q.type !== 'rank' && (
              <span className={styles.chevron} aria-hidden>
                <Icon name="chevron-right" size={18} />
              </span>
            )}
          </div>
        ))}

        {/*
          The redirect row. On every question, of every type — the spec makes
          "no, do it differently" and "skip" standing exits, not per-question
          options. The label is drawn as the input's placeholder rather than as
          a label that swaps for an input on click: same pixels, one less state.
        */}
        <div
          className={styles.row}
          data-active={activeRow === redirectRowIdx || undefined}
          onMouseEnter={() => setActiveRow(redirectRowIdx)}
        >
          <span className={styles.badge} data-icon>
            <Icon name="pencil" size={16} />
          </span>
          <input
            ref={redirectRef}
            className={styles.redirectInput}
            placeholder={redirectLabel}
            value={currentRedirect}
            onChange={(e) => setRedirect((prev) => ({ ...prev, [q.id]: e.target.value }))}
            onKeyDown={(e) => {
              if (e.key === 'Enter') commitRedirect();
            }}
          />
          {currentRedirect.trim() ? (
            <button
              type="button"
              className={styles.chevronBtn}
              onClick={commitRedirect}
              aria-label="Send"
            >
              <Icon name="chevron-right" size={18} />
            </button>
          ) : (
            <>
              {/*
                Unspecced: the PNGs draw Default and Hover for a single-select
                only. Multi-select and rank need a commit that is not a row, so
                they get one tertiary button beside Skip, in the row the spec
                already gave to tertiary actions. Revisit when Akshat draws them.
              */}
              {/*
                DONE IS HIDDEN WHERE IT WOULD SKIP. An empty multi-select commits
                as a skip (see `commitCurrent`), so on a required batch the
                button is the skip the batch forbids, wearing another word. It
                comes back as soon as one option is picked. Rank always has an
                order, so its Done always commits something.
              */}
              {q.type !== 'single-select' &&
                (!required || q.type === 'rank' || currentPicked.length > 0) && (
                  <button type="button" className={styles.skipBtn} onClick={commitCurrent}>
                    Done
                  </button>
                )}
              {!required && (
                <button type="button" className={styles.skipBtn} onClick={skip}>
                  Skip
                </button>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}

export default ComposerAsk;
