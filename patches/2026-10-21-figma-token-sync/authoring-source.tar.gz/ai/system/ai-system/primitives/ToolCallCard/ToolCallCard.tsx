/**
 * ToolCallCard — Displays a tool invocation with status
 *
 * Shows tool name, parameters, result, and current status
 * (pending, running, complete, error).
 *
 * Supports collapsible body, human-readable summary, shimmer animation
 * during running state, and duration display.
 */

import React, { useState, useEffect } from 'react';
import { Icon } from '@ink';
import styles from './ToolCallCard.module.css';

// =============================================================================
// Types
// =============================================================================

export type ToolCallStatus = 'pending' | 'running' | 'complete' | 'error';

export interface ToolCallParam {
  name: string;
  value: string;
}

export interface ToolCallCardProps {
  /** Tool name (e.g., "search_documents") */
  name: string;
  /** Human-readable summary (e.g., "Searched documents for 'quarterly report'") */
  summary?: string;
  /** Tool parameters */
  params?: ToolCallParam[];
  /** Result text (shown when complete) */
  result?: string;
  /** Current status */
  status: ToolCallStatus;
  /** Duration string (e.g., "1.2s") — shown next to status when complete */
  duration?: string;
  /** Error message (shown when status is 'error') */
  error?: string;
  /** Override the default expanded state */
  defaultExpanded?: boolean;
  /** Controlled expanded state */
  isExpanded?: boolean;
  /** Callback when expanded state changes */
  onToggle?: (expanded: boolean) => void;
}

// =============================================================================
// Helpers
// =============================================================================

const statusConfig: Record<ToolCallStatus, { icon: string; label: string }> = {
  pending: { icon: 'clock', label: 'Pending' },
  running: { icon: 'process-spinner', label: 'Running' },
  complete: { icon: 'status-check', label: 'Complete' },
  error: { icon: 'status-warn', label: 'Error' },
};

/** Determine whether the card should be expanded by default based on status. */
function getDefaultExpanded(status: ToolCallStatus): boolean {
  return status === 'running' || status === 'pending';
}

// =============================================================================
// Component
// =============================================================================

export const ToolCallCard: React.FC<ToolCallCardProps> = ({
  name,
  summary,
  params,
  result,
  status,
  duration,
  error,
  defaultExpanded,
  isExpanded: controlledExpanded,
  onToggle,
}) => {
  const config = statusConfig[status];

  // Determine if we're in controlled mode
  const isControlled = controlledExpanded !== undefined;

  // Internal state for uncontrolled mode
  const [internalExpanded, setInternalExpanded] = useState<boolean>(
    defaultExpanded ?? getDefaultExpanded(status)
  );

  // Auto-collapse when status transitions to complete or error (uncontrolled only)
  useEffect(() => {
    if (!isControlled && defaultExpanded === undefined) {
      setInternalExpanded(getDefaultExpanded(status));
    }
  }, [status, isControlled, defaultExpanded]);

  const expanded = isControlled ? controlledExpanded : internalExpanded;

  const handleToggle = () => {
    const next = !expanded;
    if (!isControlled) {
      setInternalExpanded(next);
    }
    onToggle?.(next);
  };

  // Check if body has content to show
  const hasBody =
    (params && params.length > 0) ||
    (status === 'complete' && result) ||
    (status === 'error' && error);

  return (
    <div className={styles.card} data-status={status}>
      {/* Header */}
      <div
        className={styles.header}
        onClick={hasBody ? handleToggle : undefined}
        role={hasBody ? 'button' : undefined}
        tabIndex={hasBody ? 0 : undefined}
        onKeyDown={
          hasBody
            ? (e: React.KeyboardEvent) => {
                if (e.key === 'Enter' || e.key === ' ') {
                  e.preventDefault();
                  handleToggle();
                }
              }
            : undefined
        }
        style={hasBody ? undefined : { cursor: 'default' }}
      >
        <span className={styles.statusIcon} data-status={status}>
          <Icon name={config.icon as any} size={14} />
        </span>

        {/* Collapsed with summary: show summary as primary text */}
        {!expanded && summary ? (
          <>
            <span className={styles.collapsedSummary}>{summary}</span>
          </>
        ) : (
          /* Expanded or no summary: show name + optional summary subtitle */
          <span className={styles.nameGroup}>
            <span className={styles.name}>{name}</span>
            {expanded && summary && (
              <span className={styles.summary}>{summary}</span>
            )}
          </span>
        )}

        <span className={styles.statusLabel} data-status={status}>
          {config.label}
        </span>

        {duration != null && status === 'complete' && (
          <span className={styles.duration}>{duration}</span>
        )}

        {hasBody && (
          <span className={styles.chevron} data-expanded={String(expanded)}>
            <Icon name="chevron-down" size={14} />
          </span>
        )}
      </div>

      {/* Collapsible body */}
      {hasBody && (
        <div className={styles.body} data-expanded={String(expanded)}>
          <div className={styles.bodyInner}>
            {/* Parameters */}
            {params && params.length > 0 && (
              <div className={styles.params}>
                {params.map((p, i) => (
                  <div key={i} className={styles.param}>
                    <span className={styles.paramName}>{p.name}:</span>
                    <span className={styles.paramValue}>{p.value}</span>
                  </div>
                ))}
              </div>
            )}

            {/* Result */}
            {status === 'complete' && result && (
              <div className={styles.result}>{result}</div>
            )}

            {/* Error */}
            {status === 'error' && error && (
              <div className={styles.error}>{error}</div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
