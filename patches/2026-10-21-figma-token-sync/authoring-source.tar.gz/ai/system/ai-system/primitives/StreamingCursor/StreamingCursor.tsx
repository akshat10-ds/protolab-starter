/**
 * StreamingCursor — Blinking cursor for active text generation
 *
 * Animated cursor with smooth fade-out on completion and configurable
 * blink style. Used inline at the end of streaming messages.
 */

import React, { useState, useEffect } from 'react';
import styles from './StreamingCursor.module.css';

// =============================================================================
// Types
// =============================================================================

export interface StreamingCursorProps {
  /** Whether the cursor is actively blinking */
  active?: boolean;
  /** Cursor color variant */
  variant?: 'default' | 'accent';
  /** Blink style */
  blink?: 'step' | 'smooth' | 'pulse';
  /** Called when fade-out animation completes */
  onFadeComplete?: () => void;
}

// =============================================================================
// Component
// =============================================================================

export const StreamingCursor: React.FC<StreamingCursorProps> = ({
  active = true,
  variant = 'default',
  blink = 'smooth',
  onFadeComplete,
}) => {
  const [visible, setVisible] = useState(active);
  const [fading, setFading] = useState(false);

  useEffect(() => {
    if (active) {
      setVisible(true);
      setFading(false);
    } else if (visible) {
      // Smooth fade-out instead of abrupt disappear
      setFading(true);
      const timer = setTimeout(() => {
        setVisible(false);
        setFading(false);
        onFadeComplete?.();
      }, 400);
      return () => clearTimeout(timer);
    }
  }, [active, visible, onFadeComplete]);

  if (!visible) return null;

  return (
    <span
      className={styles.cursor}
      data-variant={variant}
      data-blink={blink}
      data-fading={fading}
      aria-hidden="true"
    />
  );
};
