/**
 * ArtifactCard — Preview card for an agent-generated artifact
 *
 * Shows title, type badge, and optional thumbnail or icon.
 * Used in artifact lists and panels.
 */

import React from 'react';
import { Icon } from '@ink';
import styles from './ArtifactCard.module.css';

// =============================================================================
// Types
// =============================================================================

export type ArtifactType = 'document' | 'code' | 'table' | 'image' | 'chart' | 'custom';

export interface ArtifactCardProps {
  /** Artifact title */
  title: string;
  /** Artifact type (shown as badge) */
  type: ArtifactType;
  /** Optional description */
  description?: string;
  /** Called when card is clicked */
  onClick?: () => void;
  /** Whether this artifact is currently selected/active */
  isActive?: boolean;
}

// =============================================================================
// Config
// =============================================================================

const typeConfig: Record<ArtifactType, { icon: string; label: string }> = {
  document: { icon: 'document', label: 'Document' },
  code: { icon: 'code-bracket', label: 'Code' },
  table: { icon: 'table', label: 'Table' },
  image: { icon: 'image', label: 'Image' },
  chart: { icon: 'chart-bar', label: 'Chart' },
  custom: { icon: 'layout-grid', label: 'Custom' },
};

// =============================================================================
// Component
// =============================================================================

export const ArtifactCard: React.FC<ArtifactCardProps> = ({
  title,
  type,
  description,
  onClick,
  isActive = false,
}) => {
  const config = typeConfig[type];

  return (
    <div
      className={styles.card}
      data-active={isActive}
      onClick={onClick}
      role={onClick ? 'button' : undefined}
      tabIndex={onClick ? 0 : undefined}
    >
      <div className={styles.thumbnail}>
        <Icon name={config.icon as any} size={24} />
      </div>
      <div className={styles.content}>
        <span className={styles.title}>{title}</span>
        {description && <span className={styles.description}>{description}</span>}
      </div>
      <span className={styles.badge} data-type={type}>{config.label}</span>
    </div>
  );
};
