/**
 * StatusIndicator — Agent state display
 *
 * Shows the current state of an AI agent with animated dot, icon,
 * label, and optional detail line showing what's being operated on.
 */

import React, { useState, useEffect, useRef } from 'react';
import { Icon } from '@ink';
import styles from './StatusIndicator.module.css';

// =============================================================================
// Types
// =============================================================================

export type AgentStatus =
  | 'idle'
  | 'thinking'
  | 'searching'
  | 'reading'
  | 'writing'
  | 'executing'
  | 'waiting'
  | 'indexing'
  | 'generating'
  | 'connecting';

export interface StatusIndicatorProps {
  /** Current agent state */
  status: AgentStatus;
  /** Optional custom label override */
  label?: string;
  /** Detail line: what's being operated on (e.g., file path, search query) */
  detail?: string;
  /** Size variant */
  size?: 'small' | 'medium';
  /** Show elapsed time counter for active states (after 2s delay) */
  showElapsed?: boolean;
}

// =============================================================================
// Config
// =============================================================================

const statusConfig: Record<AgentStatus, { icon: string; label: string }> = {
  idle: { icon: 'status-check', label: 'Ready' },
  thinking: { icon: 'bolt', label: 'Thinking...' },
  searching: { icon: 'search', label: 'Searching...' },
  reading: { icon: 'document', label: 'Reading...' },
  writing: { icon: 'pencil', label: 'Writing...' },
  executing: { icon: 'control-play', label: 'Executing...' },
  waiting: { icon: 'clock', label: 'Waiting...' },
  indexing: { icon: 'layout-grid', label: 'Indexing...' },
  generating: { icon: 'bolt', label: 'Generating...' },
  connecting: { icon: 'link', label: 'Connecting...' },
};

// =============================================================================
// Elapsed timer hook
// =============================================================================

function useElapsedTime(active: boolean) {
  const [elapsed, setElapsed] = useState(0);
  const [visible, setVisible] = useState(false);
  const startRef = useRef(Date.now());

  useEffect(() => {
    if (!active) {
      setElapsed(0);
      setVisible(false);
      return;
    }

    startRef.current = Date.now();
    setElapsed(0);
    setVisible(false);

    // Show after 2s delay
    const showTimer = setTimeout(() => setVisible(true), 2000);

    const interval = setInterval(() => {
      setElapsed(Math.floor((Date.now() - startRef.current) / 1000));
    }, 1000);

    return () => {
      clearTimeout(showTimer);
      clearInterval(interval);
    };
  }, [active]);

  return { elapsed, visible };
}

function formatElapsed(seconds: number): string {
  if (seconds < 60) return `${seconds}s`;
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins}m ${secs}s`;
}

// =============================================================================
// Component
// =============================================================================

export const StatusIndicator: React.FC<StatusIndicatorProps> = ({
  status,
  label,
  detail,
  size = 'medium',
  showElapsed = false,
}) => {
  const config = statusConfig[status] || statusConfig.idle;
  const isActive = status !== 'idle';
  const { elapsed, visible: elapsedVisible } = useElapsedTime(
    showElapsed && isActive
  );

  // Track previous status for crossfade
  const [displayStatus, setDisplayStatus] = useState(status);
  const [transitioning, setTransitioning] = useState(false);

  useEffect(() => {
    if (status !== displayStatus) {
      setTransitioning(true);
      const timer = setTimeout(() => {
        setDisplayStatus(status);
        setTransitioning(false);
      }, 150);
      return () => clearTimeout(timer);
    }
  }, [status, displayStatus]);

  const activeConfig = statusConfig[displayStatus] || statusConfig.idle;

  return (
    <div
      className={styles.indicator}
      data-status={displayStatus}
      data-size={size}
      data-transitioning={transitioning}
    >
      <div className={styles.mainRow}>
        <span className={styles.dot} data-active={isActive} />
        <Icon
          name={activeConfig.icon as any}
          size={size === 'small' ? 12 : 14}
          className={styles.icon}
        />
        <span className={styles.label}>
          {label || activeConfig.label}
        </span>
        {showElapsed && elapsedVisible && isActive && (
          <span className={styles.elapsed}>{formatElapsed(elapsed)}</span>
        )}
      </div>
      {detail && isActive && (
        <div className={styles.detail}>{detail}</div>
      )}
    </div>
  );
};
