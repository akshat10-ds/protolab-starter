/**
 * ContextPill — Shows a loaded context item
 *
 * Displays a document name with icon and optional dismiss action.
 * Used in chat inputs and context bars to show what's loaded.
 */

import React from 'react';
import { Icon } from '@ink';
import styles from './ContextPill.module.css';

// =============================================================================
// Types
// =============================================================================

export interface ContextPillProps {
  /** Display label */
  label: string;
  /** Icon name */
  icon?: string;
  /** Called when dismiss button is clicked */
  onDismiss?: () => void;
  /** Called when the pill itself is clicked */
  onClick?: () => void;
  /** Truncate label after this many characters */
  maxLength?: number;
}

// =============================================================================
// Component
// =============================================================================

export const ContextPill: React.FC<ContextPillProps> = ({
  label,
  icon = 'document',
  onDismiss,
  onClick,
  maxLength = 30,
}) => {
  const displayLabel = maxLength && label.length > maxLength
    ? `${label.substring(0, maxLength)}...`
    : label;

  return (
    <span
      className={styles.pill}
      onClick={onClick}
      data-clickable={!!onClick}
      title={label}
    >
      <Icon name={icon as any} size={12} className={styles.icon} />
      <span className={styles.label}>{displayLabel}</span>
      {onDismiss && (
        <button
          type="button"
          className={styles.dismiss}
          onClick={(e) => {
            e.stopPropagation();
            onDismiss();
          }}
          aria-label={`Remove ${label}`}
        >
          <Icon name="close" size={10} />
        </button>
      )}
    </span>
  );
};
