/**
 * GroupedCitationBadge — Inline grouped citation marker with carousel tooltip
 *
 * Shows a cobalt badge with a primary source name and "+N" count. On hover,
 * reveals a portal-based tooltip with a carousel to navigate through multiple
 * source citations. Uses the same visual language as CitationBadge.
 *
 * Decided 2026-03-18.
 */

import React, { useRef, useState, useCallback, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { IconButton } from '@ink';
import type { Citation } from '@ai/primitives/CitationBadge/CitationBadge';
import styles from './GroupedCitationBadge.module.css';

// =============================================================================
// Types
// =============================================================================

export interface GroupedCitationBadgeProps {
  /** Display label for the chip (e.g., "Acme MSA") */
  label: string;
  /** Array of citations to carousel through */
  citations: Citation[];
  /** Called when a citation is clicked */
  onClick?: (citation: Citation) => void;
  /** Tooltip width in px */
  tooltipWidth?: number;
}

// =============================================================================
// Component
// =============================================================================

export const GroupedCitationBadge: React.FC<GroupedCitationBadgeProps> = ({
  label,
  citations,
  onClick,
  tooltipWidth = 280,
}) => {
  const buttonRef = useRef<HTMLButtonElement>(null);
  const tooltipRef = useRef<HTMLDivElement>(null);
  const [isHovered, setIsHovered] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);
  const [tooltipStyle, setTooltipStyle] = useState<React.CSSProperties>({});
  const hideTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const extraCount = citations.length - 1;
  const activeCitation = citations[activeIndex];

  // Reset index when citations change
  useEffect(() => {
    setActiveIndex(0);
  }, [citations]);

  const positionTooltip = useCallback(() => {
    if (buttonRef.current) {
      const rect = buttonRef.current.getBoundingClientRect();

      // Position tooltip 8px below the badge
      let left = rect.left;
      const top = rect.bottom + 8;

      // Keep within viewport
      if (left + tooltipWidth > window.innerWidth - 16) {
        left = window.innerWidth - tooltipWidth - 16;
      }
      left = Math.max(16, left);

      setTooltipStyle({ top: `${top}px`, left: `${left}px` });
    }
  }, [tooltipWidth]);

  const showTooltip = useCallback(() => {
    if (hideTimeoutRef.current) {
      clearTimeout(hideTimeoutRef.current);
      hideTimeoutRef.current = null;
    }
    positionTooltip();
    setIsHovered(true);
  }, [positionTooltip]);

  const hideTooltip = useCallback(() => {
    // Delay hide so mouse can move from chip to tooltip
    hideTimeoutRef.current = setTimeout(() => {
      setIsHovered(false);
      setActiveIndex(0);
    }, 120);
  }, []);

  // Cleanup timeout on unmount
  useEffect(() => {
    return () => {
      if (hideTimeoutRef.current) {
        clearTimeout(hideTimeoutRef.current);
      }
    };
  }, []);

  const handlePrev = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    setActiveIndex((prev) => Math.max(0, prev - 1));
  }, []);

  const handleNext = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    setActiveIndex((prev) => Math.min(citations.length - 1, prev + 1));
  }, [citations.length]);

  const handleTooltipClick = useCallback(() => {
    if (onClick && activeCitation) {
      onClick(activeCitation);
    }
  }, [onClick, activeCitation]);

  const tooltip =
    isHovered && activeCitation
      ? createPortal(
          <div
            ref={tooltipRef}
            className={`${styles.tooltip} ${styles.tooltipVisible}`}
            style={{ ...tooltipStyle, width: tooltipWidth }}
            onMouseEnter={showTooltip}
            onMouseLeave={hideTooltip}
            onClick={handleTooltipClick}
          >
            <div className={styles.tooltipContent}>
              <span className={styles.tooltipLabel}>Source</span>
              <span className={styles.tooltipTitle}>
                {activeCitation.title}
              </span>
              <span className={styles.tooltipExcerpt}>
                &ldquo;
                {activeCitation.excerpt.length > 160
                  ? `${activeCitation.excerpt.substring(0, 160)}...`
                  : activeCitation.excerpt}
                &rdquo;
              </span>
            </div>
            <div className={styles.divider} />
            <div className={styles.navBar}>
              <div className={styles.navArrows}>
                <IconButton
                  icon="chevron-left"
                  size="small"
                  variant="tertiary"
                  aria-label="Previous source"
                  onClick={handlePrev}
                  disabled={activeIndex === 0}
                />
                <IconButton
                  icon="chevron-right"
                  size="small"
                  variant="tertiary"
                  aria-label="Next source"
                  onClick={handleNext}
                  disabled={activeIndex === citations.length - 1}
                />
              </div>
              <span className={styles.navCounter}>
                {activeIndex + 1}/{citations.length}
              </span>
            </div>
          </div>,
          document.body
        )
      : null;

  return (
    <span className={styles.wrapper}>
      <button
        ref={buttonRef}
        type="button"
        className={styles.button}
        onMouseEnter={showTooltip}
        onMouseLeave={hideTooltip}
        onClick={() => onClick?.(citations[0])}
      >
        <span className={`${styles.chip} ${isHovered ? styles.chipActive : ''}`}>
          {label}
          {extraCount > 0 && (
            <span className={styles.count}>+{extraCount}</span>
          )}
        </span>
      </button>
      {tooltip}
    </span>
  );
};
